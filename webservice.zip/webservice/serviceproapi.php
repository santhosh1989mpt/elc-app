<?php
if (substr_count($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip')) ob_start("ob_gzhandler"); else ob_start();
  // JSON webservice using PHP.
  // Include core files.
  require_once 'incl/config.php';
  include("incl/MYSQL.php");
  header('Access-Control-Allow-Origin: *');
  header('Content-Type : application/json;charset=utf-8');
  date_default_timezone_set('America/Chicago');
  $script_tz 			= date_default_timezone_get();
  /*
   * Assume your local application URL is this: http://localhost/api/phpapiexample.php
   * The below methods can be called like below
   * http://localhost/api/phpapiexample.php?action=countries
   * http://localhost/api/phpapiexample.php?action=states&countryid=countryid
   * http://localhost/api/phpapiexample.php?action=states&countryid=1
  */

  if (isset($_REQUEST['action']))
  {
  	$action = $_REQUEST['action'];
  }
  else $action = "";

  /*
   * actions
  */
  // Always good to peform string comparison with lowercase and trimming spaces.
  switch (strtolower(trim($action))) {
  	case 'login_emp':
  		ipad_login_emp();
  		break;
  	case 'ipad_login_forrgot_password':
  		ipad_login_forrgot();
  		break;
	case 'login_destination':
  		ipad_login_destination();
  		break;
	case 'logout':
  		ipad_logout();
  		break;	
		
	case 'get_customers_information':
  		sp_get_customers_information();
  		break;
	case 'get_service_type':
  		sp_get_service_type();
  		break;
			
	case 'get_one_tbl_invoice_quote_header':
  		all_one_tbl_invoice_quote_header();
  		break;		
	case 'seq_count':
  		seq_count();
  		break;	
	case 'get_one_espi':
  		all_one_espi();
  		break;
	case 'get_one_espi_sa':
  		all_one_espi_sa();
  		break;	
	case 'sp_tbl_customers':
  		sp_tbl_customers_one();
  		break;	
	case 'sp_tbl_state':
  		sp_lkp_state_one();
  		break; 	
	case 'get_three_tbl_warrantycustomers':
  		all_three_tbl_warrantycustomers();
  		break;	
	case 'select_energy_savings':
  		select_energy_savings();
  		break;	
	case 'sp_customer_up':
		sp_customer_up();
		break;			
	case 'sp_workorder_desc_up':
		sp_workorder_desc_up();
		break;		
	case 'get_sp_sle_customer_type':
  		all_sp_sle_customer_type();	
  		break;
  	case 'get_sp_sle_lkp_leadsource':
  		all_sp_sle_lkp_leadsource();	
  		break;
	case 'get_sp_sle_campaign':
  		all_sp_sle_campaign();	
  		break;	
	case 'get_sp_tbl_employee':
  		all_sp_tbl_employee();	
  		break;	
	case 'get_sp_sle_lkp_designation':
  		all_sp_sle_lkp_designation();	
  		break;	
	case 'get_sp_tbl_warrantyworkorder_two':
  		all_sp_tbl_warrantyworkorder_two();	
  		break;	
	case 'get_sp_tbl_customer_type_two':
  		all_sp_tbl_customer_type_two();	
  		break;	
	case 'get_sp_sel_tbl_warrantycustomers_two':
  		all_sp_sel_tbl_warrantycustomers_two();	
  		break;
	case 'get_sp_sel_lkp_state_one':
  		all_sp_sel_lkp_state_one();	
  		break;		
	case 'get_all_states':
  		get_all_states();	
  		break;
	case 'sp_sel_espi_one_get': 
  		sp_sel_espi_one();
  		break;
	case 'get_energy_savings': 
  		sp_get_energy_savings_three();
  		break;	
	case 'get_sel_furnace_three':
		get_sel_furnace_three();
		break;
	case 'get_sle_tbl_customers':
  		all_sle_tbl_customers();
  		break;
	case 'get_sel_espi_three':
  		get_sel_espi_three();
  		break;	
	case 'get_sle_tbl_repairsolutions':
  		all_sle_tbl_repairsolutions();
  		break;
	case 'allenergy_savings_insert': 
  		sp_allenergy_savings_insert();
  		break;
	case 'allenergy_savings_update': 
  		sp_allenergy_savings_update();
  		break;	
	//products	
	case 'get_sle_four_tbl_repairsolutions':
  		all_sle_four_tbl_repairsolutions();
  		break;	
	
	case 'get_sp_sle_two_tbl_invoice_quote_footer':
  		all_sp_sle_two_tbl_invoice_quote_footer();	
  		break;
	case 'get_sp_sle_one_tbl_invoice_quote_footer':
  		all_sp_sle_one_tbl_invoice_quote_footer();	
  		break;
	case 'get_sp_sle_two_espi':
  		all_sp_sle_two_espi();
		break;
			
	case 'get_sp_sle_three_tbl_repairsolutions':
  		all_sp_sle_three_tbl_repairsolutions();	
  		break;	
	case 'get_sp_allfooterinfo':
		get_sp_allfooterinfo();
		break;
	case 'select_tbl_invoice_quote_footer':
		select_tbl_invoice_quote_footer();
		break;
	case 'get_prodsuggestions':
		get_prodsuggestions();
		break;
	
	case 'get_prodsuggestions1':
		get_prodsuggestions1();
		break;
	
	case 'get_sp_del_tbl_invoice_quote_footer':
  		all_sp_del_tbl_invoice_quote_footer();	
  		break;	
	case 'get_sp_sle_one_lkp_products':
  		all_sp_sle_one_lkp_products();	
  		break;
	case 'get_sp_sle_four_tbl_invoice_quote_footer':
  		all_sp_sle_four_tbl_invoice_quote_footer();	
  		break;	
	case 'get_sp_upd_two_tbl_repairsolutions':
  		all_sp_upd_two_tbl_repairsolutions();	
  		break;
	case 'get_sp_up_two_tbl_repairsolutions':
  		all_sp_up_two_tbl_repairsolutions();	
  		break;
	case 'get_sp_upda_two_tbl_repairsolutions':
  		all_sp_upda_two_tbl_repairsolutions();	
  		break;
		
	//products		
///////////////////////////////////ramya//////////////////////////////////	ramya/////////////////////////////////// ramya///////////////////////////////////	
///////////////////////////////////ramya//////////////////////////////////	ramya/////////////////////////////////// ramya///////////////////////////////////
///////////////////////////////////ramya//////////////////////////////////	ramya/////////////////////////////////// ramya///////////////////////////////////
///////////////////////////////////ramya//////////////////////////////////	ramya/////////////////////////////////// ramya///////////////////////////////////		
	/*SANTHOSH - START*/
	case 'sp_up_espi_twthree':
  		sp_up_espi_twthree();
  		break;
  case 'sp_ins_espi_twtwo':
  		sp_ins_espi_twtwo();
  		break;
  case 'tbl_repairsolutions': 
  		sp_tbl_repairsolutions();
  		break;
 case 'tbl_repairsolutions_cus_balance': 
  		tbl_repairsolutions_cus_balance();
  		break;
		
 case 'get_condencer_value': 
  		sp_tbl_condencer_value();
  		break;		

  case 'sp_espi_customer_prac_up':
  		sp_espi_customer_prac_up();
  		break;
  case 'get_up_nine_espi': 
  		all_up_nine_espi();
  		break;
  case 'sp_ins_nine_espi': 
  		sp_ins_nine_espi();
  		break;
   case 'sp_get_espi_report_cid_three':
  		sp_get_espi_report_cid_three();
  		break;
   case 'espi_report_insert': 
  		sp_tbl_espi_report_ins();
  		break;
   case 'up_tbl_espi_report': 
  		sp_up_tbl_espi_report();
  		break;
	case 'del_tbl_espi_report': 
  		sp_del_tbl_espi_report();
  		break;
	/*date oct29*/
	case 'sp_espitable':
  		sp_espi_five();
  		break;
	/*date nov04*/
	case 'get_sp_sle_one_tbl_customers':
  		all_sp_sle_one_tbl_customers();	
  		break;	
	case 'sp_up_espi_twseven':
  		sp_up_espi_twseven();
  		break;
	 case 'sp_up_espi_duct_age_nine':
  		sp_up_espi_duct_age_nine();
  		break;
	/*date nov07*/
	case 'sp_up_espi_twseven_heating':
  		sp_up_espi_twseven_heating();
  		break;
		/*date feb14*/
	case 'get_sp_product': 
  		get_sp_product();
  		break;
	case 'discount_type': 
  		discount_type();
  		break;	
	case 'update_special_discount': 
  		update_special_discount();
  		break;
	/*feb 28*/
	case 'customer_dynamic_color': 
  		customer_dynamic_color();
  		break;
	case 'discount_special':
  		discount_special();	
  		break;
	case 'balance_update':
  		balance_update();	
  		break; 
	case 'balance_update1':
  		balance_update1();	
  		break; 
	case 'tbl_repair_sol':
  		tbl_repair_sol();	
  		break;
	case 'sp_repairsolutions_insert':
  		sp_repairsolutions_insert();	
  		break;
	case 'delete_proposal_product':
  		delete_proposal_product();	
  		break;
	/*SANTHOSH - END*/

// Balu Created Oct - 19 //   DASHBOARD
		
		case 'spemployeetwo':
  		sp_employee_two();
  		break;
		
		case 'get_invoice_quote_header':
  		ipad_login_invoice_quote_header();
  		break;
		
		case 'spdispatchempthree':
  		sp_dispatch_emp_three();
  		break;
		
		case 'get_sp_alloted_tasks_dashboard':
  		get_sp_alloted_tasks_dashboard();	
  		break;
		
		case 'get_sp_get_user_records':
  		get_sp_get_user_records();	
  		break;
		
		case 'selectactual':
  		get_sp_selectactual();	
  		break;
		
		case 'selectsales_opp':
  		get_sp_selectsales_opp();	
  		break;
		
		case 'selectreplacement_opp':
  		get_sp_selectreplacement_opp();	
  		break;
		
		case 'selectlead_appointments':
  		get_sp_selectlead_appointments();	
  		break;
		
		case 'get_all_emp_invoice_quote_header':
  		all_emp_invoice_quote_header();
  		break;
		
		case 'spinvoice_quotetech_three':
  		sp_invoice_quote_tech_opp_three();
  		break;
		
		case 'spemployeethree':
  		sp_employee_three();
  		break;
		
		case 'spservicetype':
  		sp_service_type_three();
  		break;
		
		case 'spcustomertype':
  		sp_customer_type_three();
  		break;
		
		case 'spemployeetypetwo':
  		sp_employee_type_two();
  		break;
		
		case 'spcalculationtwo':
  		sp_calculation_two();
  		break;
		
		
		case 'get_sp_tbl_alloted_slots_four':
  		all_sp_tbl_alloted_slots_four();	
  		break;	
		
		case 'spalloteslotefour':
  		spalloteslotefour();
  		break;
		
		case 'spreferral_graph':
  		sp_spreferral_graph();	
  		break;
		
		case 'destination_name':
  		sp_destination_name();	
  		break;
		
		case 'spsearchpie':
  		sp_spsearchpie();	
  		break;
		
		case 'get_calender_id':
  		sp_get_calender_id();	
  		break;
		
		case 'get_working_calender_id':
  		sp_get_working_calender_id();	
  		break;
		
		case 'get_booking_dates':
  		sp_get_booking_dates();	
  		break;
		
		case 'get_upgrade_goals':
  		sp_get_upgrade_goals();	
  		break;
		
		case 'get_upgrade_actuals':
  		sp_get_upgrade_actuals();	
  		break;
	
		case 'goalss':
  		sp_get_goalss();	
  		break;
		
		case 'goalss_esc':
  		sp_get_goalss_esc();	
  		break;
		
		case 'get_actualss':
  		sp_get_actualss();	
  		break;
	
		case 'actualss_product':
  		sp_get_actualss_product();	
  		break;
		
		case 'actualss_product1':
  		sp_get_actualss_product1();	
  		break;
		
		
		
		case 'actuals':
  		sp_get_actuals();	
  		break;
		
		case 'getproductid':
  		sp_get_productid();	
  		break;
		
		case 'servic_type_count':
  		sp_servic_type_count();	
  		break;
		
		case 'customer_type_count':
  		sp_customer_type_count();	
  		break;
		
		case 'get_energy_smart_actuals':
  		sp_energy_smart_actuals();	
  		break;
		
		case 'get_energy_smart_goals':
  		sp_energy_smart_goals();	
  		break;	
		
		case 'graphinvoiceamount':
  		get_graphinvoiceamount();
  		break;	
		
		// Balu Created Oct - 22 // COMMON HEADER

	case 'get_sp_tbl_warrantyworkorder_two':
  		all_sp_tbl_warrantyworkorder_two();	
  		break;		
	case 'get_sp_tbl_customer_type_two':
  		all_sp_tbl_customer_type_two();	
  		break;	
	case 'get_sp_sel_tbl_warrantycustomers_two':
  		all_sp_sel_tbl_warrantycustomers_two();	
  		break;	
	case 'get_sp_sel_lkp_state_one':
  		all_sp_sel_lkp_state_one();	
  		break;	
		
		
		//Nov - 04 - 2013
		
	case 'get_all_products':
		get_all_products();
		break;
		
	case 'get_repair_details':
		get_repair_details();
		break;
	

///////////////////////////////////karuna//////////////////////////////////	karuna///////////////////////////////////
///bakkiyaraj/////

 case 'up_espi_three':
  	    sp_up_espi_three();
  		break;		
case 'invoice_quote_header': 
  		sp_uptbl_invoice_quote_header();
  		break;
 case 'get_sle_tbl_invoice_quote_header':
  		all_sle_tbl_invoice_quote_header();
  		break;
case 'up_tbl_customersone':
  		sp_up_tbl_customersone();	
  		break;
case 'sp_tbl_invoice_quote_headertwo':
  		sp_tbl_invoice_quote_header();	
  		break;
case 'get_sp_sle_two_lkp_productdepartment':
  		all_sp_sle_two_lkp_productdepartment();	
  		break;

case 'get_sp_sle_two_lkp_productdepartment1':
  		all_sp_sle_two_lkp_productdepartment1();	
  		break;
		
case 'get_sp_sle_two_lkp_productdepartment2':
  		all_sp_sle_two_lkp_productdepartment2();	
  		break;

case 'get_sp_sle_two_espi':
  		all_sp_sle_two_espi();
		break;
case 'get_sp_sle_three_tbl_invoice_quote_footer':
  		all_sp_sle_three_tbl_invoice_quote_footer();	
  		break;
case 'get_sp_sle_two_tbl_invoice_quote_footer':
  		all_sp_sle_two_tbl_invoice_quote_footer();	
  		break;
case 'get_sp_sle_one_tbl_invoice_quote_footer':
  		all_sp_sle_one_tbl_invoice_quote_footer();	
  		break;
case 'sp_ins_espi_all_ins': 
  		sp_ins_espi_all();
  		break;
case 'get_inst_tbl_invoice_quote_header':
  		all_inst_tbl_invoice_quote_header();
  		break;
case 'insert_tbl_invoice_quote_footer':
  		insert_tbl_invoice_quote_footer();
  		break;
case 'get_inst_tbl_invoice_quote_header_replacement':
  		get_inst_tbl_invoice_quote_header_replacement();
  		break;
case 'get_inst_tbl_invoice_quote_header_replacement1':
  		get_inst_tbl_invoice_quote_header_replacement1();
  		break;
case 'tbl_repairsolutionstwo': 
  		sp_tbl_repairsolutionstwo();
  		break;

case 'get_sp_sle_energy_savings':
  		all_sp_sle_energy_savings();	
  		break;	
case 'sp_sel_all_uploadedfiles':
  		sp_sel_tbl_all_uploadedfiles();	
  		break;
case 'get_upd_tbl_invoice_quote_header':
  		all_upd_tbl_invoice_quote_header();
  		break;	

case 'get_four_tbl_repairsolutions':
  		all_four_tbl_repairsolutions();
  		break;
case 'get_four_tbl_invoice_quote_header':
  		all_four_tbl_invoice_quote_header();
  		break;
case 'invoice_quote_footeramount':
  		sp_invoice_quote_footeramount();
  		break;
case 'quote_header_updatetwntyseven': 
  		tbl_invoice_quote_header_update();
  		break;
case 'up_customer_updone': 
  		sp_up_customer_updone();
  		break;
		
case 'up_customer_updfour': 
  		sp_tbl_four_update();
  		break;		
case 'sel_espi_quote': 
  		sp_sel_espi_quote();
  		break;
case 'get_four_tbl_furnace':
  		all_four_tbl_furnace();
  		break;
case 'get_four_tbl_filtration':
  		get_four_tbl_filtration();
  		break;	
case 'get_workorder_parts':
  		get_workorder_parts();
  		break;		
case 'get_four_tbl_filtration':
  		all_four_tbl_filtration();
  		break;

case 'get_four_tbl_furnace1':
  		all_four_tbl_furnace1();
  		break;
		
case 'get_four_tbl_furnace2':
  		all_four_tbl_furnace2();
  		break;
		
case 'sel_tbl_all_furnace_brand':
  		sp_sel_tbl_all_furnace_brand();
  		break;
case 'get_ins_ten_tbl_furnace':
  		all_ins_ten_tbl_furnace();
  		break;

case 'get_ins_ten_tbl_filtration':
  		all_ins_ten_tbl_filtration();
  		break;			

case 'get_nine_tbl_furnace':
  		all_nine_tbl_furnace();
  		break;

case 'get_nine_tbl_filtration':
  		all_nine_tbl_filtration();
  		break;
		
case 'get_three_tbl_invoice_quote_header':
  		all_three_tbl_invoice_quote_header();
  		break;
case 'get_tbl_furnaceone_getall':
  		tbl_furnaceone_getall();
  		break;

case 'get_tbl_filtrationone_getall':
  		tbl_filtrationone_getall();
  		break;
		
case 'get_upd_tbl_furnaceoneopne':
  		sp_upd_tbl_furnaceoneopneval();
  		break;

case 'get_upd_tbl_filtrationoneopne':
  		sp_upd_tbl_filtrationoneopneval();
  		break;
		
	///////////////////////////////////karuna//////////////////////////////////	karuna/////////////////////////////////// 
        case 'get_upd_tbl_repairreplace':
  		all_upd_tbl_repairreplace();
  		break;
		
		case 'get_inst_tbl_repairreplace':
  		all_inst_tbl_repairreplace();
  		break;
		
		case 'get_sle_three_tbl_repairreplace':
  		all_sle_three_tbl_repairreplace();
  		break;
		
		case 'get_sp_upd_espi_one':
  		all_sp_upd_espi_one();
  		break;
		
		case 'get_sp_tbl_uploadedfiles': 
  		all_sp_tbl_uploadedfiles();
  		break;
		
		case 'get_slect_all_records': 
  		all_get_slect_all_records();
  		break;
		
		case 'get_select_uploadedfiles':
  		all_select_uploadedfiles();	
  		break;
		
		case 'get_sp_upd_tbl_duct_work': 
  		all_sp_upd_tbl_duct_work();
  		break;
		
		case 'get_sp_ins_tbl_duct_work': 
  		all_sp_ins_tbl_duct_work();
  		break;
		
		case 'get_sp_sle_tbl_repairreplace_four':
  		all_sp_sle_tbl_repairreplace_four();	
  		break;
		
		case 'get_sp_tbl_duct_work': 
  		all_sp_tbl_duct_work();
  		break;
		
		case 'get_sp_update_tbl_repairsolutions_ten':
  		all_sp_update_tbl_repairsolutions_ten();
  		break;	
		
		case 'get_sp_insent_tbl__repairsolutions_ten':
  		all_sp_insent_tbl__repairsolutions_ten();
  		break;
		
		case 'get_sp_update_tbl_repairsolutions':
  		all_sp_update_tbl_repairsolutions();
  		break;
		
		case 'get_sp_insert_tbl_repairsolutions':
  		all_sp_insert_tbl_repairsolutions();
  		break;
		
		case 'get_upd_tbl_ten_repairsolutions':
  		all_upd_tbl_ten_repairsolutions();
  		break;
		
		case 'get_ins_tbl_repairsolutions':
  		all_ins_tbl_repairsolutions();
  		break;	
		
		case 'get_sel_tbl_invoice_quote_footer':
  		all_sel_tbl_invoice_quote_footer();
  		break;
		
		case 'get_sel_tbl_repairsolutions_one':
  		all_sel_tbl_repairsolutions_one();
  		break;
		
		case 'get_sel_tbl_three_invoice_quote_footer':
  		all_sel_tbl_three_invoice_quote_footer();
  		break;
		
		case 'get_ins_tbl_invoice_quote_footer':
  		all_ins_tbl_invoice_quote_footer();
  		break;
		
		case 'get_upd_tbl_invoice_quote_footer':
  		all_upd_tbl_invoice_quote_footer();
  		break;
		
		case 'get_update_tbl_invoice_quote_footer':
  		get_update_tbl_invoice_quote_footer();
  		break;
		
		case 'get_ins_ten_espi':
  		all_ins_ten_espi();
  		break;
		
		//Balu Nov - 08
		
		case 'get_three_tbl_customers':
  		all_three_tbl_customers();
  		break;	
		
	case 'get_sle_tbl_repairreplace':
  		all_sle_tbl_repairreplace();
  		break;
	
	case 'get_sle_energy_savings':
  		all_sle_energy_savings();
  		break;
		
	case 'get_all_products_details':
		get_all_products_details();
		break;
		
	
	case 'get_sp_tbl_invoice_quote_header_five':
  		all_sp_tbl_invoice_quote_header_five();	
  		break;
		
	case 'get_tbl_repairsolutions_three': 
  		sp_get_tbl_repairsolutions_three();
  		break;
	
	case 'get_ints_ten_tbl_repairreplace':
  		all_ints_ten_tbl_repairreplace();
  		break;
	
	case 'insert_tbl_repairsolutions':
  		insert_tbl_repairsolutions();
  		break;
	
	case 'sp_update_repair':
  		sp_update_repair();
  		break;
		
		case 'get_lead_sold':
  		get_lead_sold();
  		break;
		
		
		case 'map':
  		get_map();
  		break;
		
		case 'get_upgrade_upgoals':
  		sp_get_upgrade_upgoals();	
  		break;
		
		case 'get_discount_amount':
  		sp_get_discount_amount();	
  		break;
		
		case 'updatetime':
  		sp_updatetime();	
  		break;
		//Balu Nov - 08
		
		case 'get_vendors':
  		sp_vendors();	
  		break;
		
		case 'get_billto':
  		sp_billto();	
  		break;
		
		case 'get_parts_status':
  		sp_parts_status();	
  		break;
		
		case 'get_parts':
  		sp_parts();	
  		break;
		
				
		case 'check_parts':
  		sp_check_parts();	
  		break;
		
		case 'insert_parts':
  		sp_insert_parts();	
  		break;
		
		case 'insert_callran':
  		sp_insert_callran();	
  		break;
		
		case 'insert_callset':
  		sp_insert_callset();	
  		break;
		
		case 'get_twowhere_quote_footer':
  		sp_get_twowhere_quote_footer();	
  		break;
		
		case 'ins_quote_footer':
  		sp_ins_quote_footer();	
  		break;
		
		case 'del_invoice_quote_footer':
  		sp_del_invoice_quote_footer();	
  		break;
		
		case 'get_product':
  		sp_get_product();	
  		break;
		
		case 'ins_products':
  		sp_ins_products();	
  		break;
		
		case 'up_cust_home':
  		sp_up_cust_home();	
  		break;
		
		case 'get_repair_solution_values':
  		sp_repair_solution_values();	
  		break;
		
		case 'insert_solution':
  		sp_insert_solution();	
  		break;
		
		case 'update_solution':
  		sp_update_solution();	
  		break;
		
		case 'check_solproduct':
  		sp_check_solproduct();	
  		break;
		
		case 'delete_solproduct':
  		sp_delete_solproduct();	
  		break;
		
		case 'exist_repairsol':
  		sp_exist_repairsol();	
  		break;
		
		case 'updateopt_soltype':
  		sp_updateopt_soltype();	
  		break;
		
		case 'updateess_soltype':
  		sp_updateess_soltype();	
  		break;
		
		case 'updatecri_soltype':
  		sp_updatecri_soltype();	
  		break;
		
		case 'repair_solution':
  		sp_repair_solution();	
  		break;
		
		case 'get_sp_sle_one_tbl_invoice_quote_footer1':
  		all_sp_sle_one_tbl_invoice_quote_footer1();	
  		break;
		
		case 'goalgetrevenue':
  		sp_goalgetrevenue();	
  		break;
		
		case 'getgols':
  		sp_getgoals();	
  		break;
		
		
		case 'get_achivement':
  		sp_get_achivement();	
  		break;
		
		case 'get_appran':
  		sp_get_appran();	
  		break;
		
		case 'get_appset':
  		sp_get_appset();	
  		break;
		
		
		case 'get_horcommission':
  		sp_get_horcommission();	
  		break;
		
		case 'get_upgradecommission':
  		sp_get_upgradecommission();	
  		break;
		
		case 'get_esccommission':
  		sp_get_esccommission();	
  		break;
		
		case 'get_salescommission':
  		sp_get_salescommission();	
  		break;
		
		
		case 'get_upgraderevenue':
  		sp_get_upgraderevenue();	
  		break;
		
		case 'get_escrevenue':
  		sp_get_escrevenue();	
  		break;
		
		case 'get_salesrevenue':
  		sp_get_salesrevenue();	
  		break;
		
		case 'getworkorderservicetype':
  		sp_getworkorderservicetype();	
  		break;
		
		case 'get_salescommission':
  		sp_salescommission();	
  		break;
		
		case 'getcalls_report':
  		sp_getcalls_report();	
  		break;
		
		case 'getcustomer_report':
  		sp_getcustomer_report();	
  		break;
		
		case 'paystatus_update': 
  		sp_paystatus_update();	
  		break;
		
		case 'getservicecallrun': 
  		sp_getservicecallrun();	
  		break;
		
		case 'getappranset': 
  		sp_getappranset();	
  		break;
		
		case 'getgoal': 
  		sp_getgoal();	
  		break;
		
		case 'getalltarget': 
  		sp_getalltarget();	
  		break;
		
		case 'consultantsales': 
  		sp_consultantsales();	
  		break;
		
		case 'techsales': 
  		sp_techsales();	
  		break;
		
		case 'techsales1': 
  		sp_techsales1();	
  		break;
		
		case 'upgradeupdate': 
  		sp_upgradeupdate();	
  		break;
		
		case 'salesupdate': 
  		sp_salesupdate();	
  		break;
		
		case 'escupdate': 
  		sp_escupdate();	
  		break;
		
		case 'totalserviceupdate': 
  		sp_totalserviceupdate();	
  		break;
		
		case 'callsupdate': 
  		sp_callsupdate();	
  		break;
		
		case 'consultantsetupdate': 
  		sp_consultantsetupdate();	
  		break;
		
		case 'get_four_tbl_furnace3': 
  		all_four_tbl_furnace3();	
  		break;
		
		case 'update_discount_type': 
  		sp_update_discount_type();	
  		break;
		
		case 'get_condencer_valued1': 
  		sp_get_condencer_valued1();	
  		break;
		
		case 'getcommission': 
  		sp_getcommission();	
  		break;
		
		case 'get_customerreport': 
  		sp_get_customerreport();	
  		break;
		
		case 'get_customerreportesc': 
  		sp_get_customerreportesc();	
  		break;
		
		case 'get_customerreporthor': 
  		sp_get_customerreporthor();	
  		break;
		
		case 'get_appran1':
  		sp_get_appran1();	
  		break;
		
		case 'get_ref_emp_id':
  		sp_get_ref_emp_id();	
  		break;
		
		case 'get_get_serviceran':
  		sp_get_serviceran();	
  		break;
		
		case 'insert_callran1':
  		sp_insert_callran1();	
  		break;
		
		case 'insert_servicecallran':
  		sp_insert_servicecallran();	
  		break;
		
		case 'estimation_header_insert':
  		estimation_header_insert();	
  		break; 
		
		case 'estimation_header_update':
  		estimation_header_update();	
  		break;
		
		case 'estimation_footer_insert':
  		estimation_footer_insert();	
  		break;
		
		case 'get_estimation_data':
  		get_estimation_data();	
  		break;
		
		case 'get_estimation_footer_data_duplication':
  		get_estimation_footer_data_duplication();	
  		break;
		
		case 'estimation_footer_update':
  		estimation_footer_update();	
  		break;
		
		case 'estimation_footer_delete':
  		estimation_footer_delete();	
  		break;
		
		case 'update_tbl_invoice_quote_footer':
  		update_tbl_invoice_quote_footer();	
  		break;
		
		case 'get_employee_designation':
  		sp_get_employee_designation();	
  		break;
		
		case 'employee_geoloc_tracking':
  		employee_geoloc_tracking();	
  		break;
		
		case 'get_user_history':
  		get_user_history();	
  		break;
		
		case 'get_user_history_first':
  		get_user_history_first();	
  		break;
		
		case 'get_user_history_last':
  		get_user_history_last();	
  		break;
		
		case 'device_based_auth':
  		device_based_auth();
  		break;
		
		case 'device_based_info':
  		device_based_info();
  		break;
		
		case 'get_register_trusted_device':
  		get_register_trusted_device();
  		break; 
		
		case 'single_action_rendering':
  		single_action_rendering();
  		break;
		
		case 'single_chain_update':
  		single_chain_update();
  		break;
		
		case 'delete_associated_parts':
  		delete_associated_parts();
  		break;
		
		case 'sp_delete_products':
  		sp_delete_products();
  		break;
		
		case 'sp_delete_product_id':
  		sp_delete_product_id();
  		break;
		
		case 'product_lists':
  		product_lists();
  		break;
		
		case 'single_consultant_rendering':
  		single_consultant_rendering();
  		break;
		
		case 'single_acion_plan':
  		single_acion_plan();
  		break;
		
		default:
  		defa();	
		
  }
  	
	function sp_get_employee_designation(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
if (isset($_REQUEST['emp_id'])){$emp_id = $_REQUEST['emp_id'];	}else $emp_id 	= "";
		
		if(trim($emp_id) !="")
		{
$recs = db_iquery($connection,"SELECT B.designation FROM lkp_designation B INNER JOIN tbl_employee A ON B.designation_id = A.designation WHERE A.emp_id='".$emp_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_estimation_data(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];	}else $customer_id 	= "";
if (isset($_REQUEST['workorder_id']))	{$workorder_id = $_REQUEST['workorder_id'];	} else $workorder_id 	= "";
					
			
		if(trim($customer_id) !="" && trim($workorder_id) !="")
		{
$recs = db_iquery($connection,"select A.estimation_id,A.customer_id,A.workorder_id,A.discount,A.special_discount,A.solution_type,B.estimation_footer_id,B.product_quantity,B.product_id,B.product_unit_rate,B.product_cumulative_rate,B.optimal_type,B.essential_type,B.critical_type,c.product_name from estimation_header_table as A join estimation_footer_table as B on A.estimation_id=B.estimation_id join lkp_products as C on B.product_id=C.product_id and A.customer_id ='".$customer_id."' and A.workorder_id ='".$workorder_id."' ORDER BY B.estimation_footer_id asc")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_estimation_footer_data_duplication(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
if (isset($_REQUEST['estimation_id'])){$estimation_id = $_REQUEST['estimation_id'];	}else $estimation_id 	= "";
if (isset($_REQUEST['product_id']))	{$product_id = $_REQUEST['product_id'];	} else $product_id 	= "";
					
			
		if(trim($estimation_id) !="" && trim($product_id) !="")
		{
$recs = db_iquery($connection,"select estimation_footer_id from estimation_footer_table where estimation_id ='".$estimation_id."' and product_id ='".$product_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function estimation_header_insert(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id= "";
		if (isset($_REQUEST['workorder_id'])){$workorder_id = $_REQUEST['workorder_id'];}else $workorder_id= "";
		if (isset($_REQUEST['discount'])){$discount = $_REQUEST['discount'];	}else $discount = "";
		if (isset($_REQUEST['special_discount'])){$special_discount = $_REQUEST['special_discount'];	}else $special_discount = "";
		if (isset($_REQUEST['solution_type'])){$solution_type = $_REQUEST['solution_type'];	}else $solution_type = "";
		
		if(trim($customer_id) !="")
		{			
		$recs = db_iquery($connection,"CALL estimation_header_table('".$customer_id."','".$workorder_id."','".$discount."','".$special_discount."','".$solution_type."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}else{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Records is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function estimation_header_update(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id= "";
		if (isset($_REQUEST['workorder_id'])){$workorder_id = $_REQUEST['workorder_id'];}else $workorder_id= "";
		if (isset($_REQUEST['discount'])){$discount = $_REQUEST['discount'];	}else $discount = "";
		if (isset($_REQUEST['special_discount'])){$special_discount = $_REQUEST['special_discount'];	}else $special_discount = "";
		if (isset($_REQUEST['solution_type'])){$solution_type = $_REQUEST['solution_type'];	}else $solution_type = "";
		if (isset($_REQUEST['estimation_id'])){$estimation_id = $_REQUEST['estimation_id'];	}else $estimation_id = "";
		
		if(trim($customer_id) !="")
		{			
		$recs = db_iquery($connection,"UPDATE `estimation_header_table` SET `customer_id` = '".$customer_id."',`workorder_id` = '".$workorder_id."',`discount` = '".$discount."',`special_discount` = '".$special_discount."',`solution_type` = '".$solution_type."' WHERE estimation_id=".$estimation_id."")
			or die( mysql_error() ); // die ("invalid query");

				$output = array("errmsg"=>'Record Updated Successfully');
				$response['code'] = 1;
				$response['status'] = 200;
		}
		else
		{

			$output[] = array("errmsg"=>'Records is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function estimation_footer_insert(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['estimation_id'])){$estimation_id = $_REQUEST['estimation_id'];}else $estimation_id= "";
		if (isset($_REQUEST['product_quantity'])){$product_quantity = $_REQUEST['product_quantity'];}else $product_quantity	= "";
		if (isset($_REQUEST['product_id'])){$product_id = $_REQUEST['product_id'];	}else $product_id = "";
		if (isset($_REQUEST['product_unit_rate'])){$product_unit_rate = $_REQUEST['product_unit_rate'];	}else $product_unit_rate = "";
		if (isset($_REQUEST['product_cumulative_rate'])){$product_cumulative_rate = $_REQUEST['product_cumulative_rate'];}else $product_cumulative_rate = "";
		if (isset($_REQUEST['optimal_type'])){$optimal_type = $_REQUEST['optimal_type'];	}else $optimal_type = "";
		if (isset($_REQUEST['essential_type'])){$essential_type = $_REQUEST['essential_type'];	}else $essential_type = "";
		if (isset($_REQUEST['critical_type'])){$critical_type = $_REQUEST['critical_type'];	}else $critical_type = "";
		
		if(trim($estimation_id) !="")
		{			
		$recs = db_iquery($connection,"insert into `estimation_footer_table`(estimation_id,product_quantity,product_id,product_unit_rate,product_cumulative_rate,optimal_type,essential_type,critical_type)VALUES('".$estimation_id."','".$product_quantity."','".$product_id."','".$product_unit_rate."','".$product_cumulative_rate."','".$optimal_type."','".$essential_type."','".$critical_type."')")
			or die( mysql_error() ); // die ("invalid query");
			
			$output = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
		}
		else
		{

			$output[] = array("errmsg"=>'Records is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function estimation_footer_update(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['estimation_id'])){$estimation_id = $_REQUEST['estimation_id'];}else $estimation_id= "";
		if (isset($_REQUEST['product_quantity'])){$product_quantity = $_REQUEST['product_quantity'];}else $product_quantity	= "";
		if (isset($_REQUEST['product_id'])){$product_id = $_REQUEST['product_id'];	}else $product_id = "";
		if (isset($_REQUEST['product_unit_rate'])){$product_unit_rate = $_REQUEST['product_unit_rate'];	}else $product_unit_rate = "";
		if (isset($_REQUEST['product_cumulative_rate'])){$product_cumulative_rate = $_REQUEST['product_cumulative_rate'];}else $product_cumulative_rate = "";
		if (isset($_REQUEST['optimal_type'])){$optimal_type = $_REQUEST['optimal_type'];	}else $optimal_type = "";
		if (isset($_REQUEST['essential_type'])){$essential_type = $_REQUEST['essential_type'];	}else $essential_type = "";
		if (isset($_REQUEST['critical_type'])){$critical_type = $_REQUEST['critical_type'];	}else $critical_type = "";
		if (isset($_REQUEST['estimation_footer_id'])){$estimation_footer_id = $_REQUEST['estimation_footer_id'];	}else $estimation_footer_id = "";
		
		if(trim($estimation_id) !="" && trim($estimation_footer_id) !="")
		{			
		$recs = db_iquery($connection,"UPDATE `estimation_footer_table` SET `product_quantity` = '".$product_quantity."',`product_id` = '".$product_id."',`product_unit_rate` = '".$product_unit_rate."',`product_cumulative_rate` = '".$product_cumulative_rate."',`optimal_type` = '".$optimal_type."',`essential_type` = '".$essential_type."',`critical_type` = '".$critical_type."' WHERE estimation_footer_id=".$estimation_footer_id."")
			or die( mysql_error() ); // die ("invalid query");
						
			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
		}
		else
		{

			$output[] = array("errmsg"=>'Records is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function estimation_footer_delete(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['estimation_footer_id'])){$estimation_footer_id = $_REQUEST['estimation_footer_id'];}else $estimation_footer_id= "";	
		
		if(trim($estimation_footer_id) !="")
		{
		$recs = db_iquery($connection,"delete from estimation_footer_table where estimation_footer_id='".$estimation_footer_id."'")
			or die( mysql_error() ); // die ("invalid query");
				
			$output = array("errmsg"=>'Record Deleted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
		}
		else
		{

			$output[] = array("errmsg"=>'Records is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_customers_information() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_get_customers_information('".$subscriber_id."','".$company_id."','".$customer_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 
	function sp_get_service_type() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['quote_header_id']))
		{
			$quote_header_id = $_REQUEST['quote_header_id'];			
		}	
		else $quote_header_id 	= "";

		if(trim($quote_header_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_get_service_type('".$quote_header_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'quote_header_id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function sp_insert_servicecallran(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
				
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id 	= "";	
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id 	= "";
		if (isset($_REQUEST['workorder_id'])){$workorder_id = $_REQUEST['workorder_id'];}	else $workorder_id 	= "";
		if (isset($_REQUEST['emp_id'])){$emp_id = $_REQUEST['emp_id'];}	else $emp_id 	= "";
		if (isset($_REQUEST['set_date'])){$set_date = $_REQUEST['set_date'];}	else $set_date 	= "";
			
		if(trim($emp_id) !="")
		{
			$recs = db_iquery($connection,"insert into `tbl_calls`(subscriber_id,company_id,emp_id,workorder_id,service_call_ran,set_date)VALUES('".$subscriber_id."',".$company_id.",".$emp_id.",".$workorder_id.",'1','".$set_date."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Insert Successfully!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_insert_callran1(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
				
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id 	= "";	
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id 	= "";
		if (isset($_REQUEST['workorder_id'])){$workorder_id = $_REQUEST['workorder_id'];}	else $workorder_id 	= "";
		if (isset($_REQUEST['emp_id'])){$emp_id = $_REQUEST['emp_id'];}	else $emp_id 	= "";
		if (isset($_REQUEST['set_date'])){$set_date = $_REQUEST['set_date'];}	else $set_date 	= "";
			
		
		if(trim($emp_id) !="")
		{
			$recs = db_iquery($connection,"insert into `tbl_calls`(subscriber_id,company_id,emp_id,workorder_id,call_ran,set_date)VALUES('".$subscriber_id."',".$company_id.",".$emp_id.",".$workorder_id.",'1','".$set_date."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Insert Successfully!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	
	function sp_get_serviceran(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			$recs = db_iquery($connection,"SELECT sum(service_call_ran) as totalran from tbl_calls WHERE emp_id=".$employee_id." and DATE_FORMAT(set_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function sp_get_ref_emp_id(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
				
		if (isset($_REQUEST['workorder_id'])){$workorder_id = $_REQUEST['workorder_id'];} else $workorder_id 	= "";
		
		
		if(trim($workorder_id) !="")
		{
			$recs = db_iquery($connection,"SELECT all_emp from tbl_invoice_quote_header where quote_header_id =".$workorder_id."")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function sp_techsales1(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="" && $customer_id!='')
		{

$recs = db_iquery($connection,"SELECT tot_pay_amount from tbl_invoice_quote_header where all_emp=".$employee_id." and customer_id=".$customer_id." and payment_pending='' and workorder_newstatus = 'completed' and consultant_workorder='yes' and DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); 
			
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	
	function sp_get_appran1(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
				
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			$recs = db_iquery($connection,"SELECT count(*) as totalran from tbl_invoice_quote_header where workorder_technician =".$employee_id." and workorder_newstatus='completed' and consultant_workorder='' and  DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_customerreporthor(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$vdate = $_REQUEST['fromMonthYears'];			
		}	
		else $vdate 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
				
		if ($employee_id!='' && $customer_id!='' && $vdate!='')
	    {
			$recs = db_iquery($connection,"SELECT sum(((A.product_quanity * A.product_unit_price) - A.esc_savings)) as calls_report_hor FROM tbl_invoice_quote_footer A,tbl_invoice_quote_header B WHERE A.emp_id=".$employee_id." and A.prod_responsibility='HOR' and B.quote_header_id = A.header_id and B.workorder_newstatus = 'completed' and A.customer_id=".$customer_id." and A.wtype='No' and B.consultant_workorder='' and  DATE_FORMAT(B.invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
	    }
			else
			{
				$output[] = array("errmsg"=>'Argument is missing.');
				$response['status'] = 400;
			}
		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_customerreportesc(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$vdate = $_REQUEST['fromMonthYears'];			
		}	
		else $vdate 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
				
		if ($employee_id!='' && $customer_id!='' && $vdate!='')
	    {
			$recs = db_iquery($connection,"SELECT sum(((A.product_quanity * A.product_unit_price) - A.esc_savings)) as calls_report_esc FROM tbl_invoice_quote_footer A,tbl_invoice_quote_header B WHERE A.emp_id=".$employee_id." and A.prod_responsibility='ESC' and B.quote_header_id = A.header_id and B.workorder_newstatus = 'completed' and A.customer_id=".$customer_id." and A.wtype='No' and B.consultant_workorder='' and  DATE_FORMAT(B.invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
	    }
			else
			{
				$output[] = array("errmsg"=>'Argument is missing.');
				$response['status'] = 400;
			}
		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function sp_get_customerreport(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$vdate = $_REQUEST['fromMonthYears'];			
		}	
		else $vdate 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
				
		if ($employee_id!='' && $customer_id!='' && $vdate!='')
	    {
			$recs = db_iquery($connection,"SELECT sum(((A.product_quanity * A.product_unit_price) - A.esc_savings)) as calls_report_upgrade FROM tbl_invoice_quote_footer A,tbl_invoice_quote_header B WHERE A.emp_id=".$employee_id." and A.prod_responsibility='Upgrade' and B.quote_header_id = A.header_id and B.workorder_newstatus = 'completed' and A.customer_id=".$customer_id." and A.wtype='No' and B.consultant_workorder='' and  DATE_FORMAT(B.invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
	    }
			else
			{
				$output[] = array("errmsg"=>'Argument is missing.');
				$response['status'] = 400;
			}
		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function sp_getcommission(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['id']))
		{
			$id = $_REQUEST['id'];			
		}	
		else $id 	= "";
				
		if ($id!='')
	    {
			$recs = db_iquery($connection,"SELECT commission from tbl_goal where id=".$id."")
			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
	    }
			else
			{
				$output[] = array("errmsg"=>'Argument is missing.');
				$response['status'] = 400;
			}
		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function sp_get_condencer_valued1() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_id'],$_REQUEST['quote_id']))
  	{
  		 $subscriber_id = $_REQUEST['subscriber_id'];
		 $company_id = $_REQUEST['company_id'];
		 $customer_id =$_REQUEST['customer_id'];
  		 $quote_id = $_REQUEST['quote_id'];
  		
if(trim($subscriber_id!= "" && $company_id!= "" && $customer_id!= "" && $quote_id!= ""))
  	{	
		$recs = db_iquery($connection,"SELECT * FROM (tbl_furnace) WHERE subscriber_id = '".$subscriber_id."' AND company_id = ".$company_id." AND customer_id = ".$customer_id."  AND quote_id = ".$quote_id." AND acunit_br_one='condenser' AND status='active' order by furnace_id asc") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
											$output[] = $row;
  												}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
  	}
	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
	
	function sp_update_discount_type() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

	if(isset($_REQUEST['discount_type'])){ $discount_type = $_REQUEST['discount_type'];}else{$discount_type ='';}
	if(isset($_REQUEST['id'])){ $id = $_REQUEST['id'];}else{$id ='';}
	
if ($id!='')
	{
$recs = db_iquery($connection,"UPDATE `tbl_repairsolutions` SET `discount_type` = '".$discount_type."' WHERE id=".$id."") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
		
	function all_four_tbl_furnace3() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id  = $_REQUEST['customer_id'];			
		}	
		else $customer_id  	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id  = $_REQUEST['quote_id'];			
		}	
		else $quote_id  	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"SELECT * FROM (tbl_furnace) WHERE subscriber_id = '".$subscriber_id."' AND company_id = ".$company_id." AND customer_id = ".$customer_id."  AND quote_id = ".$quote_id."  AND acunit_br_one='condenser' AND status='active' order by furnace_id asc LIMIT 0,1")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id Or Quote Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_consultantsetupdate() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){$employee_id = $_REQUEST['employee_id'];}else $employee_id = "";
		if (isset($_REQUEST['set_actual'])){$set_actual = $_REQUEST['set_actual'];}else $set_actual	= "";
	
if ($employee_id!='')
	{
$recs = db_iquery($connection,"UPDATE `tbl_target` SET `actual_values` = '".$set_actual."' WHERE emp_id=".$employee_id." and service_name='Total Consultations Set #' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

	function sp_callsupdate() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		if (isset($_REQUEST['call_actual'])){$call_actual = $_REQUEST['call_actual'];}else $call_actual 	= "";
	
if ($employee_id!='')
	{
$recs = db_iquery($connection,"UPDATE `tbl_target` SET `actual_values` = '".$call_actual."' WHERE emp_id=".$employee_id." and service_name='Total Dispatches #' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

	function sp_totalserviceupdate() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		if (isset($_REQUEST['totalservice_actual'])){$totalservice_actual = $_REQUEST['totalservice_actual'];}else $totalservice_actual 	= "";
	
if ($employee_id!='')
	{
$recs = db_iquery($connection,"UPDATE `tbl_target` SET `actual_values` = '".$totalservice_actual."' WHERE emp_id=".$employee_id." and service_name='Total Service Revenue ($)' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
	
	function sp_escupdate() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		if (isset($_REQUEST['esc_actual'])){$esc_actual = $_REQUEST['esc_actual'];}else $esc_actual 	= "";
	
if ($employee_id!='')
	{
$recs = db_iquery($connection,"UPDATE `tbl_target` SET `actual_values` = '".$esc_actual."' WHERE emp_id=".$employee_id." and service_name='ESC Membership ($)' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

	function sp_salesupdate() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		if (isset($_REQUEST['sales_actual'])){$sales_actual = $_REQUEST['sales_actual'];}else $sales_actual 	= "";
	
if ($employee_id!='')
	{
$recs = db_iquery($connection,"UPDATE `tbl_target` SET `actual_values` = '".$sales_actual."' WHERE emp_id=".$employee_id." and service_name='Total Consultation Sales ($)' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
	
	function sp_upgradeupdate() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		if (isset($_REQUEST['upgarde_actual'])){$upgarde_actual = $_REQUEST['upgarde_actual'];}else $upgarde_actual 	= "";
	
if ($employee_id!='')
	{
$recs = db_iquery($connection,"UPDATE `tbl_target` SET `actual_values` = '".$upgarde_actual."' WHERE emp_id=".$employee_id." and service_name='Upgrade ($)' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
    
  
  	
	
	function sp_paystatus_update() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

	if(isset($_REQUEST['quote_header_id'])){ $header_id = $_REQUEST['quote_header_id'];}else{$header_id ='';}
	if(isset($_REQUEST['paystatus'])){ $paystatus = $_REQUEST['paystatus'];}else{$paystatus ='';}
	
if ($header_id!='')
	{
$recs = db_iquery($connection,"UPDATE `tbl_invoice_quote_header` SET `paystatus` = '".$paystatus."' WHERE quote_header_id=".$header_id."") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

	function sp_getcustomer_report(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
			
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id 	= "";
		
		if(trim($customer_id) !="")
		{
		$recs = db_iquery($connection,"SELECT firstname,lastname from tbl_customers WHERE customer_id =".$customer_id."")
			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_getcalls_report(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
$recs = db_iquery($connection,"SELECT * from tbl_invoice_quote_header WHERE invoice_technician =".$employee_id." and consultant_workorder='' and workorder_newstatus='completed' and DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_salescommission(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			$recs = db_iquery($connection,"SELECT sum(tot_pay_amount) as sales_comm FROM `tbl_invoice_quote_header` WHERE consultant_workorder= 'yes' and DATE_FORMAT(workorder_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_getworkorderservicetype(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		if (isset($_REQUEST['servicetype'])){	$servicetype = $_REQUEST['servicetype'];}else $servicetype 	= "";
		
		
		if(trim($employee_id) !="" && trim($vdate) !="" && $servicetype!='')
		{
//$recs = db_iquery($connection,"SELECT COUNT(*) as numcall FROM tbl_invoice_quote_header WHERE invoice_remark='".$servicetype."' and all_emp	=".$employee_id."  and DATE_FORMAT(workorder_created_on,'%Y-%m')='".$vdate."'")

$recs = db_iquery($connection,"SELECT COUNT(*) as numcall FROM tbl_invoice_quote_header WHERE invoice_remark='".$servicetype."' and invoice_technician=".$employee_id." and workorder_newstatus='completed'  and DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")

			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_salesrevenue(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
$recs = db_iquery($connection,"SELECT sum(product_total_amount) as salescommission from  tbl_invoice_quote_footer WHERE prod_responsibility='Sales' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_escrevenue(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
$recs = db_iquery($connection,"SELECT sum(product_total_amount) as esccommission from  tbl_invoice_quote_footer WHERE prod_responsibility='ESC' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
										
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	
	function sp_get_upgraderevenue(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
							
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
$recs = db_iquery($connection,"SELECT sum(product_total_amount) as upgradecommission from  tbl_invoice_quote_footer WHERE prod_responsibility='Upgrade' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'")
										
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	
	function sp_get_salescommission(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
$recs = db_iquery($connection,"SELECT ((sum(product_total_amount)/100)*3)  as salescommission from  tbl_invoice_quote_footer WHERE prod_responsibility='Sales' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_consultantsales(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
/*$recs = db_iquery($connection,"SELECT sum(total_cost) as total_sales from  tbl_invoice_quote_header  WHERE workorder_newstatus='completed' and consultant_workorder='yes' and DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() );*/
			
$recs = db_iquery($connection,"select sum(((A.product_quanity * A.product_unit_price) - A.esc_savings)) as totalsales_achived FROM tbl_invoice_quote_footer A,tbl_invoice_quote_header B WHERE B.workorder_newstatus='completed' and A.emp_id=".$employee_id." and (A.prod_department =1 OR A.prod_department =2 OR A.prod_department =3 OR A.prod_department =7) and A.wtype='No' and B.consultant_workorder='yes' and  DATE_FORMAT(B.invoice_date,'%Y-%m')='".$vdate."';")
			or die( mysql_error() ); 
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_techsales(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
/*$recs = db_iquery($connection,"SELECT sum(total_cost) as total_sales from  tbl_invoice_quote_header  WHERE workorder_newstatus='completed' and consultant_workorder='yes' and DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() );*/
			
/*$recs = db_iquery($connection,"select sum(((A.product_quanity * A.product_unit_price) - A.esc_savings)) as totalsales_achived FROM tbl_invoice_quote_footer A,tbl_invoice_quote_header B WHERE B.workorder_newstatus='completed' and A.emp_id=".$employee_id." and (A.prod_department =1 OR A.prod_department =2 OR A.prod_department =3 OR A.prod_department =7) and A.wtype='No' and B.consultant_workorder='' and  DATE_FORMAT(B.invoice_date,'%Y-%m')='".$vdate."';")
			or die( mysql_error() ); */
			
$recs = db_iquery($connection,"SELECT tot_pay_amount from tbl_invoice_quote_header where all_emp=".$employee_id." and payment_pending='' and workorder_newstatus = 'completed' and consultant_workorder='yes' and DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); 
			
									
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	/*function sp_get_esccommission(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
$recs = db_iquery($connection,"SELECT ((sum(product_total_amount)/100)*16) as esccommission from  tbl_invoice_quote_footer WHERE prod_responsibility='ESC' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
										
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}*/
	
	function sp_get_esccommission(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
/*$recs = db_iquery($connection,"SELECT sum(product_total_amount) as esccommission from  tbl_invoice_quote_footer WHERE prod_responsibility='ESC' and emp_id=".$employee_id." and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");*/
			
			$recs = db_iquery($connection,"SELECT sum(((A.product_quanity * A.product_unit_price) - A.esc_savings)) as esccommissions FROM tbl_invoice_quote_footer A,tbl_invoice_quote_header B WHERE A.emp_id=".$employee_id." and A.prod_responsibility='ESC' and B.quote_header_id = A.header_id and B.workorder_newstatus = 'completed' and DATE_FORMAT(A.created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	/*function sp_get_upgradecommission(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
$recs = db_iquery($connection,"SELECT ((sum(product_total_amount)/100)*16)  as upgradecommission from  tbl_invoice_quote_footer WHERE prod_responsibility='Upgrade' and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'")
										
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}*/
	
	function sp_get_upgradecommission(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
				
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
		/*$recs = db_iquery($connection,"SELECT sum(product_total_amount) as upgradecommission from tbl_invoice_quote_footer WHERE prod_responsibility='Upgrade' and emp_id=".$employee_id." and DATE_FORMAT(created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");*/
			
			$recs = db_iquery($connection,"SELECT sum(((A.product_quanity * A.product_unit_price) - A.esc_savings)) as upgradecommission FROM tbl_invoice_quote_footer A,tbl_invoice_quote_header B WHERE A.emp_id=".$employee_id." and A.prod_responsibility='Upgrade' and B.quote_header_id = A.header_id and B.workorder_newstatus = 'completed' and DATE_FORMAT(A.created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			
			
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_horcommission(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
$recs = db_iquery($connection,"SELECT ((sum(A.product_total_amount)/100)*10) as horcommission from tbl_invoice_quote_footer A,tbl_invoice_quote_header B  WHERE prod_responsibility='HOR'and B.quote_header_id = A.header_id and B.workorder_newstatus = 'completed' and emp_id='".$employee_id."' and DATE_FORMAT(A.created_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	
	
	function sp_get_appset(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){ $employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			$recs = db_iquery($connection,"SELECT sum(call_set) as totalset from tbl_calls WHERE emp_id=".$employee_id." and DATE_FORMAT(set_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_appran(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			$recs = db_iquery($connection,"SELECT sum(call_ran) as totalran from tbl_calls WHERE emp_id=".$employee_id." and DATE_FORMAT(set_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_achivement(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			/*$recs = db_iquery($connection,"SELECT sum(tot_pay_amount) as achiveamount from  tbl_invoice_quote_header WHERE ref_tech=".$employee_id." and DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() ); */
			
			$recs = db_iquery($connection,"SELECT part_payment as achiveamount from tbl_invoice_quote_header WHERE invoice_technician=".$employee_id." and workorder_newstatus='completed' and consultant_workorder='' and DATE_FORMAT(invoice_date,'%Y-%m')='".$vdate."'")
			or die( mysql_error() );
					
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_insert_callset(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
				
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id 	= "";	
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id 	= "";
		if (isset($_REQUEST['workorder_id'])){$workorder_id = $_REQUEST['workorder_id'];}	else $workorder_id 	= "";
		if (isset($_REQUEST['emp_id'])){$emp_id = $_REQUEST['emp_id'];}	else $emp_id 	= "";
		if (isset($_REQUEST['set_date'])){$set_date = $_REQUEST['set_date'];}	else $set_date 	= "";
		
		if(trim($emp_id) !="")
		{
			$recs = db_iquery($connection,"insert into `tbl_calls`(subscriber_id,company_id,emp_id,workorder_id,call_ran,set_date)VALUES('".$subscriber_id."',".$company_id.",".$emp_id.",".$workorder_id.",'1','".$set_date."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Insert Successfully!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_insert_callran(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
				
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id 	= "";	
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id 	= "";
		if (isset($_REQUEST['workorder_id'])){$workorder_id = $_REQUEST['workorder_id'];}	else $workorder_id 	= "";
		if (isset($_REQUEST['emp_id'])){$emp_id = $_REQUEST['emp_id'];}	else $emp_id 	= "";
		if (isset($_REQUEST['set_date'])){$set_date = $_REQUEST['set_date'];}	else $set_date 	= "";
			
		
		if(trim($emp_id) !="")
		{
			$recs = db_iquery($connection,"insert into `tbl_calls`(subscriber_id,company_id,emp_id,workorder_id,call_set,set_date)VALUES('".$subscriber_id."',".$company_id.",".$emp_id.",".$workorder_id.",'1','".$set_date."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Insert Successfully!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	/*function sp_getgoals(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
			
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_goals` WHERE emp_id='".$employee_id."' and month_year='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}*/
	
	function sp_getgoals(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
			
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_target` WHERE emp_id=".$employee_id." and created_date = '".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	/*function sp_goalgetrevenue(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_setgoals` WHERE emp_id='".$employee_id."' and dates='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}*/
	
	function sp_goalgetrevenue(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
		$recs = db_iquery($connection,"SELECT target_values FROM `tbl_target` WHERE emp_id='".$employee_id."' and created_date='".$vdate."' and service_name='Total Service Revenue ($)'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_getservicecallrun(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
		$recs = db_iquery($connection,"SELECT target_values,max_value FROM `tbl_target` WHERE emp_id='".$employee_id."' and created_date='".$vdate."' and service_name='Total Dispatches #'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_getappranset(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
		$recs = db_iquery($connection,"SELECT target_values,max_value FROM `tbl_target` WHERE emp_id='".$employee_id."' and created_date='".$vdate."' and service_name='Total Consultations Set #'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_getgoal(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
				
		
		$recs = db_iquery($connection,"SELECT * FROM `tbl_goal`")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		
		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_getalltarget(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		
		if (isset($_REQUEST['fromMonthYears'])){$vdate = $_REQUEST['fromMonthYears'];} else $vdate 	= "";
		if (isset($_REQUEST['employee_id'])){	$employee_id = $_REQUEST['employee_id'];}else $employee_id 	= "";
		
		if(trim($employee_id) !="" && trim($vdate) !="")
		{
		$recs = db_iquery($connection,"SELECT * FROM `tbl_target` WHERE emp_id='".$employee_id."' and created_date='".$vdate."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function all_sp_sle_one_tbl_invoice_quote_footer1() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";
		
		if (isset($_REQUEST['opt_type']))
		{
			$opt_type = $_REQUEST['opt_type'];			
		}	
		else $opt_type 	= "";	
					
		if(trim($header_id) != ""  )
		{
			$recs = db_iquery($connection,"SELECT * FROM (tbl_invoice_quote_footer) WHERE header_id = ".$header_id." AND (radio_check='".$opt_type."' OR radio_check = 1 OR radio_check = 3)  AND radio_check !=''")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Header Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function sp_invoice_quote_footeramount(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
			
		if (isset($_REQUEST['header_id'])){	$header_id = $_REQUEST['header_id'];}else $header_id 	= "";
		if (isset($_REQUEST['opts'])){$opts = $_REQUEST['opts'];}else $opts = "";				
							
		if(trim($header_id) !="" && trim($opts) !="")
		{
			/*$recs = db_iquery($connection,"SELECT SUM(product_total_amount) as totalamount FROM tbl_invoice_quote_footer WHERE header_id = '".$header_id."' and (radio_check='".$opts."' or radio_check=1) and (prod_responsibility <>'FA' and prod_responsibility <>'AHS')")*/
			$recs = db_iquery($connection,"SELECT SUM(product_total_amount) as totalamount FROM tbl_invoice_quote_footer WHERE header_id = '".$header_id."' and (radio_check='".$opts."' or radio_check=1) and (wtype <>'Yes')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_repair_solution(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		if (isset($_REQUEST['id'])){ $id = $_REQUEST['id'];}else $id = "";
			
		if(trim($id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_repairsolutions` WHERE id=".$id."")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function sp_updateopt_soltype() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['header_id']))
	{

$recs = db_iquery($connection,"UPDATE `tbl_invoice_quote_footer` SET `radio_check` = 'Opt Check' WHERE  header_id=".$_REQUEST['header_id']." AND `opt_yesno` = '1'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function sp_updateess_soltype() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['header_id']))
	{

$recs = db_iquery($connection,"UPDATE `tbl_invoice_quote_footer` SET `radio_check` = 'Ess Check' WHERE header_id=".$_REQUEST['header_id']." AND `ess_yesno` = '1'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function sp_updatecri_soltype() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['header_id']))
	{

$recs = db_iquery($connection,"UPDATE `tbl_invoice_quote_footer` SET `radio_check` = 'Cri Check' WHERE header_id=".$_REQUEST['header_id']." AND `cri_yesno` = '1'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
    

	function sp_exist_repairsol(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
			
		if (isset($_REQUEST['header_id'])){	$header_id = $_REQUEST['header_id'];}else $header_id 	= "";
					
			
		if(trim($header_id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_invoice_quote_footer` WHERE header_id=".$header_id." AND add_line = 2")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

	function sp_delete_solproduct(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
					
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";				
		
				
		if(trim($header_id) !="")
		{
				
			$recs = db_iquery($connection,"DELETE FROM `tbl_invoice_quote_footer` WHERE header_id='".$header_id."' AND add_line = 2")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_delete_products(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 1;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
					
		if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	= "";				
		
				
		if(trim($workorder_id) !="")
		{
				
			$recs = db_iquery($connection,"DELETE FROM `tbl_invoice_quote_footer` WHERE header_id='".$workorder_id."'")
			or die( mysql_error() ); // die ("invalid query");
	
				$response['code'] = 1;
				$response['status'] = 200;
				$output[] = array("errmsg"=>'Records deleted.');

		}
		else
		{

			$output[] = array("errmsg"=>'ID Missed');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_delete_product_id(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 1;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
					
		if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	= "";
		
		if (isset($_REQUEST['footer_id']))
		{
			$footer_id = $_REQUEST['footer_id'];			
		}	
		else $footer_id 	= "";				
		
				
		if(trim($workorder_id) !="" && trim($footer_id) !="")
		{
				
			$recs = db_iquery($connection,"DELETE FROM `tbl_invoice_quote_footer` WHERE header_id='".$workorder_id."' AND quote_footer_id='".$footer_id."'")
			or die( mysql_error() ); // die ("invalid query");
				$response['code'] = 1;
				$response['status'] = 200;
				$output[] = array("errmsg"=>'Records deleted.');

		}
		else
		{

			$output[] = array("errmsg"=>'ID Missed');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_check_solproduct(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['header_id'])){	$header_id = $_REQUEST['header_id'];}else $header_id 	= "";
		if (isset($_REQUEST['product_des'])){$product_des = $_REQUEST['product_des'];}else $product_des 	= "";	
		if (isset($_REQUEST['products_id'])){$products_id = $_REQUEST['products_id'];}else $products_id 	= "";			
		
		if(trim($header_id) !="" && trim($product_des) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_invoice_quote_footer` WHERE header_id='".$header_id."' and product_des='".$product_des."' and product_id='".$products_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_insert_solution(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 1;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
				
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id 	= "";
		if (isset($_REQUEST['emp_id'])){$emp_id = $_REQUEST['emp_id'];}else $emp_id	= "";
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id	= "";
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id 	= "";
		if (isset($_REQUEST['header_id'])){$header_id = $_REQUEST['header_id'];}	else $header_id 	= "";
		if (isset($_REQUEST['product_id'])){$product_id = $_REQUEST['product_id'];}else $product_id	= "";
		if (isset($_REQUEST['product_des'])){$product_des = $_REQUEST['product_des'];	}else $product_des = "";
		if (isset($_REQUEST['product_quanity'])){$product_quanity = $_REQUEST['product_quanity'];	}else $product_quanity = "";
		if (isset($_REQUEST['product_unit_price'])){$product_unit_price = $_REQUEST['product_unit_price'];	}else $product_unit_price = "";
		if (isset($_REQUEST['product_total_amount'])){$product_total_amount = $_REQUEST['product_total_amount'];}else $product_total_amount = "";
		if (isset($_REQUEST['prod_responsibility'])){$prod_responsibility = $_REQUEST['prod_responsibility'];}else $prod_responsibility = "";
		if (isset($_REQUEST['prod_department'])){$prod_department = $_REQUEST['prod_department'];}else $prod_department = 0;
		if (isset($_REQUEST['wtype'])){$wtype = $_REQUEST['wtype'];	}else $wtype = "";
		if (isset($_REQUEST['opt_yesno'])){$opt_yesno = $_REQUEST['opt_yesno'];	}else $opt_yesno = "";
		if (isset($_REQUEST['ess_yesno'])){$ess_yesno = $_REQUEST['ess_yesno'];	}else $ess_yesno = "";
		if (isset($_REQUEST['cri_yesno'])){$cri_yesno = $_REQUEST['cri_yesno'];	}else $cri_yesno = "";
		if (isset($_REQUEST['add_line'])){$add_line = $_REQUEST['add_line'];	}else $add_line = "";
		if (isset($_REQUEST['radio_check'])){$radio_check = $_REQUEST['radio_check'];	}else $radio_check = "";
		
			
		if(trim($header_id) !="")
		{
		$recs = db_iquery($connection,"insert into `tbl_invoice_quote_footer`(company_id,emp_id,customer_id,subscriber_id,header_id,product_id,product_des,radio_check,product_quanity,product_unit_price,product_total_amount,prod_responsibility,prod_department,opt_yesno,ess_yesno,cri_yesno,add_line,wtype)VALUES(".$company_id.",".$emp_id.",".$customer_id.",'".$subscriber_id."',".$header_id.",".$product_id.",'".$product_des."','".$radio_check."',".$product_quanity.",".$product_unit_price.",".$product_total_amount.",'".$prod_responsibility."',".$prod_department.",'".$opt_yesno."','".$ess_yesno."','".$cri_yesno."','".$add_line."','".$wtype."')")
			or die( mysql_error() ); // die ("invalid query");
			
				$output[] = array("errmsg"=>'Record Insert Successfully!');
				$response['status'] = 200;
			
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_update_solution() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['quote_footer_id']))
	{

$recs = db_iquery($connection,"UPDATE `tbl_invoice_quote_footer` SET `product_id` = ".$_REQUEST['product_id'].",`product_des` = '".$_REQUEST['product_des']."',`product_quanity` = '".$_REQUEST['product_quanity']."',product_unit_price=".$_REQUEST['product_unit_price'].",product_total_amount=".$_REQUEST['product_total_amount'].",prod_reponssibility='".$_REQUEST['prod_reponssibility']."',prod_department='".$_REQUEST['prod_department']."',opt_yesno='".$_REQUEST['opt_yesno']."',ess_yesno='".$_REQUEST['ess_yesno']."',cri_yesno='".$_REQUEST['cri_yesno']."' WHERE `quote_footer_id` = '".trim($_REQUEST['quote_footer_id'])."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  } 
  
  
  function sp_tbl_four_update() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id']))
  	{
$recs = db_iquery($connection,"CALL sp_tbl_customer_four_update('".trim($_REQUEST['new_address'])."','".trim($_REQUEST['city'])."','".trim($_REQUEST['state'])."','".trim($_REQUEST['zip'])."','".trim($_REQUEST['customer_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  } 

	function sp_repair_solution_values(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];	}else $subscriber_id 	= "";
		if (isset($_REQUEST['company_id']))	{$company_id = $_REQUEST['company_id'];	} else $company_id 	= "";
		if (isset($_REQUEST['quote_footer_id'])){$quote_footer_id = $_REQUEST['quote_footer_id'];}	else $quote_footer_id 	= "";
		if (isset($_REQUEST['header_id'])){	$header_id = $_REQUEST['header_id'];}else $header_id 	= "";
		if (isset($_REQUEST['add_line'])){$add_line = $_REQUEST['add_line'];}else $add_line 	= "";				
			
		if(trim($header_id) !="" && trim($add_line) !="")
		{
$recs = db_iquery($connection,"SELECT * FROM `tbl_invoice_quote_footer` WHERE header_id='".$header_id."' and add_line='".$add_line."' ORDER BY quote_footer_id asc")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
     
	function all_upd_tbl_invoice_quote_footer() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['quote_footer_id']))
	{

$recs = db_iquery($connection,"UPDATE `tbl_invoice_quote_footer` SET `product_quanity` = '".$_REQUEST['product_quanity']."',product_unit_price='".$_REQUEST['product_unit_price']."',product_total_amount='".$_REQUEST['product_total_amount']."',discount='".$_REQUEST['discount']."',esc_savings='".$_REQUEST['esc_savings']."',prod_responsibility='".$_REQUEST['prod_responsibility']."',prod_department='".$_REQUEST['prod_department']."',wtype='".$_REQUEST['wtype']."' WHERE `quote_footer_id` = '".trim($_REQUEST['quote_footer_id'])."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  } 
	
	function sp_up_cust_home() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['customer_id']))
	{

$recs = db_iquery($connection,"UPDATE `tbl_customers` SET `ageof_home` = '".$_REQUEST['living']."',sqft='".$_REQUEST['sqft']."',home_owner='".$_REQUEST['home_build']."' WHERE `customer_id` = '".trim($_REQUEST['customer_id'])."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
	
	function sp_get_product(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
					
		if (isset($_REQUEST['product_name']))
		{
			$product_name = $_REQUEST['product_name'];			
		}	
		else $product_name 	= "";				
		
		if (isset($_REQUEST['product_id']))
		{
			$product_id = $_REQUEST['product_id'];			
		}	
		else $product_id 	= "";
		
		
		
		if(trim($product_name) !="" && trim($product_id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `lkp_products` WHERE product_name='".$product_name."' and product_id='".$product_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_ins_products() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['product_name'],$_REQUEST['product_price'],$_REQUEST['service_type']))
  	{

$recs = db_iquery($connection,"CALL sp_ins_product('".trim($_REQUEST['product_name'])."','".trim($_REQUEST['product_price'])."','".trim($_REQUEST['service_type'])."','".trim($_REQUEST['product_number'])."','".trim($_REQUEST['product_des'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			
			while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			$response['code'] = 1;
			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  
   
	
	function sp_del_invoice_quote_footer(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
					
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";				
		
				
		if(trim($header_id) !="")
		{
				
			$recs = db_iquery($connection,"DELETE FROM `tbl_invoice_quote_footer` WHERE header_id='".$header_id."' AND radio_check !=1 AND radio_type !=2")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_get_twowhere_quote_footer(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
					
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";				
		
		if (isset($_REQUEST['radio_check']))
		{
			$radio_check = $_REQUEST['radio_check'];			
		}	
		else $radio_check 	= "";
		
			
		if(trim($header_id) !="" && trim($radio_check) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_invoice_quote_footer` WHERE header_id='".$header_id."' and radio_check='".$radio_check."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_ins_quote_footer(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 1;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id 	= "";	
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id 	= "";
		if (isset($_REQUEST['header_id'])){$header_id = $_REQUEST['header_id'];}	else $header_id 	= "";
		if (isset($_REQUEST['product_id'])){$product_id = $_REQUEST['product_id'];}else $product_id	= "";
		if (isset($_REQUEST['product_des'])){$product_des = $_REQUEST['product_des'];	}else $product_des = "";
		if (isset($_REQUEST['radio_check'])){$radio_check = $_REQUEST['radio_check'];	}else $radio_check = "";
		if (isset($_REQUEST['product_quanity'])){$product_quanity = $_REQUEST['product_quanity'];	}else $product_quanity = "";
		if (isset($_REQUEST['product_unit_price'])){$product_unit_price = $_REQUEST['product_unit_price'];	}else $product_unit_price = "";
		
		if (isset($_REQUEST['net_customer_cost'])){$net_customer_cost = $_REQUEST['net_customer_cost'];	}else $net_customer_cost = "";
		if (isset($_REQUEST['discount'])){$discount = $_REQUEST['discount'];	}else $discount = "";
		if (isset($_REQUEST['esc_savings'])){$esc_savings = $_REQUEST['esc_savings'];	}else $esc_savings = "";
		if (isset($_REQUEST['product_type'])){$product_type = $_REQUEST['product_type'];	}else $product_type = "";
		if (isset($_REQUEST['product_total_amount'])){$product_total_amount = $_REQUEST['product_total_amount'];	}else $product_total_amount = "";
		if (isset($_REQUEST['prod_responsibility'])){$prod_responsibility = $_REQUEST['prod_responsibility'];	}else $prod_responsibility = "";
		if (isset($_REQUEST['prod_department'])){$prod_department = $_REQUEST['prod_department'];	}else $prod_department = "";
		
		
		if(trim($header_id) !="")
		{
			$recs = db_iquery($connection,"insert into `tbl_invoice_quote_footer`(company_id,subscriber_id,header_id,product_id,product_des,radio_check,product_quanity,product_unit_price,net_customer_cost,discount,esc_savings,product_type,product_total_amount,prod_responsibility,prod_department)VALUES(".$company_id.",'".$subscriber_id."',".$header_id.",".$product_id.",'".$product_des."','".$radio_check."',".$product_quanity.",".$product_unit_price.",".$net_customer_cost.",".$discount.",".$esc_savings.",".$product_type.",".$product_total_amount.",'".$prod_responsibility."',".$prod_department.")")
			or die( mysql_error() ); // die ("invalid query");
			
			
				$output[] = array("errmsg"=>'Record Insert Successfully!');
				$response['status'] = 200;
			
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function sp_check_parts(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";				
		
		if (isset($_REQUEST['description']))
		{
			$description = $_REQUEST['description'];			
		}	
		else $description 	= "";
		
		if (isset($_REQUEST['part']))
		{
			$part = $_REQUEST['part'];			
		}	
		else $part 	= "";
		
		
		if(trim($header_id) !="" && trim($description) !="" && trim($part) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `workorder_parts` WHERE workorder_no='".$header_id."' and description='".$description."' and part='".$part."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_insert_parts(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['workorder_no'])){$workorder_no = $_REQUEST['workorder_no'];}else $workorder_no 	= "";	
		if (isset($_REQUEST['part_qty'])){$part_qty = $_REQUEST['part_qty'];}else $part_qty 	= "";
		if (isset($_REQUEST['description'])){$description = $_REQUEST['description'];}	else $description 	= "";
		if (isset($_REQUEST['part'])){$part = $_REQUEST['part'];}else $part	= "";
		if (isset($_REQUEST['vendor_id'])){$vendor_id = $_REQUEST['vendor_id'];	}else $vendor_id = "";
		if (isset($_REQUEST['bill_to_id'])){$bill_to_id = $_REQUEST['bill_to_id'];	}else $bill_to_id = "";
		if (isset($_REQUEST['status_id'])){$status_id = $_REQUEST['status_id'];	}else $status_id = "";
		
		
		if(trim($description) !="" && trim($part) !="")
		{
			$recs = db_iquery($connection,"insert into workorder_parts(workorder_no,part_qty,description,part,vendor_id,bill_to_id,status_id)VALUES('".$workorder_no."','".$part_qty."','".$description."','".$part."',".$vendor_id.",".$bill_to_id.",".$status_id.")")
			or die( mysql_error() ); // die ("invalid query");
			
				$response['code'] = 1;
				$response['status'] = 200;
				$output[] = array("errmsg"=>'Record Inserted Successfully');
		}
		else
		{
$response['code'] = 1;
$response['status'] = 400;
			$output[] = array("errmsg"=>'Data missed');
			
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	
	
	
	
	function sp_vendors(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($subscriber_id) !="" && trim($company_id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_vendors` WHERE subscriber_id='".$subscriber_id."' and company_id='".$company_id."' and status='Yes'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_billto(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($subscriber_id) !="" && trim($company_id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_workorder_bill_to` WHERE subscriber_id='".$subscriber_id."' and company_id='".$company_id."' and status='Yes'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_parts_status(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($subscriber_id) !="" && trim($company_id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `tbl_workorder_parts` WHERE subscriber_id='".$subscriber_id."' and company_id='".$company_id."' and status='Yes'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_parts(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";				
		
		
		
		
		if(trim($quote_id) !="")
		{
			$recs = db_iquery($connection,"SELECT id,workorder_no,part_qty,description,part,vendor_id,bill_to_id,status_id FROM `workorder_parts` WHERE workorder_no='".$quote_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

    function sp_updatetime() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['customer_id']) && isset($_REQUEST['workorder_id']))
	{
if($_REQUEST['customer_id']!="" && $_REQUEST['workorder_id']!="") {

$time=date('H:i:s');

$recs = db_iquery($connection,"UPDATE `tbl_invoice_quote_header` SET `time_in` = '".$time."' WHERE `customer_id` = '".trim($_REQUEST['customer_id'])."' and quote_header_id='".$_REQUEST['workorder_id']."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }


    function all_upd_tbl_repairreplace() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['tenyrs_old_repair'],$_REQUEST['high_bill_repair'],$_REQUEST['fre_break_repair'],$_REQUEST['sys_ref_repair'],$_REQUEST['id']))

  	{
if($_REQUEST['id']!="")
 {



$recs = db_iquery($connection,"CALL sp_upd_tbl_repairreplace('".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['tenyrs_old_repair'])."','".trim($_REQUEST['high_bill_repair'])."','".trim($_REQUEST['fre_break_repair'])."','".trim($_REQUEST['sys_ref_repair'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

function all_inst_tbl_repairreplace() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['tenyrs_old_repair'],$_REQUEST['high_bill_repair'],$_REQUEST['fre_break_repair'],$_REQUEST['sys_ref_repair']))
  	{

$recs = db_iquery($connection,"CALL sp_inst_tbl_repairreplace('".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['tenyrs_old_repair'])."','".trim($_REQUEST['high_bill_repair'])."','".trim($_REQUEST['fre_break_repair'])."','".trim($_REQUEST['sys_ref_repair'])."')") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
				while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Inserting');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

function all_sle_three_tbl_repairreplace() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['id']))
		{
			$id = $_REQUEST['id'];			
		}	
		else $id 	= "";
		
		
		
		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_three_tbl_repairreplace('".$subscriber_id."','".$company_id."','".$id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber ,Id Company Id ,Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_sp_upd_espi_one() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['presentation_document'],$_REQUEST['id'],$_REQUEST['quote_id']))

  	{
if($_REQUEST['id']!="")
 {



$recs = db_iquery($connection,"CALL sp_upd_espi_one('".trim($_REQUEST['presentation_document'])."','".trim($_REQUEST['id'])."','".trim($_REQUEST['quote_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sp_tbl_uploadedfiles() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['category']))
		{
			$category = $_REQUEST['category'];			
		}	
		else $category 	= "";				
		
		

		
		if(trim($category) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_tbl_uploadedfiles ('".$category."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Category  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_get_slect_all_records() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
		

		
			$recs = db_iquery($connection,"CALL sp_select_all_records_productdepartment()")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found !');
				$response['status'] = 400;
			}
		
		
		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_select_uploadedfiles() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['file_id']))
		{
			$file_id = $_REQUEST['file_id'];			
		}	
		else $file_id 	= "";				
		
		

		
		if(trim($file_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_select_tbl_uploadedfiles('".$file_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'file_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	 function all_sp_upd_tbl_duct_work() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_id'],$_REQUEST['workorder_id'],$_REQUEST['tenyrs_old_repair'],$_REQUEST['air_size_repair'],$_REQUEST['manual_design_repair'],$_REQUEST['insulation_repair'],$_REQUEST['tenyrs_old_recomm'],$_REQUEST['air_size_recomm'],$_REQUEST['manual_design_recomm'],$_REQUEST['insulation_recomm'],$_REQUEST['id']))

  	{
if($_REQUEST['id']!="")
 {



$recs = db_iquery($connection,"CALL sp_upd_tbl_duct_work('".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['workorder_id'])."','".trim($_REQUEST['tenyrs_old_repair'])."','".trim($_REQUEST['air_size_repair'])."','".trim($_REQUEST['manual_design_repair'])."','".trim($_REQUEST['insulation_repair'])."','".trim($_REQUEST['tenyrs_old_recomm'])."','".trim($_REQUEST['air_size_recomm'])."','".trim($_REQUEST['manual_design_recomm'])."','".trim($_REQUEST['insulation_recomm'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
   function all_sp_ins_tbl_duct_work() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_id'],$_REQUEST['workorder_id'],$_REQUEST['tenyrs_old_repair'],$_REQUEST['air_size_repair'],$_REQUEST['manual_design_repair'],$_REQUEST['insulation_repair'],$_REQUEST['tenyrs_old_recomm'],$_REQUEST['air_size_recomm'],$_REQUEST['manual_design_recomm'],$_REQUEST['insulation_recomm']))
  	{

$recs = db_iquery($connection,"CALL sp_ins_tbl_duct_work('".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['workorder_id'])."','".trim($_REQUEST['tenyrs_old_repair'])."','".trim($_REQUEST['air_size_repair'])."','".trim($_REQUEST['manual_design_repair'])."','".trim($_REQUEST['insulation_repair'])."','".trim($_REQUEST['tenyrs_old_recomm'])."','".trim($_REQUEST['air_size_recomm'])."','".trim($_REQUEST['manual_design_recomm'])."','".trim($_REQUEST['insulation_recomm'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
				while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Inseting');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sp_sle_tbl_repairreplace_four() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";
		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_tbl_repairsolutions_four('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id, are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_sp_tbl_duct_work() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
    
	if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";

if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	= "";

		
		
		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($workorder_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_tbl_duct_work ('".$subscriber_id."','".$company_id."','".$customer_id."','".$workorder_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
     
  function all_sel_tbl_invoice_quote_footer() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";
		
		

		
		if(trim($header_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sel_tbl_invoice_quote_footer('".$header_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Header Id   are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_sel_tbl_repairsolutions_one() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['id']))
		{
			$id = $_REQUEST['id'];			
		}	
		else $id 	= "";
		
		

		
		if(trim($id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sel_tbl_repairsolutions_one('".$id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Id   are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_sel_tbl_three_invoice_quote_footer() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";
		
		if (isset($_REQUEST['product_des']))
		{
			$product_des = $_REQUEST['product_des'];			
		}	
		else $product_des 	= "";
		
		if (isset($_REQUEST['product_id']))
		{
			$product_id = $_REQUEST['product_id'];			
		}	
		else $product_id 	= "";
		
		if (isset($_REQUEST['radio_check']))
		{
			$radio_check = $_REQUEST['radio_check'];			
		}	
		else $radio_check 	= "";


		
		if(trim($header_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sel_tbl_three_invoice_quote_footerSA('".$header_id."','".$product_des."','".$product_id."','".$radio_check."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Recor Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Header Id ,Product Des ,Product Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
  
  function all_sle_four_tbl_repairsolutions() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_four_tbl_repairsolutions('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber ,Id Company Id ,Customer Id ,Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_ins_ten_espi() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['quote_id'],$_REQUEST['customer_id'],$_REQUEST['source_control'],$_REQUEST['filtration'],$_REQUEST['humidity'],$_REQUEST['purification'],$_REQUEST['ventilation'],$_REQUEST['indoor_recommendation'],$_REQUEST['id']))
  	{

$recs = db_iquery($connection,"CALL sp_ins_nine_espi('".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['source_control'])."','".trim($_REQUEST['filtration'])."','".trim($_REQUEST['humidity'])."','".trim($_REQUEST['purification'])."','".trim($_REQUEST['ventilation'])."','".trim($_REQUEST['indoor_recommendation'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sle_tbl_repairsolutions() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		
		if (isset($_REQUEST['id']))
		{
			$id = $_REQUEST['id'];			
		}	
		else $id 	= "";
		
		if(trim($subscriber_id) != "" && trim($company_id) != ""  && trim($id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_tbl_repairsolutions_three('".$subscriber_id."','".$company_id."','".$id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id, are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

///////////////////////////////////karuna//////////////////////////////////	karuna///////////////////////////////////		
		
		
function all_four_tbl_furnace() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id  = $_REQUEST['customer_id'];			
		}	
		else $customer_id  	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id  = $_REQUEST['quote_id'];			
		}	
		else $quote_id  	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_four_tbl_furnace('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id Or Quote Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_four_tbl_filtration() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id  = $_REQUEST['customer_id'];			
		}	
		else $customer_id  	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id  = $_REQUEST['quote_id'];			
		}	
		else $quote_id  	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_four_tbl_filtration('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id Or Quote Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function get_workorder_parts() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id  = $_REQUEST['quote_id'];			
		}	
		else $quote_id  	= "";

		
		if(trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL get_workorder_parts('".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id Or Quote Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
function all_four_tbl_filtration() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id  = $_REQUEST['customer_id'];			
		}	
		else $customer_id  	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id  = $_REQUEST['quote_id'];			
		}	
		else $quote_id  	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_four_tbl_flitration('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id Or Quote Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_four_tbl_furnace1() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id  = $_REQUEST['customer_id'];			
		}	
		else $customer_id  	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id  = $_REQUEST['quote_id'];			
		}	
		else $quote_id  	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_four_tbl_furnace2('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id Or Quote Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_four_tbl_furnace2() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id  = $_REQUEST['customer_id'];			
		}	
		else $customer_id  	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id  = $_REQUEST['quote_id'];			
		}	
		else $quote_id  	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_four_tbl_furnace1('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id Or Quote Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
/////bakkiyaraj End////

	



///////////////////////////////////karuna//////////////////////////////////	karuna///////////////////////////////////

	// Balu Created Oct - 19 //DASHBOARD
	
	function ipad_login_emp() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['email']))
		{
			$email 	= $_REQUEST['email'];		
		}	
		else $email 	= "";
		
				if (isset($_REQUEST['password']))
		{
			$password 	= $_REQUEST['password'];		
		}	
		else $password 	= "";
		
		if(trim($subscriber_id) != "" && trim($email) != "" && trim($password) != ""  )
		{
			$recs = db_iquery($connection,"CALL sp_getlogin_employee('".$subscriber_id."','".$email."','".$password."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id,Email and password are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function ipad_login_forrgot() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		
		if (isset($_REQUEST['email']))
		{
			$email 	= $_REQUEST['email'];		
		}	
		else $email 	= "";
		
		
		
		if(trim($email) != "")
		{
			$recs = db_iquery($connection,"CALL sp_getlogin_forget('".$email."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Email Address!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Email are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function ipad_login_destination() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['designation_id']))
		{
			$designation_id 	= $_REQUEST['designation_id'];		
		}	
		else $designation_id 	= "";

		
		if(trim($subscriber_id) != "" && trim($designation_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_getlogin_destination('".$subscriber_id."','".$designation_id."')") or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id and Destination Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function all_one_espi() {
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
		
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		if(trim($customer_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_one_espi('".$customer_id."')") or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'No record found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'customer_id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_one_espi_sa() {
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
		
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";
		
		if(trim($customer_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_one_espi_sa('".$customer_id."','".$quote_id."')") or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'No record found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'customer_id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_productid() {
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
		
		
		if (isset($_REQUEST['department_name']))
		{
			$department_name = trim($_REQUEST['department_name']);			
		}	
		else $department_name 	= "";
		if(trim($department_name) != "" )
		{
			$recs = db_iquery($connection,"SELECT * FROM lkp_productdepartment WHERE department_name='".$department_name."'") or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'department_name are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	 function sp_tbl_customers_one() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id']))
  	{
  				
  		$customer_id = $_REQUEST['customer_id'];
  		
  		
if(trim($customer_id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL sp_tbl_customers('".$customer_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function sp_lkp_state_one() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['state_id']))
  	{
  				
  		 $state_id = $_REQUEST['state_id'];
  		
  		
if(trim($state_id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL sp_lkp_state_one('".$state_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

	
function all_three_tbl_warrantycustomers() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['warrantycustomers_id']))
		{
			$warrantycustomers_id  = $_REQUEST['warrantycustomers_id'];			
		}	
		else $warrantycustomers_id  	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($warrantycustomers_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_three_tbl_warrantycustomers('".$subscriber_id."','".$company_id."','".$warrantycustomers_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Warrantycustomers Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
/*
   * ?action=spinvoice_quote_allemp_three&subscriber_id=desss&company_id=1&all_emp=96

  */
  function sp_quote_allemp_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['id']))
  	{
  		
  		$subscriber_id = $_REQUEST['subscriber_id'];
		$company_id = $_REQUEST['company_id'];		
  		$id = $_REQUEST['id'];

  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($id) != "")
  	{	

	$recs = db_iquery($connection,"CALL sp_three_tbl_warrantyworkorder('".$subscriber_id."','".$company_id."','".$id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }	
  
  function all_one_tbl_invoice_quote_header() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['quote_header_id']))
		{
			$quote_header_id = $_REQUEST['quote_header_id'];			
		}	
		else $quote_header_id 	= "";

		if(trim($quote_header_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_one_tbl_invoice_quote_header('".$quote_header_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'quote_header_id    are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

function seq_count() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";

		if(trim($customer_id) != "" )
		{
			$recs = db_iquery($connection,"CALL seq_count('".$customer_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'customer_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function sp_get_calender_id() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
				
		if(trim($employee_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_get_calender_id('".$employee_id."')")
			or die( mysql_error() ); 
			
			// die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Employee Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_working_calender_id() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['calendar_id']))
		{
			$calendar_id = $_REQUEST['calendar_id'];			
		}	
		else $calendar_id 	= "";
		
				
		if(trim($calendar_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_get_working_calender_id('".$calendar_id."')")
			or die( mysql_error() ); 
			
			// die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Calender Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_booking_dates() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['calendar_id']))
		{
			$calendar_id = $_REQUEST['calendar_id'];			
		}	
		else $calendar_id 	= "";
		
		if (isset($_REQUEST['month']))
		{
			$month = $_REQUEST['month'];			
		}	
		else $month 	= "";
		
				
		if(trim($calendar_id) != "" && trim($month) != "")
		{
			$recs = db_iquery($connection,"CALL sp_get_booking_dates('".$calendar_id."','".$month."')")
			or die( mysql_error() ); 
			
			// die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Employee Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
function sp_workorder_desc_up() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if(isset($_REQUEST['workorder_id']))
  	{
	if($_REQUEST['workorder_id']!="") {
	$recs = db_iquery($connection,"CALL sp_workorder_desc_up('".trim($_REQUEST['workorder_des_work'])."','".trim($_REQUEST['workorder_id'])."')") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
	
  function sp_customer_up() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id']))
  	{
if($_REQUEST['customer_id']!="") {

$recs = db_iquery($connection,"UPDATE `tbl_customers` SET `zip` = '".trim($_REQUEST['zip'])."', `address1` = '".trim($_REQUEST['address1'])."',`new_address` = '".trim($_REQUEST['new_address'])."',`address2` = '".trim($_REQUEST['address2'])."', `suite` = '".trim($_REQUEST['suite'])."', `map` = '".trim($_REQUEST['map'])."', `city` = '".trim($_REQUEST['city'])."', `state` = '".trim($_REQUEST['state'])."', `phone_number` = '".trim($_REQUEST['phone_number'])."', `firstname` = '".trim($_REQUEST['firstname'])."', `lastname` = '".trim($_REQUEST['lastname'])."', `cell_phone` = '".trim($_REQUEST['cell_phone'])."', `customer_type` = '".trim($_REQUEST['customer_type'])."', `warranty_customers` = '".trim($_REQUEST['warranty_customers'])."', `warranty_workorder` = '".trim($_REQUEST['warranty_workorder'])."', `work_phone` = '".trim($_REQUEST['work_phone'])."', `email` = '".trim($_REQUEST['email'])."' WHERE `customer_id` = '".trim($_REQUEST['customer_id'])."'") or die( mysqli_error() ); 
;
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sp_sle_customer_type() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";	
		
		if (isset($_REQUEST['Customer_type_id']))
		{
			$Customer_type_id = $_REQUEST['Customer_type_id'];			
		}	
		else $Customer_type_id 	= "";
		
		
		
		if(trim($subscriber_id) != "" && (trim($company_id)) != "" && (trim($Customer_type_id)) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_customer_type('".$subscriber_id."','".$company_id."','".$Customer_type_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id ,Customer_type_id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 /* 

 */	
	function all_sp_sle_lkp_leadsource() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";	
		
		if (isset($_REQUEST['leadsource_id']))
		{
			$leadsource_id = $_REQUEST['leadsource_id'];			
		}	
		else $leadsource_id 	= "";
		
		
		
		if(trim($subscriber_id) != "" && (trim($company_id)) != "" && (trim($leadsource_id)) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_lkp_leadsource('".$subscriber_id."','".$company_id."','".$leadsource_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id ,Leadsource Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 /*
*/	
	function all_sp_sle_campaign() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";	
		
		if (isset($_REQUEST['campaign_id']))
		{
			$campaign_id = $_REQUEST['campaign_id'];			
		}	
		else $campaign_id 	= "";
		
		
		
		if(trim($subscriber_id) != "" && (trim($company_id)) != "" && (trim($campaign_id)) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_campaign('".$subscriber_id."','".$company_id."','".$campaign_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id ,Campaign Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 /*

 */	
	function all_sp_tbl_employee() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['emp_id']))
		{
			$emp_id = $_REQUEST['emp_id'];			
		}	
		else $emp_id 	= "";				
		
		
		
		if(trim($emp_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_tbl_employee('".$emp_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Emp_id , are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

/*
  */	
		function all_sp_sle_lkp_designation() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['designation_id']))
		{
			$designation_id = $_REQUEST['designation_id'];			
		}	
		else $designation_id 	= "";				
		
		

		
		if(trim($designation_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_lkp_designation('".$designation_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Designation Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 /*
 */	
	function all_sp_tbl_warrantyworkorder_two() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		
		if(trim($subscriber_id) != "" && ($company_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_tbl_warrantyworkorder_two('".$subscriber_id."','".$company_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Calendar Title   are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 /*  
   
   */	
	function all_sp_tbl_customer_type_two() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		
		if(trim($subscriber_id) != "" && trim($company_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_tbl_customer_type_two ('".$subscriber_id."','".$company_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id, are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
  /* 
  */	
	function all_sp_sel_tbl_warrantycustomers_two() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['status']))
		{
			$status = $_REQUEST['status'];			
		}	
		else $status 	= "";
		
		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($status) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_sel_tbl_warrantycustomers_two('".$subscriber_id."','".$company_id."','".$status."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id, are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
  /* 
  */	
	function all_sp_sel_lkp_state_one() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['state_id']))
		{
			$state_id = $_REQUEST['state_id'];			
		}	
		else $state_id 	= "";				
			
		if(trim($state_id) != ""  )
		{
			$recs = db_iquery($connection,"CALL sp_sel_lkp_state_one('".$state_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'State_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
  /*  
  
  */
  
  function get_all_states() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");


	$recs = db_iquery($connection,"select * from lkp_state") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  	}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function sp_sel_espi_one() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['id']))
  	{
  				
  		 $id = $_REQUEST['id'];
  		
  		
if(trim($id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL sp_sel_espi_one('".$id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 


    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  //////////date 6th november 2013/////ramya
  
 function sp_get_energy_savings_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['id']))
  	{
  				
  		 $subscriber_id = $_REQUEST['subscriber_id'];
		 $company_id = $_REQUEST['company_id'];
		 $id = $_REQUEST['id'];
  		
if(trim($subscriber_id!= "" && $company_id!= ""  && $id!= ""))
  	{	

	$recs = db_iquery($connection,"CALL sp_get_energy_savings_three('".$subscriber_id."','".$company_id."','".$id."')") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function get_sel_furnace_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id'],$_REQUEST['workorder_id'],$_REQUEST['cacunit']))
  	{
  				
  		 $customer_id = $_REQUEST['customer_id'];
		 $workorder_id = $_REQUEST['workorder_id'];
		 $cacunit = $_REQUEST['cacunit'];
  		
if(trim($workorder_id!= "" && $customer_id!= ""  && $cacunit!= ""))
  	{	

	$recs = db_iquery($connection,"SELECT * FROM (`tbl_furnace`) WHERE `acunit_br_one` = '".$cacunit."' AND customer_id = '".$customer_id."' AND `quote_id`= '".$workorder_id."' ORDER BY furnace_id asc LIMIT 0 , 1") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function get_sel_espi_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id'],$_REQUEST['workorder_id'],$_REQUEST['id']))
  	{
  				
  		 $customer_id = $_REQUEST['customer_id'];
		 $workorder_id = $_REQUEST['workorder_id'];
		 $id = $_REQUEST['id'];
  		
if(trim($workorder_id!= "" && $customer_id!= ""  && $id!= ""))
  	{	

	$recs = db_iquery($connection,"SELECT * FROM (`espi`) WHERE `id` = '".$id."' AND customer_id = '".$customer_id."' AND `quote_id`= '".$workorder_id."'") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function all_sle_tbl_customers() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_tbl_customers('".$subscriber_id."','".$company_id."','".$customer_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber ,Id Company Id ,Customer Ld are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 /*
*/	
	
 /*
 */	
		
  function sp_allenergy_savings_insert() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id']))
  	{
		 $subscriber_id=$_REQUEST['subscriber_id'];
		$company_id=$_REQUEST['company_id'];
		 $customer_id=$_REQUEST['customer_id'];
		 $workorder_id=$_REQUEST['workorder_id'];
		 $es_cool_cost_annual=$_REQUEST['es_cool_cost_annual'];
		 $es_cool_cost_monthly=$_REQUEST['es_cool_cost_monthly'];
		 $es_estimated_new_cool_cost_annual=$_REQUEST['es_estimated_new_cool_cost_annual'];
		 $es_estimated_new_cool_cost_monthly=$_REQUEST['es_estimated_new_cool_cost_monthly'];
		 $es_entimated_energy_savings_annual=$_REQUEST['es_entimated_energy_savings_annual'];
		 $es_entimated_energy_savings_monthly=$_REQUEST['es_entimated_energy_savings_monthly'];
		 $todays_repair_cost=$_REQUEST['todays_repair_cost'];
		 $ten_year_repair_cost=$_REQUEST['ten_year_repair_cost'];
		 $ten_year_energy_cost=$_REQUEST['ten_year_energy_cost'];
		 $total_expense=$_REQUEST['total_expense'];
		 $home_buyer_allowance=$_REQUEST['home_buyer_allowance'];
		 $new_system_rep_annual=$_REQUEST['new_system_rep_annual'];
		 $new_system_rep_monthly=$_REQUEST['new_system_rep_monthly'];
		 $ten_year_repair_cost_replace=$_REQUEST['ten_year_repair_cost_replace'];
		 $ten_year_energy_cost_replace=$_REQUEST['ten_year_energy_cost_replace'];
		 $benefits=$_REQUEST['benefits'];
		 $total_investment=$_REQUEST['total_investment'];
		 $increase_home_value=$_REQUEST['increase_home_value'];
		  $selectedtons=$_REQUEST['selectedtons'];
		 $selectedseer=$_REQUEST['selectedseer'];  
  		
		//die;
	$recs = db_iquery($connection,"CALL sp_allenergy_savings_insert('".trim($subscriber_id)."','".trim($company_id)."','".trim($customer_id)."','".trim($workorder_id)."','".trim($es_cool_cost_annual)."','".trim($es_cool_cost_monthly)."','".trim($es_estimated_new_cool_cost_annual)."','".trim($es_estimated_new_cool_cost_monthly)."','".trim($es_entimated_energy_savings_annual)."','".trim($es_entimated_energy_savings_monthly)."','".trim($todays_repair_cost)."','".trim($ten_year_repair_cost)."','".trim($ten_year_energy_cost)."','".trim($total_expense)."','".trim($home_buyer_allowance)."','".trim($new_system_rep_annual)."','".trim($new_system_rep_monthly)."','".trim($ten_year_repair_cost_replace)."','".trim($ten_year_energy_cost_replace)."','".trim($benefits)."','".trim($total_investment)."','".trim($increase_home_value)."','".trim($selectedseer)."','".trim($selectedtons)."')");
	
	
  		if ($recs == true)
			{	
				//$outid = db_iquery($connection,"select max(id) as id from energy_savings order by id desc");
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				
				$response['code'] = 1;
				$response['status'] = 200;
  		}else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
	}	
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

  // echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
   function sp_allenergy_savings_update() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['energy_savings_id']) && $_REQUEST['energy_savings_id']!='')
  	{
		 $subscriber_id=$_REQUEST['subscriber_id'];
	     $company_id=$_REQUEST['company_id'];
	     $customer_id=$_REQUEST['customer_id'];
		 $workorder_id=$_REQUEST['workorder_id'];
		 $es_cool_cost_annual=$_REQUEST['es_cool_cost_annual'];
		 $es_cool_cost_monthly=$_REQUEST['es_cool_cost_monthly'];
		 $es_estimated_new_cool_cost_annual=$_REQUEST['es_estimated_new_cool_cost_annual'];
		 $es_estimated_new_cool_cost_monthly=$_REQUEST['es_estimated_new_cool_cost_monthly'];
		 $es_entimated_energy_savings_annual=$_REQUEST['es_entimated_energy_savings_annual'];
		 $es_entimated_energy_savings_monthly=$_REQUEST['es_entimated_energy_savings_monthly'];
		 $todays_repair_cost=$_REQUEST['todays_repair_cost'];
		 $ten_year_repair_cost=$_REQUEST['ten_year_repair_cost'];
		 $ten_year_energy_cost=$_REQUEST['ten_year_energy_cost'];
		 $total_expense=$_REQUEST['total_expense'];
		 $home_buyer_allowance=$_REQUEST['home_buyer_allowance'];
		 $new_system_rep_annual=$_REQUEST['new_system_rep_annual'];
		 $new_system_rep_monthly=$_REQUEST['new_system_rep_monthly'];
		 $ten_year_repair_cost_replace=$_REQUEST['ten_year_repair_cost_replace'];
		 $ten_year_energy_cost_replace=$_REQUEST['ten_year_energy_cost_replace'];
		 $benefits=$_REQUEST['benefits'];
		 $total_investment=$_REQUEST['total_investment'];
		 $increase_home_value=$_REQUEST['increase_home_value'];
		 $energy_savings_id=$_REQUEST['energy_savings_id'];
		 $selectedtons=$_REQUEST['selectedtons'];
		 $selectedseer=$_REQUEST['selectedseer'];
  		
		
	$recs = db_iquery($connection,"CALL sp_allenergy_savings_update('".trim($subscriber_id)."','".trim($company_id)."','".trim($customer_id)."','".trim($workorder_id)."','".trim($es_cool_cost_annual)."','".trim($es_cool_cost_monthly)."','".trim($es_estimated_new_cool_cost_annual)."','".trim($es_estimated_new_cool_cost_monthly)."','".trim($es_entimated_energy_savings_annual)."','".trim($es_entimated_energy_savings_monthly)."','".trim($todays_repair_cost)."','".trim($ten_year_repair_cost)."','".trim($ten_year_energy_cost)."','".trim($total_expense)."','".trim($home_buyer_allowance)."','".trim($new_system_rep_annual)."','".trim($new_system_rep_monthly)."','".trim($ten_year_repair_cost_replace)."','".trim($ten_year_energy_cost_replace)."','".trim($benefits)."','".trim($total_investment)."','".trim($increase_home_value)."','".$selectedseer."','".$selectedtons."','".trim($energy_savings_id)."')") or die( mysqli_error() ); 
 
	
  	if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
	}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function all_sp_sle_two_espi() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";				
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		

		
		if(trim($quote_id) != ""  && trim($customer_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_two_espi('".$quote_id."','".$customer_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id,Customer Ld are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
		function all_sp_sle_three_tbl_invoice_quote_footer() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";
		
		if (isset($_REQUEST['radio_check']))
		{
			$radio_check = $_REQUEST['radio_check'];			
		}	
		else $radio_check 	= "";
		
		if(trim($subscriber_id) != "" && (trim($company_id)) !="" && (trim($header_id)) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_three_tbl_invoice_quote_footer('".$subscriber_id."','".$company_id."','".$header_id."','".$radio_check."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id, Header Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function all_sp_sle_two_tbl_invoice_quote_footer() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";				
		
		if (isset($_REQUEST['workorder_type']))
		{
			$workorder_type = $_REQUEST['workorder_type'];			
		}	
		else $workorder_type 	= "";
		
		
		
		if(trim($header_id) != "" && (trim($workorder_type)) !="" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_two_tbl_invoice_quote_footer('".$header_id."','".$workorder_type."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Header Id ,Workorder Type are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function all_sp_sle_one_tbl_invoice_quote_footer() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";				
		
		
		
		
		if(trim($header_id) != ""  )
		{
			$recs = db_iquery($connection,"CALL sp_sle_one_tbl_invoice_quote_footer('".$header_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Header Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
  

	 function all_sp_sle_three_tbl_repairsolutions() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";				
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";
		
		if (isset($_REQUEST['opt_check']))
		{
			$opt_check = $_REQUEST['opt_check'];			
		}	
		else $opt_check 	= "";
		
		
		if(trim($customer_id) != "" && trim($quote_id) !="" && trim($opt_check) !="" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_three_tbl_repairsolutions('".$customer_id."','".$quote_id."','".$opt_check."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Customer Id ,Quote Id ,Opt Check are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_sp_allfooterinfo() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";
		
		if (isset($_REQUEST['radio_check']))
		{
			$radio_check = $_REQUEST['radio_check'];			
		}	
		else $radio_check 	= "";
		

		
		
		if(trim($quote_id) !="")
		{
			$recs = db_iquery($connection,"select * from tbl_invoice_quote_footer where header_id='".$quote_id."' and (radio_check='".$radio_check."' or radio_check='1' or radio_type='2') order by product_des ASC")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function select_tbl_invoice_quote_footer() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";
			
		if(trim($quote_id) !="")
		{
			$recs = db_iquery($connection,"select * from tbl_invoice_quote_footer where header_id='".$quote_id."' order by product_des ASC")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function select_energy_savings() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";
			
		if(trim($quote_id) !="")
		{
			$recs = db_iquery($connection,"select * from energy_savings where workorder_id='".$quote_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}		
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_sp_del_tbl_invoice_quote_footer() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['header_id']))
  	{
	
	$header_id=trim($_REQUEST['header_id']);
	if($header_id!="")
	{

	$recs = db_iquery($connection,"CALL sp_del_tbl_invoice_quote_footer(".$header_id.")") or die( mysqli_error() ); 


  	if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Deleted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Deleting');
  			$response['status'] = 400;
  		}
		
	} 
	else
		{
		 $output = array("errmsg"=>'Argument is Empty.');
  		$response['status'] = 400; 
		} 
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
/*
 */	
	function all_sp_sle_one_lkp_products() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;

		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['product_name']))
		{
			$product_name = $_REQUEST['product_name'];			
		}	
		else $product_name 	= "";				
		
		
		
		
		if(trim($product_name) != ""  )
		{
			$recs = db_iquery($connection,"CALL sp_sle_one_lkp_products('".$product_name."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Product Name  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 /* 
 */	
		function all_sp_sle_four_tbl_invoice_quote_footer() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";				
		
		if (isset($_REQUEST['product_des']))
		{
			$product_des = $_REQUEST['product_des'];			
		}	
		else $product_des 	= "";
		
		if (isset($_REQUEST['product_id']))
		{
			$product_id = $_REQUEST['product_id'];			
		}	
		else $product_id 	= "";
		
		
		if (isset($_REQUEST['radio_check']))
		{
			$radio_check = $_REQUEST['radio_check'];			
		}	
		else $radio_check 	= "";

		
		/*if(trim($header_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_four_tbl_invoice_quote_footerSA(".$header_id.",'".stripslashes($product_des)."',".$product_id.",'".$radio_check."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not found');
				$response['status'] = 400;
			}
		}*/
		
		if(trim($header_id) != ""){
		
			$recs = db_iquery($connection,"SELECT * FROM `tbl_invoice_quote_footer` WHERE header_id=".$header_id." and product_des='".$product_des."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		
		}
		
		else
		{

			$output[] = array("errmsg"=>'Header Id ,Product Des ,Product Quanity ,Net Customer Cost are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 /*
  */	
function get_update_tbl_invoice_quote_footer() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['header_id']))
  	{
$recs = db_iquery($connection,"update tbl_invoice_quote_footer set subscriber_id='".trim($_REQUEST['subscriber_id'])."',company_id='".trim($_REQUEST['company_id'])."',header_id='".trim($_REQUEST['header_id'])."',product_id='".trim($_REQUEST['product_id'])."',product_des='".trim($_REQUEST['product_des'])."',product_quanity ='".trim($_REQUEST['product_quanity'])."',prod_responsibility ='".trim($_REQUEST['prod_responsibility'])."',prod_department ='".trim($_REQUEST['prod_department'])."',product_unit_price ='".trim($_REQUEST['product_unit_price'])."',radio_check='".trim($_REQUEST['radio_check'])."' where quote_footer_id='".trim($_REQUEST['quote_footer_id'])."'") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
   function all_ins_tbl_invoice_quote_footer() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['header_id']))
  	{

//$recs = db_iquery($connection,"CALL sp_ins_tbl_invoice_quote_footer('".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['header_id'])."','".trim($_REQUEST['product_id'])."','".trim($_REQUEST['product_des'])."')") or die( mysqli_error() ); 

$recs = db_iquery($connection,"insert into tbl_invoice_quote_footer(subscriber_id,emp_id,customer_id,company_id,header_id,product_id,product_des,radio_check,product_quanity,net_customer_cost,discount,esc_savings,total_esc_savings,prod_responsibility,prod_department,prod_upgrade,product_unit_price,product_type,product_total_amount,quote_type,workorder_type,invioice_type,wtype,add_line) values('".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['emp_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['header_id'])."','".trim($_REQUEST['product_id'])."','".trim($_REQUEST['product_des'])."','".trim($_REQUEST['radio_check'])."','".trim($_REQUEST['product_quanity'])."','".trim($_REQUEST['net_customer_cost'])."','".trim($_REQUEST['discount'])."','".trim($_REQUEST['esc_savings'])."','".trim($_REQUEST['total_esc_savings'])."','".trim($_REQUEST['prod_responsibility'])."','".trim($_REQUEST['prod_department'])."','".trim($_REQUEST['prod_upgrade'])."','".trim($_REQUEST['product_unit_price'])."','".trim($_REQUEST['product_type'])."','".trim($_REQUEST['product_total_amount'])."','".trim($_REQUEST['quote_type'])."','".trim($_REQUEST['workorder_type'])."','".trim($_REQUEST['invioice_type'])."','".trim($_REQUEST['wtype'])."','".trim($_REQUEST['add_line'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sp_upd_two_tbl_repairsolutions() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['optimal_sol'],$_REQUEST['quote_id']))

  	{
if($_REQUEST['quote_id']!="")
 {



$recs = db_iquery($connection,"CALL sp_upd_two_tbl_repairsolutions('".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['quote_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
/*
 */
  function all_sp_up_two_tbl_repairsolutions() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['essent_sol'],$_REQUEST['quote_id']))

  	{
if($_REQUEST['quote_id']!="")
 {



$recs = db_iquery($connection,"CALL sp_up_two_tbl_repairsolutions('".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['quote_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
/*

*/
  function all_sp_upda_two_tbl_repairsolutions() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['critical_sol'],$_REQUEST['quote_id']))

  	{
if($_REQUEST['quote_id']!="")
 {



$recs = db_iquery($connection,"CALL sp_upda_two_tbl_repairsolutions('".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['quote_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

  //////////date 6th november 2013/////ramya
///////////////////////////////////ramya//////////////////////////////////	ramya/////////////////////////////////// ramya///////////////////////////////////	
///////////////////////////////////ramya//////////////////////////////////	ramya/////////////////////////////////// ramya///////////////////////////////////
///////////////////////////////////ramya//////////////////////////////////	ramya/////////////////////////////////// ramya///////////////////////////////////
///////////////////////////////////ramya//////////////////////////////////	ramya/////////////////////////////////// ramya///////////////////////////////////	
	
	
	/*SANTHOSH - START*/
  function sp_up_espi_twthree() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['quote_id'],$_REQUEST['customer_id'],$_REQUEST['electric_provider'],$_REQUEST['electric_rate'],$_REQUEST['electric_expiry'],$_REQUEST['gas_provider'],$_REQUEST['gas_rate'],$_REQUEST['gas_expiry'],$_REQUEST['electric_bill'],$_REQUEST['gas_bill'],$_REQUEST['living'],$_REQUEST['home_build'],$_REQUEST['sqft'],$_REQUEST['occupants'],$_REQUEST['winter'],$_REQUEST['summer'],$_REQUEST['warranty'],$_REQUEST['warranty_others'],$_REQUEST['smart_club'],$_REQUEST['expiration_date'],$_REQUEST['into_house'],$_REQUEST['out_of_house'],$_REQUEST['id']))
  	{
if($_REQUEST['id']!="") {
$recs = db_iquery($connection,"CALL sp_up_espi_twthree('".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['electric_provider'])."','".trim($_REQUEST['electric_rate'])."','".trim($_REQUEST['electric_expiry'])."','".trim($_REQUEST['gas_provider'])."','".trim($_REQUEST['gas_rate'])."','".trim($_REQUEST['gas_expiry'])."','".trim($_REQUEST['electric_bill'])."','".trim($_REQUEST['gas_bill'])."','".trim($_REQUEST['living'])."','".trim($_REQUEST['home_build'])."','".trim($_REQUEST['sqft'])."','".trim($_REQUEST['occupants'])."','".trim($_REQUEST['winter'])."','".trim($_REQUEST['summer'])."','".trim($_REQUEST['warranty'])."','".trim($_REQUEST['warranty_others'])."','".trim($_REQUEST['smart_club'])."','".trim($_REQUEST['expiration_date'])."','".trim($_REQUEST['into_house'])."','".trim($_REQUEST['out_of_house'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  } 
  function sp_ins_espi_twtwo() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['quote_id'],$_REQUEST['customer_id'],$_REQUEST['electric_provider'],$_REQUEST['electric_rate'],$_REQUEST['electric_expiry'],$_REQUEST['gas_provider'],$_REQUEST['gas_rate'],$_REQUEST['gas_expiry'],$_REQUEST['electric_bill'],$_REQUEST['gas_bill'],$_REQUEST['living'],$_REQUEST['home_build'],$_REQUEST['sqft'],$_REQUEST['occupants'],$_REQUEST['winter'],$_REQUEST['summer'],$_REQUEST['warranty'],$_REQUEST['warranty_others'],$_REQUEST['smart_club'],$_REQUEST['expiration_date'],$_REQUEST['into_house'],$_REQUEST['out_of_house']))
  	{

$recs = db_iquery($connection,"CALL sp_ins_espi_twtwo('".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['electric_provider'])."','".trim($_REQUEST['electric_rate'])."','".trim($_REQUEST['electric_expiry'])."','".trim($_REQUEST['gas_provider'])."','".trim($_REQUEST['gas_rate'])."','".trim($_REQUEST['gas_expiry'])."','".trim($_REQUEST['electric_bill'])."','".trim($_REQUEST['gas_bill'])."','".trim($_REQUEST['living'])."','".trim($_REQUEST['home_build'])."','".trim($_REQUEST['sqft'])."','".trim($_REQUEST['occupants'])."','".trim($_REQUEST['winter'])."','".trim($_REQUEST['summer'])."','".trim($_REQUEST['warranty'])."','".trim($_REQUEST['warranty_others'])."','".trim($_REQUEST['smart_club'])."','".trim($_REQUEST['expiration_date'])."','".trim($_REQUEST['into_house'])."','".trim($_REQUEST['out_of_house'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
			while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function sp_tbl_repairsolutions() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_id'],$_REQUEST['quote_id']))
  	{
  				
  		 $subscriber_id = $_REQUEST['subscriber_id'];
		 $company_id = $_REQUEST['company_id'];
		 $customer_id =$_REQUEST['customer_id'];
  		 $quote_id = $_REQUEST['quote_id'];
  		
if(trim($subscriber_id!= "" && $company_id!= "" && $customer_id!= "" && $quote_id!= ""))
  	{	

	$recs = db_iquery($connection,"CALL sp_sle_tbl_repairsolutions_four('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function tbl_repairsolutions_cus_balance() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_id']))
  	{
  				
  		 $subscriber_id = $_REQUEST['subscriber_id'];
		 $company_id = $_REQUEST['company_id'];
		 $customer_id =$_REQUEST['customer_id'];

if(trim($subscriber_id!= "" && $company_id!= "" && $customer_id!= ""))
  	{	

	$recs = db_iquery($connection,"CALL sp_sle_tbl_repairsolutions_four_bal('".$subscriber_id."','".$company_id."','".$customer_id."')") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function sp_tbl_condencer_value() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_id'],$_REQUEST['quote_id']))
  	{
  		 $subscriber_id = $_REQUEST['subscriber_id'];
		 $company_id = $_REQUEST['company_id'];
		 $customer_id =$_REQUEST['customer_id'];
  		 $quote_id = $_REQUEST['quote_id'];
  		
if(trim($subscriber_id!= "" && $company_id!= "" && $customer_id!= "" && $quote_id!= ""))
  	{	
		$recs = db_iquery($connection,"CALL sp_four_tbl_furnace1('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
											$output[] = $row;
  												}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
  	}
	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
 
  function sp_espi_customer_prac_up() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['lights_off'],$_REQUEST['conserve_water'],$_REQUEST['havc'],$_REQUEST['cfl'],$_REQUEST['thermostat'],$_REQUEST['swimming_pool'],$_REQUEST['pets'],$_REQUEST['summer_humidity'],$_REQUEST['hot_or_cold'],$_REQUEST['try_winter'],$_REQUEST['noise_concerns'],$_REQUEST['frequency_dusting'],$_REQUEST['allergies'],$_REQUEST['other_concern'],$_REQUEST['id']))
  	{
if($_REQUEST['id']!="") {
$recs = db_iquery($connection,"CALL espi_customer_prac_up('".trim($_REQUEST['lights_off'])."','".trim($_REQUEST['conserve_water'])."','".trim($_REQUEST['havc'])."','".trim($_REQUEST['cfl'])."','".trim($_REQUEST['thermostat'])."','".trim($_REQUEST['swimming_pool'])."','".trim($_REQUEST['pets'])."','".trim($_REQUEST['summer_humidity'])."','".trim($_REQUEST['hot_or_cold'])."','".trim($_REQUEST['try_winter'])."','".trim($_REQUEST['noise_concerns'])."','".trim($_REQUEST['frequency_dusting'])."','".trim($_REQUEST['allergies'])."','".trim($_REQUEST['other_concern'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function all_up_nine_espi() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['quote_id']))
  	{

$recs = db_iquery($connection,"CALL sp_up_nine_espi('".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['source_control'])."','".trim($_REQUEST['filtration'])."','".trim($_REQUEST['humidity'])."','".trim($_REQUEST['purification'])."','".trim($_REQUEST['ventilation'])."','".trim($_REQUEST['indoor_recommendation'])."','".trim($_REQUEST['Supply_Duct_Leakage'])."','".trim($_REQUEST['Return_Leakage'])."','".trim($_REQUEST['Unsealed_Registers'])."','".trim($_REQUEST['Unsealed_Attic_Ladder'])."','".trim($_REQUEST['Unsealed_Attic_Penetrations'])."','".trim($_REQUEST['Electronic'])."','".trim($_REQUEST['Media'])."','".trim($_REQUEST['Pure_Air'])."','".trim($_REQUEST['ACCU_Clean'])."','".trim($_REQUEST['filteration_Other'])."','".trim($_REQUEST['Filter_Location'])."','".trim($_REQUEST['Mold_On_Grills'])."','".trim($_REQUEST['T_point'])."','".trim($_REQUEST['UV_Purification'])."','".trim($_REQUEST['light_at_coil'])."','".trim($_REQUEST['ventilation_None'])."','".trim($_REQUEST['Fresh_Air_Intake'])."','".trim($_REQUEST['ERV'])."','".trim($_REQUEST['ventilation_Other'])."','".trim($_REQUEST['instal_type'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function sp_ins_nine_espi() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['quote_id'],$_REQUEST['customer_id'],$_REQUEST['source_control'],$_REQUEST['filtration'],$_REQUEST['humidity'],$_REQUEST['purification'],$_REQUEST['ventilation'],$_REQUEST['indoor_recommendation']))
  	{

$recs = db_iquery($connection,"CALL sp_ins_nine_espi('".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['source_control'])."','".trim($_REQUEST['filtration'])."','".trim($_REQUEST['humidity'])."','".trim($_REQUEST['purification'])."','".trim($_REQUEST['ventilation'])."','".trim($_REQUEST['indoor_recommendation'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
			while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function sp_get_espi_report_cid_three() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id'],$_REQUEST['main_description'],$_REQUEST['description']))
  	{
  		
  		$customer_id = $_REQUEST['customer_id'];
		$main_description = $_REQUEST['main_description'];		
  		$description = $_REQUEST['description'];

  		
if(trim($customer_id) != "" && trim($main_description) != "" && trim($description) != "")
  	{	

	$recs = db_iquery($connection,"CALL sp_get_espi_report_cid_three('".$customer_id."','".$main_description."','".$description."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function sp_tbl_espi_report_ins() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['status'],$_REQUEST['customer_id'],$_REQUEST['work_order_id'],$_REQUEST['main_description'],$_REQUEST['description']))
  	{
  		 $status = $_REQUEST['status'];
  		 $customer_id = $_REQUEST['customer_id'];
		 $work_order_id   = $_REQUEST['work_order_id'];
		 $main_description = $_REQUEST['main_description'];
		 $description =$_REQUEST['description'];
  		
  		
if(trim($status!= "" && $customer_id!= "" && $work_order_id!= "" && $main_description!= "" && $description!= ""))
  	{	

	$recs = db_iquery($connection,"CALL  sp_tbl_espi_report_insert('".$status."','".$customer_id."','".$work_order_id."','".$main_description."','".$description."')") or die( mysqli_error() ); 
  	if (isset($recs))
	{
		$output = array("Successmsg"=>'Record INserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	}

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function sp_up_tbl_espi_report() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['status'],$_REQUEST['customer_id'],$_REQUEST['work_order_id'],$_REQUEST['main_description'],$_REQUEST['description'],$_REQUEST['id']))
  	{
  		 $status = $_REQUEST['status'];
  		 $customer_id = $_REQUEST['customer_id'];
		 $work_order_id   = $_REQUEST['work_order_id'];
		 $main_description = $_REQUEST['main_description'];
		 $description =$_REQUEST['description'];
  		                $id  =$_REQUEST['id'];
  		


	$recs = db_iquery($connection,"CALL  sp_up_tbl_espi_report('".trim($status)."','".trim($customer_id)."','".trim($work_order_id)."','".trim($main_description)."','".trim($description)."','".trim($id)."')") or die( mysqli_error() ); 
  	if (isset($recs))
	{
		$output = array("Successmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function sp_del_tbl_espi_report() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['id']))
  	{
  				
  		 $id = $_REQUEST['id'];
  		
  		
if(trim($id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL  sp_del_tbl_espi_report('".$id."')") or die( mysqli_error() ); 

  	if (isset($recs))
	{       $output = array("errmsg"=>'Record Deleted');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	}
	

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  /*date oct29*/
  function sp_espi_five() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['leakage'],$_REQUEST['insulation'],$_REQUEST['ventilation1'],$_REQUEST['radiant_barrier'],$_REQUEST['attic_recommendation'],$_REQUEST['insulation_text'],$_REQUEST['Attic_Ladder'],$_REQUEST['Plumbing_Pene'],$_REQUEST['Electrical_Pene'],$_REQUEST['HVAC_Pene'],$_REQUEST['Fiberglass'],$_REQUEST['Greater'],$_REQUEST['Soffits_Clear'],$_REQUEST['Ridge_Vent'],$_REQUEST['Gable_Vent'],$_REQUEST['Power_Ventil'],$_REQUEST['Whirly_Bird'],$_REQUEST['Solar_Attic'],$_REQUEST['blocked'],$_REQUEST['Cool_Ply'],$_REQUEST['Spray_On'],$_REQUEST['Staple'],$_REQUEST['None'],$_REQUEST['id']))
  	{
  				
  		     $leakage = $_REQUEST['leakage'];
		     $insulation = $_REQUEST['insulation'];
		     $ventilation1 = $_REQUEST['ventilation1'];
		     $radiant_barrier = $_REQUEST['radiant_barrier'];
		     $attic_recommendation = $_REQUEST['attic_recommendation'];
		     $insulation_text = $_REQUEST['insulation_text'];
			 $Attic_Ladder  			    = $_REQUEST['Attic_Ladder'];
		     $Plumbing_Pene  			= $_REQUEST['Plumbing_Pene'];
		     $Electrical_Pene  			= $_REQUEST['Electrical_Pene'];
		     $HVAC_Pene  			    = $_REQUEST['HVAC_Pene'];
		     $Fiberglass  			    = $_REQUEST['Fiberglass'];
		     $Greater  			        = $_REQUEST['Greater'];
		     $Soffits_Clear  			= $_REQUEST['Soffits_Clear'];
		     $Ridge_Vent  			    = $_REQUEST['Ridge_Vent'];
		     $Gable_Vent  			    = $_REQUEST['Gable_Vent'];
		     $Power_Ventil  			    = $_REQUEST['Power_Ventil'];
		     $Whirly_Bird  			    = $_REQUEST['Whirly_Bird'];
		     $Solar_Attic  			    = $_REQUEST['Solar_Attic'];
		     $blocked  			        = $_REQUEST['blocked'];
		     $Cool_Ply  			        = $_REQUEST['Cool_Ply'];
		     $Spray_On  			        = $_REQUEST['Spray_On'];
		     $Staple  			        = $_REQUEST['Staple'];
		     $None  			            = $_REQUEST['None'];
		     $id = $_REQUEST['id'];
  		
  	

	 $recs = db_iquery($connection,"CALL sp_espi_five('".trim($leakage)."','".trim($insulation)."','".trim($ventilation1)."','".trim($radiant_barrier)."','".trim($attic_recommendation)."','".trim($insulation_text)."','".trim($Attic_Ladder)."','".trim($Plumbing_Pene)."','".trim($Electrical_Pene)."','".trim($HVAC_Pene)."','".trim($Fiberglass)."','".trim($Greater)."','".trim($Soffits_Clear)."','".trim($Ridge_Vent)."','".trim($Gable_Vent)."','".trim($Power_Ventil)."','".trim($Whirly_Bird)."','".trim($Solar_Attic)."','".trim($blocked)."','".trim($Cool_Ply)."','".trim($Spray_On)."','".trim($Staple)."','".trim($None)."','".trim($id)."')") or die( mysqli_error() ); 

  	if (isset($recs))
	{
		$output = array("success"=>'Record Uptated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

   // echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  /*date nov04*/
  function all_sp_sle_one_tbl_customers() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";				
		
		
		
		if(trim($customer_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_one_tbl_customers('".$customer_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Customer Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
  function sp_up_espi_twseven() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");




 if (isset($_REQUEST['air_cond_age'],$_REQUEST['age'],$_REQUEST['efficiency_seer'],$_REQUEST['efficiency_seer_text'],$_REQUEST['evacoil'],$_REQUEST['maintenance'],$_REQUEST['evaporator_coil'],$_REQUEST['condenser_coil'],$_REQUEST['primary_pan'],$_REQUEST['drain_line'],$_REQUEST['other'],$_REQUEST['installation1'],$_REQUEST['Disconnect'],$_REQUEST['Level'],$_REQUEST['Raise'],$_REQUEST['Insulate'],$_REQUEST['Relocate'],$_REQUEST['Strap'],$_REQUEST['Inspection'],$_REQUEST['Inline'],$_REQUEST['Secondary'],$_REQUEST['Hard'],$_REQUEST['Surge'],$_REQUEST['Quick'],$_REQUEST['Otherins'],$_REQUEST['air_cond_recommendation'],$_REQUEST['id']))
  	{
if($_REQUEST['id']!="")
 {

$recs = db_iquery($connection,"CALL sp_up_espi_twseven('".trim($_REQUEST['air_cond_age'])."','".trim($_REQUEST['age'])."','".trim($_REQUEST['efficiency_seer'])."','".trim($_REQUEST['efficiency_seer_text'])."','".trim($_REQUEST['evacoil'])."','".trim($_REQUEST['maintenance'])."','".trim($_REQUEST['evaporator_coil'])."','".trim($_REQUEST['condenser_coil'])."','".trim($_REQUEST['primary_pan'])."','".trim($_REQUEST['drain_line'])."','".trim($_REQUEST['other'])."','".trim($_REQUEST['installation1'])."','".trim($_REQUEST['Disconnect'])."','".trim($_REQUEST['Level'])."','".trim($_REQUEST['Raise'])."','".trim($_REQUEST['Insulate'])."','".trim($_REQUEST['Relocate'])."','".trim($_REQUEST['Strap'])."','".trim($_REQUEST['Inspection'])."','".trim($_REQUEST['Inline'])."','".trim($_REQUEST['Secondary'])."','".trim($_REQUEST['Hard'])."','".trim($_REQUEST['Surge'])."','".trim($_REQUEST['Quick'])."','".trim($_REQUEST['Otherins'])."','".trim($_REQUEST['air_cond_recommendation'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function sp_up_espi_duct_age_nine() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['id']))
  	{
if($_REQUEST['id']!="") {

$recs = db_iquery($connection,"CALL sp_up_espi_duct_age_nine('".trim($_REQUEST['duct_age'])."','".trim($_REQUEST['duct_age_check'])."','".trim($_REQUEST['insulation2'])."','".trim($_REQUEST['design'])."','".trim($_REQUEST['installation3'])."','".trim($_REQUEST['duct_insulation'])."','".trim($_REQUEST['duct_recommendation'])."','".trim($_REQUEST['espi_status'])."','".trim($_REQUEST['return_leakage'])."','".trim($_REQUEST['supply_leakage'])."','".trim($_REQUEST['insulationrvalue'])."','".trim($_REQUEST['noise'])."','".trim($_REQUEST['drafts'])."','".trim($_REQUEST['uneventemp'])."','".trim($_REQUEST['highstaticpressure'])."','".trim($_REQUEST['noofreturns'])."','".trim($_REQUEST['seal'])."','".trim($_REQUEST['stretch'])."','".trim($_REQUEST['ductstrap'])."','".trim($_REQUEST['straighten'])."','".trim($_REQUEST['return_grill_size1'])."','".trim($_REQUEST['return_duct_size1'])."','".trim($_REQUEST['system_ton1'])."','".trim($_REQUEST['return_grill_size2'])."','".trim($_REQUEST['return_duct_size2'])."','".trim($_REQUEST['system_ton2'])."','".trim($_REQUEST['return_grill_size3'])."','".trim($_REQUEST['return_duct_size3'])."','".trim($_REQUEST['system_ton3'])."','".trim($_REQUEST['return_grill_size4'])."','".trim($_REQUEST['return_duct_size4'])."','".trim($_REQUEST['system_ton4'])."','".trim($_REQUEST['return_grill_size5'])."','".trim($_REQUEST['return_duct_size5'])."','".trim($_REQUEST['system_ton5'])."','".trim($_REQUEST['return_grill_size6'])."','".trim($_REQUEST['return_duct_size6'])."','".trim($_REQUEST['system_ton6'])."','".trim($_REQUEST['return_grill_size7'])."','".trim($_REQUEST['return_duct_size7'])."','".trim($_REQUEST['system_ton7'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  /*date nov07*/
  function sp_up_espi_twseven_heating() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

	


 if (isset($_REQUEST['heating_age'],$_REQUEST['heating'],$_REQUEST['efficiency'],$_REQUEST['heating_efficiency'],$_REQUEST['pumps'],$_REQUEST['afue'],$_REQUEST['effseer'],$_REQUEST['fueltype'],$_REQUEST['variablespeed'],$_REQUEST['Blower'],$_REQUEST['Burners'],$_REQUEST['Exchanger'],$_REQUEST['Main_Heat_Other'],$_REQUEST['Furnace'],$_REQUEST['Service'],$_REQUEST['Flue'],$_REQUEST['Gas'],$_REQUEST['Ins_Other'],$_REQUEST['maintenance1'],$_REQUEST['installation2'],$_REQUEST['heating_recommendation'],$_REQUEST['id']))
  	{


if($_REQUEST['id']!="")
 {

$recs = db_iquery($connection,"CALL sp_up_espi_twseven_heating('".trim($_REQUEST['heating_age'])."','".trim($_REQUEST['heating'])."','".trim($_REQUEST['efficiency'])."','".trim($_REQUEST['heating_efficiency'])."','".trim($_REQUEST['pumps'])."','".trim($_REQUEST['afue'])."','".trim($_REQUEST['effseer'])."','".trim($_REQUEST['fueltype'])."','".trim($_REQUEST['variablespeed'])."','".trim($_REQUEST['Blower'])."','".trim($_REQUEST['Burners'])."','".trim($_REQUEST['Exchanger'])."','".trim($_REQUEST['Main_Heat_Other'])."','".trim($_REQUEST['Furnace'])."','".trim($_REQUEST['Service'])."','".trim($_REQUEST['Flue'])."','".trim($_REQUEST['Gas'])."','".trim($_REQUEST['Ins_Other'])."','".trim($_REQUEST['maintenance1'])."','".trim($_REQUEST['installation2'])."','".trim($_REQUEST['heating_recommendation'])."',".trim($_REQUEST['id']).")") or die( mysqli_error() ); 


  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function get_sp_product() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['product_id']))
  	{
  				
  		 $product_id = $_REQUEST['product_id'];
  		
  		
if(trim($product_id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL get_sp_product9('".$product_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function discount_type() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");


	$recs = db_iquery($connection,"select * from discount_type") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  	}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sp_update_tbl_repairsolutions_ten() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['optimal_sol']))

  	{
if($_REQUEST['id']!="")
 {

$recs = db_iquery($connection,"CALL sp_update_tbl_repairsolutions_ten9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['optimal_sol_benefits'])."','".trim($_REQUEST['opt_dispatches'])."','".trim($_REQUEST['opt_sal_opp'])."','".trim($_REQUEST['opt_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['opt_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sp_insent_tbl__repairsolutions_ten() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['optimal_sol']))
  	{

$recs = db_iquery($connection,"CALL sp_insent_tbl__repairsolutions_ten9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['optimal_sol_benefits'])."','".trim($_REQUEST['opt_dispatches'])."','".trim($_REQUEST['opt_sal_opp'])."','".trim($_REQUEST['opt_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['opt_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
			//$response['insert_id'] = $ins_id;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sp_update_tbl_repairsolutions() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['essent_sol']))

  	{
if($_REQUEST['id']!="")
 {



$recs = db_iquery($connection,"CALL sp_update_tbl_repairsolutions9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['essent_sol_ben'])."','".trim($_REQUEST['ess_dispatches'])."','".trim($_REQUEST['ess_sal_opp'])."','".trim($_REQUEST['ess_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['ess_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_sp_insert_tbl_repairsolutions() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['essent_sol']))
  	{

$recs = db_iquery($connection,"CALL sp_insert_tbl_repairsolutions9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['essent_sol_ben'])."','".trim($_REQUEST['ess_dispatches'])."','".trim($_REQUEST['ess_sal_opp'])."','".trim($_REQUEST['ess_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['ess_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			
				while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
			//$response['insert_id'] = $ins_id;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_upd_tbl_ten_repairsolutions() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['critical_sol']))

  	{
if($_REQUEST['id']!="")
 {



$recs = db_iquery($connection,"CALL sp_upd_tbl_ten_repairsolutions9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['critical_sol_ben'])."','".trim($_REQUEST['cri_dispatches'])."','".trim($_REQUEST['cri_sal_opp'])."','".trim($_REQUEST['cri_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['cri_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_ins_tbl_repairsolutions() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['critical_sol']))
  	{

$recs = db_iquery($connection,"CALL sp_ins_tbl_repairsolutions9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['critical_sol_ben'])."','".trim($_REQUEST['cri_dispatches'])."','".trim($_REQUEST['cri_sal_opp'])."','".trim($_REQUEST['cri_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['cri_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			
				while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
			//$response['insert_id'] = $ins_id;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function update_special_discount() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['special_discount'],$_REQUEST['id']))

  	{
if($_REQUEST['id']!="")
 {

$recs = db_iquery($connection,"CALL update_special_discount9('".trim($_REQUEST['special_discount'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
   function customer_dynamic_color() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['status']))
		{
			$status = $_REQUEST['status'];			
		}	
		else $status 	= "";
		
		if(trim($company_id) != "" && trim($subscriber_id) != "" )
		{
$recs = db_iquery($connection,"SELECT * FROM tbl_warrantycustomers WHERE subscriber_id = '".$subscriber_id."' AND company_id = '".$company_id."'
AND status ='".$status."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function discount_special() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";				
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";

		if(trim($customer_id) != "" && trim($quote_id) !="" )
		{
			$recs = db_iquery($connection,"CALL discount_special('".$customer_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Customer Id ,Quote Id ,Opt Check are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function balance_update() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";				
		
		
		if (isset($_REQUEST['balance_amount']))
		{
			$balance_amount = $_REQUEST['balance_amount'];			
		}	
		else $balance_amount 	= 0;

		if(trim($customer_id) != "")
		{
			$recs = db_iquery($connection,"CALL balance_update('".$customer_id."','".$balance_amount."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Customer Id ,Quote Id ,Opt Check are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function balance_update1() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";				
		
		
		if (isset($_REQUEST['balance_amount']))
		{
			$balance_amount = $_REQUEST['balance_amount'];			
		}	
		else $balance_amount 	= 0;
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= 0;

		if(trim($customer_id) != "" && trim($quote_id) !="" )
		{
			$recs = db_iquery($connection,"CALL balance_update1('".$customer_id."','".$quote_id."','".$balance_amount."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Customer Id ,Quote Id ,Opt Check are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function tbl_repair_sol() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";				
		

		if(trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL tbl_repair_sol('".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'ID required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_repairsolutions_insert() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['quote_id']))
  	{

$recs = db_iquery($connection,"CALL sp_repairsolutions_insert('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['ess_dispatches'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['ess_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['customer_approvel'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."','".trim($_REQUEST['special_discount'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
			while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
	
	function delete_proposal_product() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	="";
		
		if (isset($_REQUEST['product_id']))
		{
			$product_id = $_REQUEST['product_id'];			
		}	
		else $product_id 	="";
		
		if (isset($_REQUEST['product_name']))
		{
			$product_name = $_REQUEST['product_name'];			
		}	
		else $product_name 	="";
		

		if(trim($workorder_id) != "" && trim($product_id) !="" )
		{
			$recs = db_iquery($connection,"CALL delete_proposal_product('".$subscriber_id."','".$company_id."','".$workorder_id."','".$product_id."','".$product_name."')")
			or die( mysql_error() ); // die ("invalid query");
			
			/*$recs = db_iquery($connection,"DELETE FROM tbl_invoice_quote_footer WHERE company_id ='".$company_id."' AND subscriber_id = '".$subscriber_id."' AND header_id = '".$workorder_id."' AND product_id = '".$product_id."' AND product_des = '".$product_name."'")
			or die( mysql_error() ); // die ("invalid query");*/
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'ID missing');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
  /*SANTHOSH - END*/	
	
	/////////////////////////////////////////////// Balu Created Oct - 19 ///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////// Balu Created Oct - 19 ///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////// Balu Created Oct - 19 ///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////// Balu Created Oct - 19 ///////////////////////////////////////////////////////////////

	function get_sp_alloted_tasks_dashboard() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['date_of_appoinment']))
		{
			$date_of_appoinment = $_REQUEST['date_of_appoinment'];			
		}	
		else $date_of_appoinment 	= "";
		
		if (isset($_REQUEST['quote_header_id']))
		{
			$quote_id = $_REQUEST['quote_header_id'];			
		}	
		else $quote_id 	= "";
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($date_of_appoinment) != "" && trim($quote_id) != "" )
		{
			$recs = db_iquery($connection,"SELECT *,B.firstname as fname, B.lastname as lname FROM tbl_alloted_slots AS A, tbl_customers AS B, tbl_employee AS C, tbl_invoice_quote_header AS D WHERE A.company_id ='".$company_id."' AND A.subscriber_id ='".$subscriber_id."' AND A.employee_id = C.emp_id AND A.customer_id = B.customer_id and A.date_of_appoinment  = '".$date_of_appoinment."' and A.header_quote_id=D.quote_header_id and D.quote_header_id = '".$quote_id."' ORDER BY C.firstname, A.date_of_appoinment,A.start_time, A.end_time")	or die( mysql_error() );  // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_sp_get_user_records() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['warrantycustomers_id']))
		{
			$warranty_type_id = $_REQUEST['warrantycustomers_id'];			
		}	
		else $warranty_type_id 	= "";
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($warranty_type_id) != "")
		{
			$recs = db_iquery($connection,"SELECT * FROM tbl_warrantycustomers WHERE subscriber_id = '".$subscriber_id."'
AND company_id = '".$company_id."'
AND warrantycustomers_id ='".$warranty_type_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_sp_selectactual() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['employee_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$emp_id = $_REQUEST['employee_id'];

  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($emp_id) != "")
  	{	

	$recs = db_iquery($connection,"CALL get_sp_tbl_invoice_quote_header('".$subscriber_id."','".$company_id."','".$emp_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function get_sp_selectsales_opp() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['employee_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$emp_id = $_REQUEST['employee_id'];

  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($emp_id) != "")
  	{	

	$recs = db_iquery($connection,"CALL get_sp_tbl_employee_three('".$subscriber_id."','".$company_id."','".$emp_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function get_sp_selectreplacement_opp() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['employee_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$emp_id = $_REQUEST['employee_id'];

  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($emp_id) != "")
  	{	

	$recs = db_iquery($connection,"CALL get_sp_tbl_employee_invoice_three('".$subscriber_id."','".$company_id."','".$emp_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function get_sp_selectlead_appointments() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['employee_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$emp_id = $_REQUEST['employee_id'];

  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($emp_id) != "")
  	{	

	$recs = db_iquery($connection,"CALL get_sp_tbl_employee_invoice_tech('".$subscriber_id."','".$company_id."','".$emp_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
	
	function sp_dispatch_emp_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['employee_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$emp_id = $_REQUEST['employee_id'];

  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($emp_id) != "")
  	{	

	$recs = db_iquery($connection,"CALL sp_dispatch_emp_three('".$subscriber_id."','".$company_id."','".$emp_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
    function sp_employee_two() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		
  		
if(trim($subscriber_id) != "" && trim($company_id) != ""  )
  	{	

	$recs = db_iquery($connection,"CALL sp_employee_two('".$subscriber_id."','".$company_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function sp_invoice_quote_tech_opp_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['invoice_technician'],$_REQUEST['subscriber_id'],$_REQUEST['company_id']))
  	{
  		
  		$invoice_technician = $_REQUEST['invoice_technician'];
		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];

  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($invoice_technician) != "")
  	{	

	$recs = db_iquery($connection,"CALL sp_invoice_quote_tech_opp_three('".$subscriber_id."','".$company_id."','".$invoice_technician."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function sp_employee_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['employee_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$emp_id = $_REQUEST['employee_id'];
  		
if(trim($subscriber_id) != "" && trim($company_id) != ""  )
  	{	

	$recs = db_iquery($connection,"CALL sp_employee_three('".$subscriber_id."','".$company_id."','".$emp_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
	function sp_service_type_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['status']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$status = $_REQUEST['status'];
  		
if(trim($subscriber_id) != "" && trim($company_id) != ""  )
  	{	

	$recs = db_iquery($connection,"CALL sp_service_type_three('".$subscriber_id."','".$company_id."','".$status."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function sp_customer_type_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['status']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$status = $_REQUEST['status'];
  		
if(trim($subscriber_id) != "" && trim($company_id) != ""  )
  	{	

	$recs = db_iquery($connection,"CALL sp_customer_type_three('".$subscriber_id."','".$company_id."','".$status."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  	
	function sp_employee_type_two() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		
  		
if(trim($subscriber_id) != "" && trim($company_id) != ""  )
  	{	

	$recs = db_iquery($connection,"CALL sp_employee_type_two('".$subscriber_id."','".$company_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  	function sp_calculation_two() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		
  		
if(trim($subscriber_id) != "" && trim($company_id) != ""  )
  	{	

	$recs = db_iquery($connection,"CALL sp_calculation_two('".$subscriber_id."','".$company_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  
  	function sp_servic_type_count() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$fromMonthYear = $_REQUEST['fromMonthYears'];			
		}	
		else $fromMonthYear 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
				
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($fromMonthYear) != "" && trim($employee_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_service_type_count('".$subscriber_id."','".$company_id."','".$fromMonthYear."','".$employee_id."')")
			
			//$recs = db_iquery($connection,"SELECT * FROM tbl_invoice_quote_header AS A JOIN tbl_warrantycustomers AS B ON A.warranty_customers=B.warrantycustomers_id JOIN tbl_alloted_slots AS C ON A.quote_header_id=C.header_quote_id WHERE ((extract(YEAR_MONTH from A.workorder_date)) = (extract(YEAR_MONTH from '".$fromMonthYear."'))) and A.workorder_technician = ".$employee_id." and (A.invoice_remark = 'Recall' or A.invoice_remark = 'recall' or A.invoice_remark = 'RECALL') and A.subscriber_id  ='".$subscriber_id."' and A.company_id =".$company_id."")
			 			or die( mysql_error() ); 
			
			// die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment, Quote Header Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_customer_type_count() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$fromMonthYear = $_REQUEST['fromMonthYears'];			
		}	
		else $fromMonthYear 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['warrantycustomers_id']))
		{
			$warrantycustomers_id = $_REQUEST['warrantycustomers_id'];			
		}	
		else $warrantycustomers_id 	= "";
		
				
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($fromMonthYear) != "" && trim($employee_id) != "" && $warrantycustomers_id !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM tbl_invoice_quote_header AS A JOIN tbl_warrantycustomers AS B ON A.warranty_customers=B.warrantycustomers_id JOIN tbl_alloted_slots AS C ON A.quote_header_id=C.header_quote_id WHERE ((extract(YEAR_MONTH from A.workorder_date)) = (extract(YEAR_MONTH from '".$fromMonthYear."'))) and A.workorder_technician = '".$employee_id."' and A.warranty_customers = '".$warrantycustomers_id."' and A.subscriber_id  ='".$subscriber_id."' and A.company_id ='".$company_id."'")
			or die( mysql_error() ); 
			
			// die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment, Quote Header Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
  	function sp_spreferral_graph() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$fromMonthYear = $_REQUEST['fromMonthYears'];			
		}	
		else $fromMonthYear 	= "";
		
		if (isset($_REQUEST['emp']))
		{
			$emp = $_REQUEST['emp'];			
		}	
		else $emp 	= "";
		
				
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($fromMonthYear) != "")
		{
			if(trim($emp) == ""){
			
			$recs = db_iquery($connection,"CALL sp_spreferral_graph('".$subscriber_id."','".$company_id."','".$fromMonthYear."')")
			or die( mysql_error() ); 
			}
			else
			{
			
			$recs = db_iquery($connection,"CALL sp_spreferral_graphs('".$subscriber_id."','".$company_id."','".$fromMonthYear."','".$emp."')")
			or die( mysql_error() ); 
			}
			// die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment, Quote Header Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function all_sp_tbl_alloted_slots_four() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['date_of_appoinment']))
		{
			$date_of_appoinment = $_REQUEST['date_of_appoinment'];			
		}	
		else $date_of_appoinment 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($date_of_appoinment) != "" && trim($employee_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_tbl_alloted_slots_four('".$company_id."','".$subscriber_id."','".$date_of_appoinment."','".$employee_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function spalloteslotefour() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['employee_id'],$_REQUEST['date_of_appoinment']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$employee_id = $_REQUEST['employee_id'];
  		$date_of_appoinment = $_REQUEST['date_of_appoinment'];
  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($employee_id) != "" && trim($date_of_appoinment) != "" )
  	{	

	$recs = db_iquery($connection,"CALL sp_allote_slote_four('".$subscriber_id."','".$company_id."','".$employee_id."','".$date_of_appoinment."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
    function sp_repairstatus() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			 $company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			 $subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			 $customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			 $quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($customer_id) != "" && trim($quote_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_repair_status('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_repairreplace() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($customer_id) != "" && trim($quote_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_repair_replace('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_energesavings() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($customer_id) != "" && trim($workorder_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_tbl_alloted_slots_four('".$subscriber_id."','".$company_id."','".$customer_id."','".$workorder_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_spsearchpie() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['month']))
		{
			$month = $_REQUEST['month'];			
		}	
		else $month 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_dashtechserch_pie('".$subscriber_id."','".$company_id."','".$month."','".$employee_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id,Date of Appoinment,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	/////////////////////////////////////////////// Balu Created Oct - 19 ///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////// Balu Created Oct - 19 ///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////// Balu Created Oct - 19 ///////////////////////////////////////////////////////////////
	/////////////////////////////////////////////// Balu Created Oct - 19 ///////////////////////////////////////////////////////////////
	
	
	
	//Nov - 04 - 2013
	
	function get_prodsuggestions(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
		if (isset($_REQUEST['term']))
		{
			$term = $_REQUEST['term'];			
		}	
		else $term 	= "";
		
	
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($term) !="")
		{
			$recs = db_iquery($connection,"SELECT product_id,product_name,customer_cost FROM `lkp_products` WHERE product_name like '".$term."%' and subscriber_id='".$subscriber_id."' and company_id='".$company_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}	
	
	function get_prodsuggestions1(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
		if (isset($_REQUEST['term']))
		{
			$term = $_REQUEST['term'];			
		}	
		else $term 	= "";
		
	
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($term) !="")
		{
			$recs = db_iquery($connection,"SELECT product_id,product_name,customer_cost FROM `lkp_products` WHERE product_name like '".$term."%' and subscriber_id='".$subscriber_id."' and company_id='".$company_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_all_products(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
		if (isset($_REQUEST['term']))
		{
			$term = $_REQUEST['term'];			
		}	
		else $term 	= "";
		
	
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($term) !="")
		{
			$recs = db_iquery($connection,"SELECT product_id,product_name FROM `lkp_products` WHERE subscriber_id='".$subscriber_id."' and company_id='".$company_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_repair_details() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['id']))
		{
			$id = $_REQUEST['id'];			
		}	
		else $id 	= "";
		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($id) != "")
		{
			$recs = db_iquery($connection,"SELECT * FROM tbl_repairsolutions WHERE subscriber_id=".$subscriber_id." and company_id=".$company_id." and id=".$id."")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber ,Id Company Id ,Customer Id ,Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_emp_invoice_quote_header() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['all_emp']))
		{
			$all_emp = $_REQUEST['all_emp'];			
		}	
		else $all_emp 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id 	= $_REQUEST['company_id'];		
		}	
		else $company_id 	= "";
		

		
		if(trim($all_emp) != "" && trim($subscriber_id) != "" && trim($company_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_get_three_tbl_invoice_quote_header('".$all_emp."','".$subscriber_id."','".$company_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'All Emp , subscriber_id And Company Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function sp_get_upgrade_goals () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_get_upgrade_goals('".$subscriber_id."','".$company_id."','".$month."','".$employee_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_energy_smart_actuals () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" )
		{
			$recs = db_iquery($connection,"SELECT *,sum(B.product_quanity) as amount FROM tbl_invoice_quote_header as A join tbl_invoice_quote_footer as B on A.quote_header_id=B.header_id WHERE A.subscriber_id  ='".$subscriber_id."' and A.company_id ='".$company_id."' and ((extract(YEAR_MONTH from A.invoice_date)) = (extract(YEAR_MONTH from '".$month."'))) and A.invoice_technician = '".$employee_id."'  and B.prod_department='8'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_energy_smart_goals () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" )
		{
			$recs = db_iquery($connection,"SELECT * from tbl_goals WHERE subscriber_id = '".$subscriber_id."' and company_id = '".$company_id."' and  	month_year = '".$month."' and emp_id = '".$employee_id."' and (service_type = 'ESC Membership')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_upgrade_actuals () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_get_upgrade_actuals('".$subscriber_id."','".$company_id."','".$month."','".$employee_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_goalss () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
				
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
	
		
		if(trim($employee_id) != "" && trim($month) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_get_goalss('".$month."','".$employee_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_graphinvoiceamount() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id  	= $_REQUEST['company_id'];		
		}	
		else $company_id  	= "";
		
				if (isset($_REQUEST['month_year']))
		{
			$month_year 	= $_REQUEST['month_year'];		
		}	
		else $month_year  	= "";
		
					if (isset($_REQUEST['invoice_technician']))
		{
			$invoice_technician 	= $_REQUEST['invoice_technician'];		
		}	
		else $invoice_technician 	= "";
		
		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($month_year) != "" && trim($invoice_technician) != "")
		{
		
			$recs = db_iquery($connection,"CALL sp_getgraph_invoice('".$subscriber_id."','".$company_id."','".$month_year."','".$invoice_technician."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id,InvoiceTechnician Id and Company Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_goalss_esc () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['remark_type']))
		{
			$service_type = $_REQUEST['remark_type'];			
		}	
		else $service_type 	= "";
		
		if (isset($_REQUEST['servicetype_id']))
		{
			$servicetype_id = $_REQUEST['servicetype_id'];			
		}	
		else $servicetype_id 	= "";
		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($month) != "" && trim($employee_id) != "" && trim($service_type) != ""&& trim($servicetype_id) != "")
		{
			$recs = db_iquery($connection,"SELECT * from tbl_goals WHERE subscriber_id = '".$subscriber_id."' and company_id = '".$company_id."' and month_year = '".$month."' and emp_id = '".$employee_id."' and service_type = '".$service_type."' and service_type_id = '".$servicetype_id."' and service_type != 'ESC Membership'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_actualss () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
		if (isset($_REQUEST['remark_type']))
		{
			$remark_type = $_REQUEST['remark_type'];			
		}	
		else $remark_type 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" && trim($remark_type) != "")
		{
			$recs = db_iquery($connection,"SELECT *,sum(B.product_total_amount) as amount FROM tbl_invoice_quote_header as A join tbl_invoice_quote_footer as B on A.quote_header_id=B.header_id WHERE A.subscriber_id  ='".$subscriber_id."' and A.company_id ='".$company_id."' and ((extract(YEAR_MONTH from A.invoice_date)) = (extract(YEAR_MONTH from '".$month."'))) and A.invoice_technician = '".$employee_id."' and A.invoice_remark = '".$remark_type."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_actualss_product () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = trim($_REQUEST['company_id']);			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = trim($_REQUEST['subscriber_id']);			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = trim($_REQUEST['employee_id']);			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = trim($_REQUEST['fromMonthYears']);			
		}	
		else $month 	= "";
		
		if (isset($_REQUEST['servicetype_id']))
		{
			$servicetype_id = trim($_REQUEST['servicetype_id']);			
		}	
		else $servicetype_id 	= "";
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" && trim($servicetype_id) 
		!='')
		{
			$recs = db_iquery($connection,"SELECT *,sum(B.product_total_amount) as amount FROM tbl_invoice_quote_header as A join tbl_invoice_quote_footer as B on A.quote_header_id=B.header_id WHERE A.subscriber_id  ='".$subscriber_id."' and A.company_id ='".$company_id."' and ((extract(YEAR_MONTH from A.invoice_date)) = (extract(YEAR_MONTH from '".$month."'))) and A.invoice_technician = '".$employee_id."' and B.prod_department='".$servicetype_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_actualss_product1 () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = trim($_REQUEST['company_id']);			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = trim($_REQUEST['subscriber_id']);			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = trim($_REQUEST['employee_id']);			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = trim($_REQUEST['fromMonthYears']);			
		}	
		else $month 	= "";
		
		if (isset($_REQUEST['servicetype_id']))
		{
			$servicetype_id = trim($_REQUEST['servicetype_id']);			
		}	
		else $servicetype_id 	= "";
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" && trim($servicetype_id) 
		!='')
		{
			$recs = db_iquery($connection,"SELECT *,sum(B.product_total_amount) as amount FROM tbl_invoice_quote_header as A join tbl_invoice_quote_footer as B on A.quote_header_id=B.header_id WHERE A.subscriber_id  ='".$subscriber_id."' and A.company_id ='".$company_id."' and ((extract(YEAR_MONTH from A.invoice_date)) = (extract(YEAR_MONTH from '".$month."'))) and A.invoice_technician = '".$employee_id."' and B.prod_responsibility='".$servicetype_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function sp_get_actuals () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
		if (isset($_REQUEST['remark_type']))
		{
			$remark_type = $_REQUEST['remark_type'];			
		}	
		else $remark_type 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" && trim($remark_type) != "")
		{
			$recs = db_iquery($connection,"SELECT *,sum(B.product_total_amount) as amount FROM tbl_invoice_quote_header as A join tbl_invoice_quote_footer as B on A.quote_header_id=B.header_id WHERE A.subscriber_id  ='".$subscriber_id."' and A.company_id ='".$company_id."' and ((extract(YEAR_MONTH from A.invoice_date)) = (extract(YEAR_MONTH from '".$month."'))) and A.invoice_technician = '".$employee_id."' and A.invoice_remark = '".$remark_type."'")
			or die( mysql_error() ); // die ("invalid query");
					
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function sp_destination_name() {
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
		
		
		if (isset($_REQUEST['designation_id']))
		{
			$designation_id = $_REQUEST['designation_id'];			
		}	
		else $designation_id 	= "";
		if(trim($designation_id) != "" )
		{
			$recs = db_iquery($connection,"CALL sp_des_name('".$designation_id."')") or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'No record found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'designation_id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function ipad_login_invoice_quote_header() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['ref_tech']))
		{
			$ref_tech = $_REQUEST['ref_tech'];			
		}	
		else $ref_tech 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id 	= $_REQUEST['company_id'];		
		}	
		else $company_id 	= "";
		

		
		if(trim($ref_tech) != "" && trim($subscriber_id) != "" && trim($company_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_get_tbl_invoice_quote_header('".$ref_tech."','".$subscriber_id."','".$company_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Ref Tech , subscriber_id And Company Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}	
	
 
  function sp_up_espi_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['authorizationcode'],$_REQUEST['customer_id'],$_REQUEST['quote_id']))
  	{
  				
  		     $authorizationcode = $_REQUEST['authorizationcode'];
		     $customer_id = $_REQUEST['customer_id'];
		     $quote_id = $_REQUEST['quote_id'];
		    
  	

	 $recs = db_iquery($connection,"CALL sp_up_espi_three('".trim($authorizationcode)."','".trim($customer_id)."','".trim($quote_id)."')") or die( mysqli_error() ); 

  	if (isset($recs))
	{
		$output = array("success"=>'Record Uptated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

   // echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
   function sp_uptbl_invoice_quote_header() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['authorization_code'],$_REQUEST['authorization_verified'],$_REQUEST['customer_id'],$_REQUEST['quote_header_id']))
  	{
  				
  		     $authorizationcode = $_REQUEST['authorization_code'];
			 $authorization_verified = $_REQUEST['authorization_verified'];
		     $customer_id = $_REQUEST['customer_id'];
		     $quote_header_id = $_REQUEST['quote_header_id'];
		    
  	

	 $recs = db_iquery($connection,"CALL sp_uptbl_invoice_quote_header('".trim($authorizationcode)."','".trim($authorization_verified)."','".trim($customer_id)."','".trim($quote_header_id)."')") or die( mysqli_error() ); 

  	if (isset($recs))
	{
		$output = array("success"=>'Record Uptated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

   // echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function all_sle_tbl_invoice_quote_header() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['quote_header_id']))
		{
			$quote_header_id = $_REQUEST['quote_header_id'];			
		}	
		else $quote_header_id 	= "";
		
		

		
		if(trim($quote_header_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_tbl_invoice_quote_header('".$quote_header_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Header Id   are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 function sp_up_tbl_customersone() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['email'],$_REQUEST['customer_id']))
  	{
  				
  		     $email = $_REQUEST['email'];
		     $customer_id = $_REQUEST['customer_id'];
		    
		    
  	

	 $recs = db_iquery($connection,"CALL sp_up_tbl_customersone('".trim($email)."','".trim($customer_id)."')") or die( mysqli_error() ); 

  	if (isset($recs))
	{
		$output = array("success"=>'Record Uptated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

   // echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
   function sp_tbl_invoice_quote_header() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";				
		
		if (isset($_REQUEST['quote_header_id']))
		{
			$quote_header_id = $_REQUEST['quote_header_id'];			
		}	
		else $workorder_id 	= "";
		
		if(trim($customer_id) != "" && trim($quote_header_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_tbl_invoiceheader_one('".$customer_id."','".$quote_header_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id, are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_sp_sle_two_lkp_productdepartment() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				

		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		

		
		if(trim($subscriber_id) != ""  && trim($company_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_two_lkp_productdepartment('".$subscriber_id."','".$company_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id,Company Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function all_sp_sle_two_lkp_productdepartment1(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($subscriber_id) !="" && trim($company_id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `lkp_productdepartment` WHERE subscriber_id='".$subscriber_id."' and company_id='".$company_id."' and status='Yes' and product_type='Yes'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function all_sp_sle_two_lkp_productdepartment2(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($subscriber_id) !="" && trim($company_id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `lkp_productdepartment` WHERE subscriber_id='".$subscriber_id."' and company_id='".$company_id."' and status='Yes' and service_type='Yes'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function sp_ins_espi_all() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['quote_id'],$_REQUEST['customer_id']))
  	{

$recs = db_iquery($connection,"CALL sp_ins_espi_all1('".trim($_REQUEST['into_house'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['out_of_house'])."','".trim($_REQUEST['electric_provider'])."','".trim($_REQUEST['electric_rate'])."','".trim($_REQUEST['electric_expiry'])."','".trim($_REQUEST['gas_provider'])."','".trim($_REQUEST['gas_rate'])."','".trim($_REQUEST['gas_expiry'])."','".trim($_REQUEST['electric_bill'])."','".trim($_REQUEST['gas_bill'])."','".trim($_REQUEST['living'])."','".trim($_REQUEST['home_build'])."','".trim($_REQUEST['sqft'])."','".trim($_REQUEST['occupants'])."','".trim($_REQUEST['winter'])."','".trim($_REQUEST['summer'])."','".trim($_REQUEST['warranty'])."','".trim($_REQUEST['warranty_others'])."','".trim($_REQUEST['smart_club'])."','".trim($_REQUEST['expiration_date'])."','".trim($_REQUEST['lights_off'])."','".trim($_REQUEST['conserve_water'])."','".trim($_REQUEST['havc'])."','".trim($_REQUEST['cfl'])."','".trim($_REQUEST['thermostat'])."','".trim($_REQUEST['swimming_pool'])."','".trim($_REQUEST['pets'])."','".trim($_REQUEST['summer_humidity'])."','".trim($_REQUEST['try_winter'])."','".trim($_REQUEST['hot_or_cold'])."','".trim($_REQUEST['noise_concerns'])."','".trim($_REQUEST['frequency_dusting'])."','".trim($_REQUEST['allergies'])."','".trim($_REQUEST['other_concern'])."','".trim($_REQUEST['source_control'])."','".trim($_REQUEST['filtration'])."','".trim($_REQUEST['humidity'])."','".trim($_REQUEST['purification'])."','".trim($_REQUEST['ventilation'])."','".trim($_REQUEST['indoor_recommendation'])."','".trim($_REQUEST['leakage'])."','".trim($_REQUEST['insulation'])."','".trim($_REQUEST['ventilation1'])."','".trim($_REQUEST['radiant_barrier'])."','".trim($_REQUEST['attic_recommendation'])."','".trim($_REQUEST['insulation_text'])."','".trim($_REQUEST['air_cond_age'])."','".trim($_REQUEST['age'])."','".trim($_REQUEST['efficiency_seer'])."','".trim($_REQUEST['efficiency_seer_text'])."','".trim($_REQUEST['evacoil'])."','".trim($_REQUEST['duct_insulation'])."','".trim($_REQUEST['heating_efficiency'])."','".trim($_REQUEST['pumps'])."','".trim($_REQUEST['afue'])."','".trim($_REQUEST['effseer'])."','".trim($_REQUEST['fueltype'])."','".trim($_REQUEST['variablespeed'])."','".trim($_REQUEST['Blower'])."','".trim($_REQUEST['Burners'])."','".trim($_REQUEST['Exchanger'])."','".trim($_REQUEST['Main_Heat_Other'])."','".trim($_REQUEST['Furnace'])."','".trim($_REQUEST['Service'])."','".trim($_REQUEST['Flue'])."','".trim($_REQUEST['Gas'])."','".trim($_REQUEST['Ins_Other'])."','".trim($_REQUEST['maintenance'])."','".trim($_REQUEST['evaporator_coil'])."','".trim($_REQUEST['condenser_coil'])."','".trim($_REQUEST['primary_pan'])."','".trim($_REQUEST['drain_line'])."','".trim($_REQUEST['other'])."','".trim($_REQUEST['installation1'])."','".trim($_REQUEST['Disconnect'])."','".trim($_REQUEST['Level'])."','".trim($_REQUEST['Raise'])."','".trim($_REQUEST['Insulate'])."','".trim($_REQUEST['Relocate'])."','".trim($_REQUEST['Strap'])."','".trim($_REQUEST['Inspection'])."','".trim($_REQUEST['Inline'])."','".trim($_REQUEST['Secondary'])."','".trim($_REQUEST['Hard'])."','".trim($_REQUEST['Surge'])."','".trim($_REQUEST['Quick'])."','".trim($_REQUEST['Otherins'])."','".trim($_REQUEST['air_cond_recommendation'])."','".trim($_REQUEST['heating_age'])."','".trim($_REQUEST['heating'])."','".trim($_REQUEST['efficiency'])."','".trim($_REQUEST['maintenance1'])."','".trim($_REQUEST['installation2'])."','".trim($_REQUEST['heating_recommendation'])."','".trim($_REQUEST['duct_age'])."','".trim($_REQUEST['duct_age_check'])."','".trim($_REQUEST['insulation2'])."','".trim($_REQUEST['design'])."','".trim($_REQUEST['installation3'])."','".trim($_REQUEST['return_leakage'])."','".trim($_REQUEST['supply_leakage'])."','".trim($_REQUEST['insulationrvalue'])."','".trim($_REQUEST['noise'])."','".trim($_REQUEST['uneventemp'])."','".trim($_REQUEST['drafts'])."','".trim($_REQUEST['highstaticpressure'])."','".trim($_REQUEST['noofreturns'])."','".trim($_REQUEST['seal'])."','".trim($_REQUEST['stretch'])."','".trim($_REQUEST['ductstrap'])."','".trim($_REQUEST['straighten'])."','".trim($_REQUEST['duct_recommendation'])."','".trim($_REQUEST['espi_status'])."','".trim($_REQUEST['presentation_document'])."','".trim($_REQUEST['Supply_Duct_Leakage'])."','".trim($_REQUEST['Return_Leakage1'])."','".trim($_REQUEST['Unsealed_Registers'])."','".trim($_REQUEST['Unsealed_Attic_Ladder'])."','".trim($_REQUEST['Unsealed_Attic_Penetrations'])."','".trim($_REQUEST['Electronic'])."','".trim($_REQUEST['Media'])."','".trim($_REQUEST['Pure_Air'])."','".trim($_REQUEST['ACCU_Clean'])."','".trim($_REQUEST['filteration_Other'])."','".trim($_REQUEST['Filter_Location'])."','".trim($_REQUEST['At_Furnace'])."','".trim($_REQUEST['Mold_On_Grills'])."','".trim($_REQUEST['T_point'])."','".trim($_REQUEST['UV_Purification'])."','".trim($_REQUEST['light_at_coil'])."','".trim($_REQUEST['ventilation_None'])."','".trim($_REQUEST['Fresh_Air_Intake'])."','".trim($_REQUEST['ERV'])."','".trim($_REQUEST['ventilation_Other'])."','".trim($_REQUEST['Attic_Ladder'])."','".trim($_REQUEST['Plumbing_Pene'])."','".trim($_REQUEST['Electrical_Pene'])."','".trim($_REQUEST['HVAC_Pene'])."','".trim($_REQUEST['Fiberglass'])."','".trim($_REQUEST['Greater'])."','".trim($_REQUEST['Soffits_Clear'])."','".trim($_REQUEST['Ridge_Vent'])."','".trim($_REQUEST['Gable_Vent'])."','".trim($_REQUEST['Power_Ventil'])."','".trim($_REQUEST['Whirly_Bird'])."','".trim($_REQUEST['Solar_Attic'])."','".trim($_REQUEST['blocked'])."','".trim($_REQUEST['Cool_Ply'])."','".trim($_REQUEST['Spray_On'])."','".trim($_REQUEST['Staple'])."','".trim($_REQUEST['None'])."','".trim($_REQUEST['instal_type'])."','".trim($_REQUEST['return_grill_size1'])."','".trim($_REQUEST['return_duct_size1'])."','".trim($_REQUEST['system_ton1'])."','".trim($_REQUEST['return_grill_size2'])."','".trim($_REQUEST['return_duct_size2'])."','".trim($_REQUEST['system_ton2'])."','".trim($_REQUEST['return_grill_size3'])."','".trim($_REQUEST['return_duct_size3'])."','".trim($_REQUEST['system_ton3'])."','".trim($_REQUEST['return_grill_size4'])."','".trim($_REQUEST['return_duct_size4'])."','".trim($_REQUEST['system_ton4'])."','".trim($_REQUEST['return_grill_size5'])."','".trim($_REQUEST['return_duct_size5'])."','".trim($_REQUEST['system_ton5'])."','".trim($_REQUEST['return_grill_size6'])."','".trim($_REQUEST['return_duct_size6'])."','".trim($_REQUEST['system_ton6'])."','".trim($_REQUEST['return_grill_size7'])."','".trim($_REQUEST['return_duct_size7'])."','".trim($_REQUEST['system_ton7'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
    function all_inst_tbl_invoice_quote_header() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['company_id'],$_REQUEST['subscriber_id'],$_REQUEST['customer_id']))
  	{

$recs = db_iquery($connection,"CALL sp_inst_tbl_invoice_quote_header('".trim($_REQUEST['company_id'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['workorder_number'])."','".trim($_REQUEST['workorder_created_by'])."','".trim($_REQUEST['workorder_created_on'])."','".trim($_REQUEST['workorder_updated_by'])."',
'".trim($_REQUEST['workorder_updated_on'])."','".trim($_REQUEST['workorder_service_manager'])."','".trim($_REQUEST['workorder_technician'])."','".trim($_REQUEST['workorder_salesmanager'])."','".trim($_REQUEST['ageof_equibment'])."','".trim($_REQUEST['warranty_customers'])."','".trim($_REQUEST['lead_source'])."','".trim($_REQUEST['pre_work_no'])."','".trim($_REQUEST['ref_workorder_id'])."','".trim($_REQUEST['workorder_date'])."','".trim($_REQUEST['workorder_recommendation'])."','".trim($_REQUEST['workorder_newstatus'])."','".trim($_REQUEST['invoice_technician'])."','".trim($_REQUEST['invoice_date'])."','".trim($_REQUEST['warranty_workorder'])."','".trim($_REQUEST['inside_sales'])."','".trim($_REQUEST['customer_confirmed'])."','".trim($_REQUEST['workorder_source'])."','".trim($_REQUEST['workorder_des_work'])."','".trim($_REQUEST['diagnosis'])."','".trim($_REQUEST['cause'])."','".trim($_REQUEST['consultant_workorder'])."','".trim($_REQUEST['workorder_seq_num'])."','".trim($_REQUEST['all_emp'])."','".trim($_REQUEST['payment_pending'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
			while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
   function insert_tbl_invoice_quote_footer() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['header_id']))
  	{

$recs = db_iquery($connection,"CALL insert_tbl_invoice_quote_footer('".trim($_REQUEST['company_id'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['header_id'])."','".trim($_REQUEST['product_id'])."','".trim($_REQUEST['product_des'])."','".trim($_REQUEST['radio_check'])."','".trim($_REQUEST['radio_type'])."','".trim($_REQUEST['product_quanity'])."','".trim($_REQUEST['product_unit_price'])."','".trim($_REQUEST['net_customer_cost'])."','".trim($_REQUEST['discount'])."','".trim($_REQUEST['esc_savings'])."','".trim($_REQUEST['total_esc_savings'])."','".trim($_REQUEST['product_type'])."','".trim($_REQUEST['product_total_amount'])."','".trim($_REQUEST['prod_responsibility'])."','".trim($_REQUEST['prod_department'])."','".trim($_REQUEST['prod_upgrade'])."','".trim($_REQUEST['product_tax'])."','".trim($_REQUEST['quote_type'])."','".trim($_REQUEST['workorder_type'])."','".trim($_REQUEST['invioice_type'])."','".trim($_REQUEST['reciept_type'])."','".trim($_REQUEST['opt_yesno'])."','".trim($_REQUEST['ess_yesno'])."','".trim($_REQUEST['cri_yesno'])."','".trim($_REQUEST['add_line'])."','".trim($_REQUEST['wtype'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
			$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
   function get_inst_tbl_invoice_quote_header_replacement() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['company_id'],$_REQUEST['subscriber_id'],$_REQUEST['customer_id']))
  	{

$recs = db_iquery($connection,"CALL tbl_invoice_quote_header_replacement('".trim($_REQUEST['company_id'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['workorder_number'])."','".trim($_REQUEST['workorder_created_by'])."','".trim($_REQUEST['workorder_created_on'])."','".trim($_REQUEST['workorder_updated_by'])."',
'".trim($_REQUEST['workorder_updated_on'])."','".trim($_REQUEST['workorder_service_manager'])."','".trim($_REQUEST['workorder_technician'])."','".trim($_REQUEST['workorder_salesmanager'])."','".trim($_REQUEST['ageof_equibment'])."','".trim($_REQUEST['warranty_customers'])."','".trim($_REQUEST['lead_source'])."','".trim($_REQUEST['pre_work_no'])."','".trim($_REQUEST['ref_workorder_id'])."','".trim($_REQUEST['workorder_date'])."','".trim($_REQUEST['workorder_recommendation'])."','".trim($_REQUEST['workorder_newstatus'])."','".trim($_REQUEST['invoice_technician'])."','".trim($_REQUEST['invoice_date'])."','".trim($_REQUEST['warranty_workorder'])."','".trim($_REQUEST['inside_sales'])."','".trim($_REQUEST['customer_confirmed'])."','".trim($_REQUEST['workorder_source'])."','".trim($_REQUEST['workorder_des_work'])."','".trim($_REQUEST['diagnosis'])."','".trim($_REQUEST['cause'])."','".trim($_REQUEST['consultant_workorder'])."','".trim($_REQUEST['workorder_seq_num'])."','".trim($_REQUEST['all_emp'])."','".trim($_REQUEST['payment_pending'])."','".trim($_REQUEST['invoice_remark'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
			while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function get_inst_tbl_invoice_quote_header_replacement1() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['company_id'],$_REQUEST['subscriber_id'],$_REQUEST['customer_id']))
  	{

$recs = db_iquery($connection,"CALL tbl_invoice_quote_header_replacement1('".trim($_REQUEST['company_id'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['workorder_number'])."','".trim($_REQUEST['workorder_created_by'])."','".trim($_REQUEST['workorder_created_on'])."','".trim($_REQUEST['workorder_updated_by'])."',
'".trim($_REQUEST['workorder_updated_on'])."','".trim($_REQUEST['workorder_service_manager'])."','".trim($_REQUEST['workorder_technician'])."','".trim($_REQUEST['workorder_salesmanager'])."','".trim($_REQUEST['ageof_equibment'])."','".trim($_REQUEST['warranty_customers'])."','".trim($_REQUEST['lead_source'])."','".trim($_REQUEST['pre_work_no'])."','".trim($_REQUEST['ref_workorder_id'])."','".trim($_REQUEST['workorder_date'])."','".trim($_REQUEST['workorder_recommendation'])."','".trim($_REQUEST['workorder_newstatus'])."','".trim($_REQUEST['invoice_technician'])."','".trim($_REQUEST['invoice_date'])."','".trim($_REQUEST['warranty_workorder'])."','".trim($_REQUEST['inside_sales'])."','".trim($_REQUEST['customer_confirmed'])."','".trim($_REQUEST['workorder_source'])."','".trim($_REQUEST['workorder_des_work'])."','".trim($_REQUEST['diagnosis'])."','".trim($_REQUEST['cause'])."','".trim($_REQUEST['consultant_workorder'])."','".trim($_REQUEST['workorder_seq_num'])."','".trim($_REQUEST['all_emp'])."','".trim($_REQUEST['payment_pending'])."','".trim($_REQUEST['invoice_remark'])."','".trim($_REQUEST['tot_pay_amount'])."','".trim($_REQUEST['part_payment'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
			while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}
  			//$output[] = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function  sp_tbl_repairsolutionstwo() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id']))
  	{
  				
  		
		$customer_id =$_REQUEST['customer_id'];
  		$quote_id = $_REQUEST['quote_id'];
  		
if(trim($customer_id!= "" && $quote_id!= ""))
  	{	

	$recs = db_iquery($connection,"CALL sp_sle_two_tbl_repairsolutions('".$customer_id."','".$quote_id."')") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }

	function all_sp_sle_energy_savings() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";				
		
		if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	= "";
		
		
		
		if(trim($customer_id) != "" && (trim($workorder_id)) !="" )
		{
			$recs = db_iquery($connection,"CALL sp_sle_energy_savings('".$customer_id."','".$workorder_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Customer_id ,Workorder Id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function sp_sel_tbl_all_uploadedfiles() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			$recs = db_iquery($connection,"CALL sp_sel_tbl_all_uploadedfiles()")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		
	

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function all_upd_tbl_invoice_quote_header() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['follow_up'],$_REQUEST['ref_tech'],$_REQUEST['quote_header_id'])){
if($_REQUEST['quote_header_id']!="")
 {

$recs = db_iquery($connection,"CALL sp_upd_tbl_invoice_quote_header('".trim($_REQUEST['follow_up'])."','".trim($_REQUEST['ref_tech'])."','".trim($_REQUEST['quote_header_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
	function all_four_tbl_repairsolutions() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id  = $_REQUEST['customer_id'];			
		}	
		else $customer_id  	= "";
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id  = $_REQUEST['quote_id'];			
		}	
		else $quote_id  	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_four_tbl_repairsolutions('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Or Quote Quote Id   are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function all_four_tbl_invoice_quote_header() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['quote_header_id']))
		{
			$quote_header_id  = $_REQUEST['quote_header_id'];			
		}	
		else $quote_header_id  	= "";
		
		

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($quote_header_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_four_tbl_invoice_quote_header('".$subscriber_id."','".$company_id."','".$quote_header_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Quote Header Id   are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
   /*function  sp_invoice_quote_footeramount() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['header_id']))
  	{
  				
  		  $header_id  = $_REQUEST['header_id'];
  		  $prod_responsibility1   = $_REQUEST['prod_responsibility1'];
		  $prod_responsibility2   = $_REQUEST['prod_responsibility2'];
		  
	}
if(trim($header_id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL sp_sle_tbl_invoice_quote_footeramount('".$header_id ."','".$prod_responsibility1."','".$prod_responsibility2."')") or die( mysqli_error() ); 

  	if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		
		else 
		{
		 $output[] = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }*/
  
   function tbl_invoice_quote_header_update() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['quote_header_id']))
  	{
		 $cash=$_REQUEST['cash'];
	     $pay_amt_cash=$_REQUEST['pay_amt_cash'];
	     $activate_cash=$_REQUEST['activate_cash'];
		 $credit_card=$_REQUEST['credit_card'];
		 $pay_amt_credit=$_REQUEST['pay_amt_credit'];
		 $transaction_id=$_REQUEST['transaction_id'];
		 $activate=$_REQUEST['activate'];
		 
		 $first_name=$_REQUEST['first_name'];
		 $last_name=$_REQUEST['last_name'];
		 $ccredit_card=$_REQUEST['ccredit_card'];
		 $cvv_no=$_REQUEST['cvv_no'];
		 $month=$_REQUEST['month'];
		 $year=$_REQUEST['year'];
		 
		 $check1=$_REQUEST['check1'];
		 $finance=$_REQUEST['finance'];
		 $finance_pro_by1=$_REQUEST['finance_pro_by1'];
		 $finance_pro_by2=$_REQUEST['finance_pro_by2'];
		 $finance_pro_by3=$_REQUEST['finance_pro_by3'];
		 $pay_amt_finance=$_REQUEST['pay_amt_finance'];
		 $pay_amt_finance2=$_REQUEST['pay_amt_finance2'];
		 $pay_amt_finance3=$_REQUEST['pay_amt_finance3'];
		 $pay_amt_check=$_REQUEST['pay_amt_check'];
		 $bank_no=$_REQUEST['bank_no'];
		 $check_no=$_REQUEST['check_no'];
		 $tot_pay_amount=$_REQUEST['tot_pay_amount'];
		 $part_payment=$_REQUEST['part_payment'];
		 $signature=$_REQUEST['signature'];
		 $pay_pending_reason=$_REQUEST['pay_pending_reason'];
		 $invoice_technician=$_REQUEST['invoice_technician'];
		 $invoice_date=$_REQUEST['invoice_date'];
		 $workorder_newstatus=$_REQUEST['workorder_newstatus'];
		 $quote_header_id=$_REQUEST['quote_header_id'];
		 $pay_method=$_REQUEST['pay_method'];
		 $time=date('H:i:s');
		
  		
	$recs = db_iquery($connection,"CALL sp_tbl_invoice_quote_header_update('".trim($cash)."','".trim($pay_amt_cash)."','".trim($activate_cash)."','".trim($credit_card)."','".trim($pay_amt_credit)."','".trim($transaction_id)."','".trim($activate)."','".trim($first_name)."','".trim($last_name)."','".trim($ccredit_card)."','".trim($cvv_no)."','".trim($month)."','".trim($year)."','".trim($check1)."','".trim($finance)."','".trim($finance_pro_by1)."','".trim($finance_pro_by2)."','".trim($finance_pro_by3)."','".trim($pay_amt_finance)."','".trim($pay_amt_finance2)."','".trim($pay_amt_finance3)."','".trim($pay_amt_check)."','".trim($bank_no)."','".trim($check_no)."','".trim($tot_pay_amount)."','".trim($part_payment)."','".trim($pay_method)."','".trim($signature)."','".trim($pay_pending_reason)."','".trim($invoice_technician)."','".trim($invoice_date)."','".trim($workorder_newstatus)."','".trim($quote_header_id)."','".trim($time)."')") or die( mysqli_error() ); 
  	if (isset($recs))
	{
		$output = array("Successmsg"=>'Record Update Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
   function sp_up_customer_updone() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['email'],$_REQUEST['customer_id']))
  	{


$recs = db_iquery($connection,"CALL sp_up_customer_updone('".trim($_REQUEST['email'])."','".trim($_REQUEST['customer_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function  sp_sel_espi_quote() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['quote_id']))
  	{
  				
  		 $quote_id = $_REQUEST['quote_id'];
  		
  		
if(trim($quote_id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL sp_sel_espi_quote('".$quote_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 


    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function sp_sel_tbl_all_furnace_brand() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			$recs = db_iquery($connection,"CALL sp_sel_tbl_all_furnace_brand()")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		
	

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
  function all_ins_ten_tbl_furnace() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['company_id'],$_REQUEST['subscriber_id'],$_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['acunit_br_one'],$_REQUEST['acunit_br_sec'],$_REQUEST['furnace_br'],$_REQUEST['acunit_mod_one'],$_REQUEST['acunit_mod_sec'],$_REQUEST['furnace_mod'],$_REQUEST['created_date']))
  	{

$recs = db_iquery($connection,"CALL sp_ten_tbl_furnace('".trim($_REQUEST['company_id'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['acunit_br_one'])."','".trim($_REQUEST['acunit_br_sec'])."','".trim($_REQUEST['furnace_br'])."','".trim($_REQUEST['acunit_mod_one'])."','".trim($_REQUEST['acunit_mod_sec'])."','".trim($_REQUEST['furnace_mod'])."','".trim($_REQUEST['created_date'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_ins_ten_tbl_filtration() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['company_id'],$_REQUEST['subscriber_id'],$_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['f_type'],$_REQUEST['f_brand'],$_REQUEST['f_height'],$_REQUEST['f_width'],$_REQUEST['f_depth'],$_REQUEST['f_location'],$_REQUEST['created_date']))
  	{

$recs = db_iquery($connection,"CALL sp_ten_tbl_filtration('".trim($_REQUEST['company_id'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['f_type'])."','".trim($_REQUEST['f_brand'])."','".trim($_REQUEST['f_height'])."','".trim($_REQUEST['f_width'])."','".trim($_REQUEST['f_depth'])."','".trim($_REQUEST['f_location'])."','".trim($_REQUEST['created_date'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	}
  
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_nine_tbl_furnace() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['acunit_br_one'],$_REQUEST['acunit_br_sec'],$_REQUEST['furnace_br'],$_REQUEST['acunit_mod_one'],$_REQUEST['acunit_mod_sec'],$_REQUEST['furnace_mod'],$_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['furnace_id']))
  	{

$recs = db_iquery($connection,"CALL sp_nine_tbl_furnace('".trim($_REQUEST['acunit_br_one'])."','".trim($_REQUEST['acunit_br_sec'])."','".trim($_REQUEST['furnace_br'])."','".trim($_REQUEST['acunit_mod_one'])."','".trim($_REQUEST['acunit_mod_sec'])."','".trim($_REQUEST['furnace_mod'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['furnace_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_nine_tbl_filtration() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['f_type'],$_REQUEST['f_brand'],$_REQUEST['f_height'],$_REQUEST['f_width'],$_REQUEST['f_depth'],$_REQUEST['f_location'],$_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['filtration_id']))
  	{

$recs = db_iquery($connection,"CALL sp_nine_tbl_filtration('".trim($_REQUEST['f_type'])."','".trim($_REQUEST['f_brand'])."','".trim($_REQUEST['f_height'])."','".trim($_REQUEST['f_width'])."','".trim($_REQUEST['f_depth'])."','".trim($_REQUEST['f_location'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['filtration_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function all_three_tbl_invoice_quote_header() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['diagnosis'],$_REQUEST['cause'],$_REQUEST['quote_header_id']))
  	{

$recs = db_iquery($connection,"CALL sp_three_tbl_invoice_quote_header('".trim($_REQUEST['diagnosis'])."','".trim($_REQUEST['cause'])."','".trim($_REQUEST['quote_header_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function tbl_furnaceone_getall() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['furnace_id']))
  	{
  				
  		$furnace_id = $_REQUEST['furnace_id'];
  		
  		
if(trim($furnace_id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL sp_ten_tbl_furnaceone_getall('".$furnace_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function tbl_filtrationone_getall() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['filtarion_id']))
  	{
  				
  		$filtarion_id = $_REQUEST['filtarion_id'];
  		
  		
if(trim($filtarion_id)!= "")
  	{	

	$recs = db_iquery($connection,"CALL sp_ten_tbl_filtrationone_getall('".$filtarion_id."')") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function sp_upd_tbl_furnaceoneopneval() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['status'],$_REQUEST['furnace_id']))
  	{
  				
  		     $status = $_REQUEST['status'];
		     $furnace_id = $_REQUEST['furnace_id'];
		    
		    
  	

	 $recs = db_iquery($connection,"CALL sp_upd_tbl_furnaceoneopne('".trim($status)."','".trim($furnace_id)."')") or die( mysqli_error() ); 

  	if (isset($recs))
	{
		$output = array("success"=>'Record Uptated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

   // echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function sp_upd_tbl_filtrationoneopneval() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['status'],$_REQUEST['filtarion_id']))
  	{
  				
  	$status = $_REQUEST['status'];
	$filtarion_id = $_REQUEST['filtarion_id'];
	
	$recs = db_iquery($connection,"CALL sp_upd_tbl_filtrationoneopne('".trim($status)."','".trim($filtarion_id)."')") or die( mysqli_error() ); 
  	if (isset($recs))
	{
		$output = array("success"=>'Record Uptated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 
  	
	

   // echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function ipad_logout()
  {
		header("location:index.php");
  }	
	 // Send a HTTP response code/message
  function sendResponse($status = 200, $body = '', $content_type = 'text/html')
  {
    $status_header = 'HTTP/1.1 ' . $status . ' ' . getStatusCodeMessage($status);
    header($status_header);
    header('Content-type: ' . $content_type);
    echo $body;
  }
  
  
   // Balu - Nov - 08
 
function all_three_tbl_customers() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_three_tbl_customers('".$subscriber_id."','".$company_id."','".$customer_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber Id ,Company Id And Customer Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

function all_sle_tbl_repairreplace() { 
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		
		if (isset($_REQUEST['quote_id']))
		{
			$quote_id = $_REQUEST['quote_id'];			
		}	
		else $quote_id 	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($quote_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_tbl_repairreplace('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber ,Id Company Id ,customer_id ,Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
function all_sle_energy_savings() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";
		
		
		if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	= "";

		
		if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($customer_id) != "" && trim($workorder_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_sle_energy_savings_four('".$subscriber_id."','".$company_id."','".$customer_id."','".$workorder_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Subscriber ,Id Company Id ,customer_id ,Workorder Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

function get_all_products_details(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";				
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";
		
		
		if(trim($subscriber_id) !="" && trim($company_id) !="")
		{
			$recs = db_iquery($connection,"SELECT * FROM `lkp_products` WHERE subscriber_id='".$subscriber_id."' and company_id='".$company_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
function sp_get_discount_amount(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		
			
		if (isset($_REQUEST['header_id']))
		{
			$header_id = $_REQUEST['header_id'];			
		}	
		else $header_id 	= "";				
		
		if(trim($header_id) !="")
		{
			$recs = db_iquery($connection,"SELECT discount_type,special_discount FROM `tbl_repairsolutions` WHERE quote_id =".$header_id."")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Quote Id are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}

function all_sp_tbl_invoice_quote_header_five() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['customer_id']))
		{
			$customer_id = $_REQUEST['customer_id'];			
		}	
		else $customer_id 	= "";				
		
		if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	= "";
		
		if(trim($customer_id) != "" && trim($workorder_id) != "")
		{
			$recs = db_iquery($connection,"CALL sp_tbl_invoice_quote_header_five('".$customer_id."','".$workorder_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Invalid Authentication!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company Id , Subscriber Id, are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
function sp_get_tbl_repairsolutions_three() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['id']))
  	{
  				
  		 $subscriber_id = $_REQUEST['subscriber_id'];
		 $company_id = $_REQUEST['company_id'];
		 $id = $_REQUEST['id'];
  		
if(trim($subscriber_id!= "" && $company_id!= ""  && $id!= ""))
  	{	

	$recs = db_iquery($connection,"CALL sp_get_tbl_repairsolutions_three('".$subscriber_id."','".$company_id."','".$id."')") or die( mysqli_error() ); 
  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
function all_ints_ten_tbl_repairreplace() {
  	$response['code'] = 0;
  	$response['status'] = 400;

  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");
	
 if ($_REQUEST['quote_id'])
  	{
$recs = db_iquery($connection,"CALL sp_ints_ten_tbl_repairreplace('".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['optimal_sol_benefits'])."','".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['essent_sol_ben'])."','".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['critical_sol_ben'])."','".trim($_REQUEST['opt_dispatches'])."','".trim($_REQUEST['opt_sal_opp'])."','".trim($_REQUEST['opt_rep_opp'])."','".trim($_REQUEST['ess_dispatches'])."','".trim($_REQUEST['ess_sal_opp'])."','".trim($_REQUEST['ess_rep_opp'])."','".trim($_REQUEST['cri_dispatches'])."','".trim($_REQUEST['cri_sal_opp'])."','".trim($_REQUEST['cri_rep_opp'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_approval'])."','".trim($_REQUEST['created_date'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
			while($row=mysqli_fetch_object($recs))
			{ $output[] =  $row;}
  			//$output = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Inseting');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  } 

function insert_tbl_repairsolutions() {
  	$response['code'] = 0;
  	$response['status'] = 400;

  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");
	
 if ($_REQUEST['quote_id'])
  	{
$recs = db_iquery($connection,"CALL insert_tbl_repairsolutions('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['ess_dispatches'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['ess_check'])."','".trim($_REQUEST['cri_check'])."','".trim($_REQUEST['opt_investment'])."','".trim($_REQUEST['ess_investment'])."','".trim($_REQUEST['cri_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['customer_approvel'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_approval'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."','".trim($_REQUEST['special_discount'])."','".trim($_REQUEST['balance_amount'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Inserted Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Inseting');
  			$response['status'] = 400;
  		}
		
	
	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  } 

function sp_update_repair() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id'],$_REQUEST['optimal_sol'],$_REQUEST['optimal_sol_benefits'],$_REQUEST['essent_sol'],$_REQUEST['essent_sol_ben'],$_REQUEST['critical_sol'],$_REQUEST['critical_sol_ben'],$_REQUEST['opt_dispatches'],$_REQUEST['opt_sal_opp'],$_REQUEST['opt_rep_opp'],$_REQUEST['ess_dispatches'],$_REQUEST['ess_sal_opp'],$_REQUEST['ess_rep_opp'],$_REQUEST['cri_dispatches'],$_REQUEST['cri_sal_opp'],$_REQUEST['cri_rep_opp'],$_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['customer_approval'],$_REQUEST['created_date'],$_REQUEST['id']))

  	{
if($_REQUEST['id']!="")
 {
$recs = db_iquery($connection,"CALL get_upd_tbl_repairsolutions('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['optimal_sol_benefits'])."','".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['essent_sol_ben'])."','".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['critical_sol_ben'])."','".trim($_REQUEST['opt_dispatches'])."','".trim($_REQUEST['opt_sal_opp'])."','".trim($_REQUEST['opt_rep_opp'])."','".trim($_REQUEST['ess_dispatches'])."','".trim($_REQUEST['ess_sal_opp'])."','".trim($_REQUEST['ess_rep_opp'])."','".trim($_REQUEST['cri_dispatches'])."','".trim($_REQUEST['cri_sal_opp'])."','".trim($_REQUEST['cri_rep_opp'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_approval'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['id'])."')") or die( mysqli_error() ); 


  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
			
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	else
  		{
  			$output = array("errmsg"=>'Primary Id Is Empty');
  			$response['status'] = 400;
  		}	
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function get_map() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['employee_id'],$_REQUEST['date_of_appoinment']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$employee_id = $_REQUEST['employee_id'];
  		$date_of_appoinment = $_REQUEST['date_of_appoinment'];
  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($employee_id) != "" && trim($date_of_appoinment) != "" )
  	{	

	$recs = db_iquery($connection,"select B.address1,B.address2,B.new_address,B.city,B.state,B.zip from tbl_alloted_slots as A join tbl_customers as B on A.customer_id=B.customer_id join lkp_state as C on B.state=C.state_id join tbl_invoice_quote_header as D on A.header_quote_id=D.quote_header_id and A.subscriber_id ='".$subscriber_id."' and A.company_id =".$company_id." and A.employee_id = ".$employee_id." and date_of_appoinment = '".$date_of_appoinment."'") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
  
  function sp_get_upgrade_upgoals () {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['company_id']))
		{
			$company_id = $_REQUEST['company_id'];			
		}	
		else $company_id 	= "";				
		
		if (isset($_REQUEST['subscriber_id']))
		{
			$subscriber_id = $_REQUEST['subscriber_id'];			
		}	
		else $subscriber_id 	= "";
		
		if (isset($_REQUEST['employee_id']))
		{
			$employee_id = $_REQUEST['employee_id'];			
		}	
		else $employee_id 	= "";
		
		if (isset($_REQUEST['fromMonthYears']))
		{
			$month = $_REQUEST['fromMonthYears'];			
		}	
		else $month 	= "";
		
	
		
		if(trim($company_id) != "" && trim($subscriber_id) != ""  && trim($employee_id) != "" && trim($month) != "" )
		{
			$recs = db_iquery($connection,"SELECT * from tbl_goals WHERE subscriber_id = '".$subscriber_id."' and company_id = '".$company_id."' and month_year = '".$month."' and emp_id = '".$employee_id."' and (service_type = 'Upgrades')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record Not Found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Company ID , Subscriber ID,From,Employee_id  are required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
 
 function get_lead_sold() { 
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

 if (isset($_REQUEST['subscriber_id'],$_REQUEST['company_id'],$_REQUEST['ref_tech']))
  	{
  		$subscriber_id = $_REQUEST['subscriber_id'];		
  		$company_id = $_REQUEST['company_id'];
  		$ref_tech = $_REQUEST['ref_tech'];
  		
if(trim($subscriber_id) != "" && trim($company_id) != "" && trim($ref_tech) != "")
  	{	

	$recs = db_iquery($connection,"SELECT * FROM tbl_invoice_quote_header WHERE ref_tech = '".$ref_tech."' and subscriber_id  ='".$subscriber_id."' and company_id ='".$company_id."' and YEAR(invoice_date) = YEAR(CURDATE()) AND MONTH(invoice_date) = MONTH(CURDATE())") or die( mysqli_error() ); 

  	if (isset($recs) && mysqli_num_rows($recs) > 0)
  	{
  		while($row=mysqli_fetch_object($recs)) {
			$output[] = $row;
  			}
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Record not found');
  			$response['status'] = 400;
  		}
		}
		else 
		{
		 $output = array("errmsg"=>'Argument are Empty.');
  		$response['status'] = 400; 
		} 
  	}
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
 // Balu - Nov - 08 
 
 function update_tbl_invoice_quote_footer() {
  	$response['code'] = 0;
  	$response['status'] = 400;
  	$response['data'] = NULL;
  	$contenttype = 'application/json; charset=utf-8';
	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");

if (isset($_REQUEST['quote_footer_id']))
	{

$recs = db_iquery($connection,"UPDATE `tbl_invoice_quote_footer` SET `product_id` = ".$_REQUEST['product_id'].",`product_des` = '".$_REQUEST['product_des']."',`radio_check` = '".$_REQUEST['radio_check']."',`product_quanity` = '".$_REQUEST['product_quanity']."',product_unit_price=".$_REQUEST['product_unit_price'].",product_total_amount=".$_REQUEST['product_total_amount'].",prod_responsibility='".$_REQUEST['prod_responsibility']."',prod_department='".$_REQUEST['prod_department']."',opt_yesno='".$_REQUEST['opt_yesno']."',ess_yesno='".$_REQUEST['ess_yesno']."',cri_yesno='".$_REQUEST['cri_yesno']."',wtype='".$_REQUEST['wtype']."',add_line='".$_REQUEST['add_line']."' WHERE `quote_footer_id` = '".trim($_REQUEST['quote_footer_id'])."'") or die( mysqli_error() ); 
  			if(isset($recs))
  			{
  			$output = array("errmsg"=>'Record Updated Successfully');
  			$response['code'] = 1;
  			$response['status'] = 200;
  		}
  		else
  		{
  			$output = array("errmsg"=>'Error While Updating');
  			$response['status'] = 400;
  		}
		
	}
	 	
	else 
		{
		 $output = array("errmsg"=>'Argument is missing.');
  		$response['status'] = 400; 
		} 

    //echo json_encode($output);exit();
  	$response['data'] = $output;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  } 
  
  function employee_geoloc_tracking(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'

		$response['status'] = 404;

		$contenttype = 'application/json; charset=utf-8';	
		
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id= "";
		if (isset($_REQUEST['EmplolyeeID'])){$EmplolyeeID = $_REQUEST['EmplolyeeID'];}else $EmplolyeeID= "";
		if (isset($_REQUEST['DateTime'])){$DateTime = $_REQUEST['DateTime'];	}else $DateTime = "";
		if (isset($_REQUEST['MacId'])){$MacId = $_REQUEST['MacId'];	}else $MacId = "";
		if (isset($_REQUEST['DeviceId'])){$DeviceId = $_REQUEST['DeviceId'];	}else $DeviceId = "";
		if (isset($_REQUEST['Latitude'])){$Latitude = $_REQUEST['Latitude'];	}else $Latitude = "";
		if (isset($_REQUEST['Longitude'])){$Longitude = $_REQUEST['Longitude'];	}else $Longitude = "";
		
		if((trim($subscriber_id) !="") && (trim($EmplolyeeID) !="") && (trim($DateTime) !="") && (trim($MacId) !="") && (trim($DeviceId) !="") && (trim($Latitude) !="") && (trim($Longitude) !=""))
		{			
		$recs = db_iquery($connection,"CALL employee_geoloc_tracking('".$subscriber_id."','".$EmplolyeeID."','".$DateTime."','".$MacId."','".$DeviceId."','".$Latitude."','".$Longitude."')")
			or die( mysql_error() ); // die ("invalid query");
			
			$response['message'] = 'Data is inserted';
			$response['status'] = 200;
		}
		else
		{
			$response['errmsg'] = 'Some data is missed';
			$response['status'] = 404;
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	
	function get_user_history(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
if (isset($_REQUEST['employee_id'])){$employee_id = $_REQUEST['employee_id'];	}else $employee_id 	= "";
if (isset($_REQUEST['fromdate']))	{$fromdate = $_REQUEST['fromdate'];	} else $fromdate 	= "";
if (isset($_REQUEST['todate']))	{$todate = $_REQUEST['todate'];	} else $todate 	= "";					
					
			
		if(trim($employee_id) !="" && trim($fromdate) !="")
		{
$recs = db_iquery($connection,"SELECT Latitude, Longitude
FROM temployeetracking where DateTime >= '".$fromdate." 01:00:00'
AND DateTime <= '".$todate." 24:00:00'
AND subscriber_id =  'desss'
AND EmplolyeeID =  '".$employee_id."' group by Latitude")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Records is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_user_history_first(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
if (isset($_REQUEST['employee_id'])){$employee_id = $_REQUEST['employee_id'];	}else $employee_id 	= "";
if (isset($_REQUEST['fromdate']))	{$fromdate = $_REQUEST['fromdate'];	} else $fromdate 	= "";
if (isset($_REQUEST['todate']))	{$todate = $_REQUEST['todate'];	} else $todate 	= "";				
					
			
		if(trim($employee_id) !="")
		{
$recs = db_iquery($connection,"SELECT Latitude, Longitude
FROM temployeetracking where DateTime >= '".$fromdate." 01:00:00'
AND DateTime <= '".$todate." 24:00:00'
AND subscriber_id =  'desss'
AND EmplolyeeID =  '".$employee_id."' ORDER BY id ASC
LIMIT 1")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Records is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_user_history_last(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		// Set default HTTP response of 'ok'
		$response['code'] = 0;
		$response['status'] = 404;
		$response['data'] = NULL;
		$contenttype = 'application/json; charset=utf-8';	
		
if (isset($_REQUEST['employee_id'])){$employee_id = $_REQUEST['employee_id'];	}else $employee_id 	= "";
if (isset($_REQUEST['fromdate']))	{$fromdate = $_REQUEST['fromdate'];	} else $fromdate 	= "";
if (isset($_REQUEST['todate']))	{$todate = $_REQUEST['todate'];	} else $todate 	= "";	
				
					
			
		if(trim($employee_id) !="")
		{
$recs = db_iquery($connection,"SELECT Latitude, Longitude
FROM temployeetracking where DateTime >= '".$fromdate." 01:00:00'
AND DateTime <= '".$todate." 24:00:00'
AND subscriber_id =  'desss'
AND EmplolyeeID =  '".$employee_id."'
ORDER BY id DESC
LIMIT 1")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}	
				$response['code'] = 1;
				$response['status'] = 200;
			}
			else
			{
				$output[] = array("errmsg"=>'Record not found!');
				$response['status'] = 400;
			}
		}
		else
		{

			$output[] = array("errmsg"=>'Records is required!');
			$response['status'] = 400;
		}		

		$response['data'] = $output;
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function device_based_auth() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['mac_address'])){$macaddress = $_REQUEST['mac_address'];}else $macaddress= "";
		if (isset($_REQUEST['device_uuid'])){$device_uuid = $_REQUEST['device_uuid'];}else $device_uuid= "";
		if (isset($_REQUEST['device_platform'])){$device_platform = $_REQUEST['device_platform'];}else $device_platform = "";
		if (isset($_REQUEST['passcode'])){$passcode = $_REQUEST['passcode'];}else $passcode = "";
		
		if((trim($macaddress) !="") && (trim($device_uuid) !="") && (trim($device_platform) !="") && (trim($passcode) !=""))
		{	
			$recs = db_iquery($connection,"CALL device_based_auth('".$macaddress."','".$device_uuid."','".$device_platform."','".$passcode."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				$response['code'] = 1;
				$response['status'] = 200;
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}
				$response['data'] = $output;
			}
			else
			{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"failed","device"=>"Unregistered device");
			}
		}
		else
		{

				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"failed","device"=>"Device data missed");
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function device_based_info() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['macaddress'])){$macaddress = $_REQUEST['macaddress'];}else $macaddress= "";
		if (isset($_REQUEST['device_uuid'])){$device_uuid = $_REQUEST['device_uuid'];}else $device_uuid= "";
		if (isset($_REQUEST['device_platform'])){$device_platform = $_REQUEST['device_platform'];}else $device_platform = "";
		
		if((trim($macaddress) !="") && (trim($device_uuid) !="") && (trim($device_platform) !=""))
		{	
			$recs = db_iquery($connection,"CALL device_based_info('".$macaddress."','".$device_uuid."','".$device_platform."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				$response['code'] = 1;
				$response['status'] = 200;
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}
				$response['data'] = $output;
			}
			else
			{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"failed","device"=>"Unregistered device");
			}
		}
		else
		{

				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"failed","device"=>"Device data missed");
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function get_register_trusted_device() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['macaddress'])){$macaddress = $_REQUEST['macaddress'];}else $macaddress= "";
		if (isset($_REQUEST['device_uuid'])){$device_uuid = $_REQUEST['device_uuid'];}else $device_uuid= "";
		if (isset($_REQUEST['device_platform'])){$device_platform = $_REQUEST['device_platform'];}else $device_platform = "";
		if (isset($_REQUEST['member_id'])){$member_id = $_REQUEST['member_id'];}else $member_id= "";  
		if (isset($_REQUEST['password'])){$password = $_REQUEST['password'];}else $password= "";  
		if (isset($_REQUEST['passcode'])){$passcode = $_REQUEST['passcode'];}else $passcode = "";
		$subscriber_id = "desss";
		
		if((trim($macaddress) !="") && (trim($device_uuid) !="") && (trim($device_platform) !="") && (trim($member_id) !="") && (trim($password) !="") && (trim($passcode) !=""))
		{	
			$recs1 = db_iquery($connection,"CALL sp_getlogin_employee('".$subscriber_id."','".$member_id."','".$password."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs1) > 0)
			{	
				while($row=mysqli_fetch_object($recs1))
				{
				$employee_id =  $row->emp_id;
				}
			     $connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		         $recs2 = db_iquery($connection,"CALL get_register_trusted_device_count('".$employee_id."')")
			     or die( mysqli_error() ); // die ("invalid query");
			
			     if (mysqli_num_rows($recs2) < 5)
			     {
				$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
			$recs2 = db_iquery($connection,"CALL get_register_trusted_device('".$employee_id."','".$macaddress."','".$device_uuid."','".$device_platform."','".$passcode."')")
			or die( mysqli_error() ); // die ("invalid query");
			
				$response['code'] = 1;
				$response['status'] = 200;
				$response['data'] = array("status"=>"Successfully registered");
			}else{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"Unable to register. Device count reached");
			}
			}else{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"Unable to register. Authentication failed");
			}

		}
		else
		{

				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"Unable to register. Parameters missed");
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function delete_associated_parts(){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';	
		if (isset($_REQUEST['workorder_id']))
		{
			$workorder_id = $_REQUEST['workorder_id'];			
		}	
		else $workorder_id 	= "";				

		
		if(trim($workorder_id) !="")
		{
			$recs = db_iquery($connection,"DELETE FROM `workorder_parts` WHERE workorder_no='".$workorder_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			    $response['code'] = 1;
				$response['status'] = 200;
				$response['data'] = array("status"=>"Successfully deleted");
		}
		else
		{
			$response['code'] = 1;
			$response['status'] = 400;
			$response['data'] = array("status"=>"Workorder id missed");
			
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function single_action_rendering() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id= "";
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id= "";
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id = "";
		if (isset($_REQUEST['quote_id'])){$quote_id = $_REQUEST['quote_id'];}else $quote_id = "";

		
		if((trim($subscriber_id) !="") && (trim($company_id) !="") && (trim($customer_id) !=""))
		{	
		    $response['code'] = 1;
			$response['status'] = 200;
			
			$recs1 = db_iquery($connection,"CALL sp_three_tbl_customers('".$subscriber_id."','".$company_id."','".$customer_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs1) > 0)
			{	
				while($row1=mysqli_fetch_object($recs1))
				{
				$customer_information[] =  $row1;
				}	
				$response['customer_information'] =  $customer_information;
				
			}
			else
			{
				$response['customer_information'] = array("errmsg"=>'No Record');
			}
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
			$recs = db_iquery($connection,"CALL sp_four_tbl_furnace('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($diagnose_cause_furnace=mysqli_fetch_object($recs))
				{
				$diagnose_cause_furnace_out[] =  $diagnose_cause_furnace;
				}	
				$response['diagnose_cause_furnace'] =  $diagnose_cause_furnace_out;
			}
			else
			{
				$response['diagnose_cause_furnace'] = array("errmsg"=>'No Record');
			}
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
			$recs = db_iquery($connection,"CALL sp_four_tbl_filtration('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($sp_four_tbl_filtration=mysqli_fetch_object($recs))
				{
				$sp_four_tbl_filtration_out[] =  $sp_four_tbl_filtration;
				}	
				$response['sp_four_tbl_filtration'] =  $sp_four_tbl_filtration_out;
			}
			else
			{
				$response['sp_four_tbl_filtration'] = array("errmsg"=>'No Record');
			}
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
			$recs = db_iquery($connection,"CALL sp_sle_tbl_repairreplace('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($repair_and_replace=mysqli_fetch_object($recs))
				{
				$repair_and_replace_out[] =  $repair_and_replace;
				}	
				$response['repair_and_replace'] =  $repair_and_replace_out;
			}
			else
			{
				$response['repair_and_replace'] = array("errmsg"=>'No Record');
			}
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
			$recs = db_iquery($connection,"CALL sp_one_espi_sa('".$customer_id."','".$quote_id."')") or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				
				$espi[] =  $row;
				}	
				$response['espi'] =  $espi;
			}
			else
			{
				$response['espi'] = array("errmsg"=>'No Record!');
			}
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$recs = db_iquery($connection,"CALL sp_four_tbl_invoice_quote_header('".$subscriber_id."','".$company_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($row=mysqli_fetch_object($recs))
				{
				
				$workorder_information[] =  $row;
				}
				$response['workorder_information'] =  $workorder_information;	
				
			}
			else
			{
				$response['workorder_information'] = array("errmsg"=>'No Record');
			}
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$recs = db_iquery($connection,"SELECT * FROM `tbl_invoice_quote_footer` WHERE header_id='".$quote_id."' and add_line=2 ORDER BY quote_footer_id asc")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($repair_solutions_product=mysqli_fetch_object($recs))
				{
				$repair_solutions_product_output[] =  $repair_solutions_product;
				}	
				$response['client_product'] =  $repair_solutions_product_output;
			}
			else
			{
				$response['client_product'] = array("errmsg"=>'No Record');
			}
			/*$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$recs3 = db_iquery($connection,"CALL sp_sle_one_tbl_invoice_quote_footer('".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs3) > 0)
			{	
				while($row3=mysqli_fetch_object($recs3))
				{
				
				$output[] =  $row3;
				}	
				$response['workorder_product'] =  $output;
			}
			else
			{
				$response['workorder_product'] = array("errmsg"=>'No Record');
			}*/
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$recs = db_iquery($connection,"SELECT * FROM tbl_invoice_quote_footer WHERE header_id = '".$quote_id."' AND workorder_type = 'Yes' AND add_line!=2")
			or die( mysql_error() ); // die ("invalid query");
			
						
			/*$recs = db_iquery($connection,"CALL sp_sle_two_tbl_invoice_quote_footer('".$quote_id."','Yes')")
			or die( mysql_error() ); // die ("invalid query");*/
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($products_screen=mysqli_fetch_object($recs))
				{
				$products_screen_output[] =  $products_screen;
				}	
				$response['products_screen'] =  $products_screen_output;
			}
			else
			{
				$response['products_screen'] = array("errmsg"=>'No Record');
			}
			
			
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$recs = db_iquery($connection,"CALL sp_four_tbl_furnace2('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($overview_page_furnace1=mysqli_fetch_object($recs))
				{
				$overview_page_furnace1_output[] =  $overview_page_furnace1;
				}	
				$response['overview_page_furnace1'] =  $overview_page_furnace1_output;
			}
			else
			{
				$response['overview_page_furnace1'] = array("errmsg"=>'No Record');
			}
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$recs = db_iquery($connection,"CALL sp_four_tbl_furnace1('".$subscriber_id."','".$company_id."','".$customer_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($overview_page_furnace2=mysqli_fetch_object($recs))
				{
				$overview_page_furnace2_output[] =  $overview_page_furnace2;
				}	
				$response['overview_page_furnace2'] = $overview_page_furnace2_output;
			}
			else
			{
				$response['overview_page_furnace2'] = array("errmsg"=>'No Record');
			}
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$recs = db_iquery($connection,"CALL get_repairsolutions_other('".$subscriber_id."','".$company_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($get_repair_solution_values=mysqli_fetch_object($recs))
				{
				$get_repair_solution_values_output[] =  $get_repair_solution_values;
				}	
				$response['get_repair_solution_values'] = $get_repair_solution_values_output;
			}
			else
			{
				$response['get_repair_solution_values'] = array("errmsg"=>'No Record');
			}
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$recs = db_iquery($connection,"SELECT id,workorder_no,part_qty,description,part,vendor_id,bill_to_id,status_id FROM `workorder_parts` WHERE workorder_no='".$quote_id."'")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				while($get_parts=mysqli_fetch_object($recs))
				{
				$get_parts_output[] =  $get_parts;
				}	
				$response['get_parts'] = $get_parts_output;
			}
			else
			{
				$response['get_parts'] = array("errmsg"=>'No Record');
			}
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");
			$invoice_status = db_iquery($connection,"CALL sp_tbl_invoice_quote_header_five('".$customer_id."','".$quote_id."')")
			or die( mysql_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($invoice_status) > 0)
			{	
				while($invoice_status_obj=mysqli_fetch_object($invoice_status))
				{
				$invoice_status_val['invoice_status'] =  $invoice_status_obj->workorder_newstatus;
				$invoice_status_val['authorization_verified'] =  $invoice_status_obj->authorization_verified; 
				}	
				$response['workorder_status'] = $invoice_status_val;
			}
			else
			{
				$response['workorder_status'] = array("errmsg"=>'No Record');
			}
			
			
		}
		else
		{

				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"Parameters missed");
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
	function single_chain_update() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
  	$contenttype = 'application/json; charset=utf-8';
	


	if($_REQUEST['customer_id']!="") {
		
		$recs = db_iquery($connection,"UPDATE `tbl_customers` SET `zip` = '".trim($_REQUEST['zip'])."', `address1` = '".trim($_REQUEST['address1'])."',`new_address` = '".trim($_REQUEST['new_address'])."',`address2` = '".trim($_REQUEST['address2'])."', `suite` = '".trim($_REQUEST['suite'])."', `map` = '".trim($_REQUEST['map'])."', `city` = '".trim($_REQUEST['city'])."', `state` = '".trim($_REQUEST['state'])."', `phone_number` = '".trim($_REQUEST['phone_number'])."', `firstname` = '".trim($_REQUEST['firstname'])."', `lastname` = '".trim($_REQUEST['lastname'])."', `cell_phone` = '".trim($_REQUEST['cell_phone'])."', `customer_type` = '".trim($_REQUEST['customer_type'])."', `warranty_customers` = '".trim($_REQUEST['warranty_customers'])."', `warranty_workorder` = '".trim($_REQUEST['warranty_workorder'])."', `work_phone` = '".trim($_REQUEST['work_phone'])."', `email` = '".trim($_REQUEST['email'])."' WHERE `customer_id` = '".trim($_REQUEST['customer_id'])."'") or die( mysqli_error() );
		if(isset($recs)){
				$response['customer_information'] = array("errmsg"=>'Record Updated Successfully');
		}
  	}else{
				$response['customer_information'] = array("errmsg"=>"Parameters missed");
	}
	
	if(isset($_REQUEST['quote_id'],$_REQUEST['customer_id'],$_REQUEST['electric_provider'],$_REQUEST['electric_rate'],$_REQUEST['electric_expiry'],$_REQUEST['gas_provider'],$_REQUEST['gas_rate'],$_REQUEST['gas_expiry'],$_REQUEST['electric_bill'],$_REQUEST['gas_bill'],$_REQUEST['living'],$_REQUEST['home_build'],$_REQUEST['sqft'],$_REQUEST['occupants'],$_REQUEST['winter'],$_REQUEST['summer'],$_REQUEST['warranty'],$_REQUEST['warranty_others'],$_REQUEST['smart_club'],$_REQUEST['expiration_date'],$_REQUEST['into_house'],$_REQUEST['out_of_house'],$_REQUEST['espi_id'])){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$recs = db_iquery($connection,"CALL sp_up_espi_twthree('".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['electric_provider'])."','".trim($_REQUEST['electric_rate'])."','".trim($_REQUEST['electric_expiry'])."','".trim($_REQUEST['gas_provider'])."','".trim($_REQUEST['gas_rate'])."','".trim($_REQUEST['gas_expiry'])."','".trim($_REQUEST['electric_bill'])."','".trim($_REQUEST['gas_bill'])."','".trim($_REQUEST['living'])."','".trim($_REQUEST['home_build'])."','".trim($_REQUEST['sqft'])."','".trim($_REQUEST['occupants'])."','".trim($_REQUEST['winter'])."','".trim($_REQUEST['summer'])."','".trim($_REQUEST['warranty'])."','".trim($_REQUEST['warranty_others'])."','".trim($_REQUEST['smart_club'])."','".trim($_REQUEST['expiration_date'])."','".trim($_REQUEST['into_house'])."','".trim($_REQUEST['out_of_house'])."','".trim($_REQUEST['espi_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs)){
  				$response['espi_information'] = array("errmsg"=>'Record Updated Successfully');
  			}
	}else{
				$response['espi_information'] = array("errmsg"=>"Parameters missed");
  	} 
	
	if (isset($_REQUEST['lights_off'],$_REQUEST['conserve_water'],$_REQUEST['havc'],$_REQUEST['cfl'],$_REQUEST['thermostat'],$_REQUEST['swimming_pool'],$_REQUEST['pets'],$_REQUEST['summer_humidity'],$_REQUEST['hot_or_cold'],$_REQUEST['try_winter'],$_REQUEST['noise_concerns'],$_REQUEST['frequency_dusting'],$_REQUEST['allergies'],$_REQUEST['other_concern'],$_REQUEST['espi_id']))
  	{
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$recs = db_iquery($connection,"CALL espi_customer_prac_up('".trim($_REQUEST['lights_off'])."','".trim($_REQUEST['conserve_water'])."','".trim($_REQUEST['havc'])."','".trim($_REQUEST['cfl'])."','".trim($_REQUEST['thermostat'])."','".trim($_REQUEST['swimming_pool'])."','".trim($_REQUEST['pets'])."','".trim($_REQUEST['summer_humidity'])."','".trim($_REQUEST['hot_or_cold'])."','".trim($_REQUEST['try_winter'])."','".trim($_REQUEST['noise_concerns'])."','".trim($_REQUEST['frequency_dusting'])."','".trim($_REQUEST['allergies'])."','".trim($_REQUEST['other_concern'])."','".trim($_REQUEST['espi_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$response['espi_customer_practices'] = array("errmsg"=>'Record Updated Successfully');
  		    }
	}else{
  			$response['espi_customer_practices'] = array("errmsg"=>'Parameters missed');
  	}
	
	if(isset($_REQUEST['quote_id'])){
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
$recs = db_iquery($connection,"CALL sp_up_nine_espi('".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['source_control'])."','".trim($_REQUEST['filtration'])."','".trim($_REQUEST['humidity'])."','".trim($_REQUEST['purification'])."','".trim($_REQUEST['ventilation'])."','".trim($_REQUEST['indoor_recommendation'])."','".trim($_REQUEST['Supply_Duct_Leakage'])."','".trim($_REQUEST['Return_Leakage'])."','".trim($_REQUEST['Unsealed_Registers'])."','".trim($_REQUEST['Unsealed_Attic_Ladder'])."','".trim($_REQUEST['Unsealed_Attic_Penetrations'])."','".trim($_REQUEST['Electronic'])."','".trim($_REQUEST['Media'])."','".trim($_REQUEST['Pure_Air'])."','".trim($_REQUEST['ACCU_Clean'])."','".trim($_REQUEST['filteration_Other'])."','".trim($_REQUEST['Filter_Location'])."','".trim($_REQUEST['Mold_On_Grills'])."','".trim($_REQUEST['T_point'])."','".trim($_REQUEST['UV_Purification'])."','".trim($_REQUEST['light_at_coil'])."','".trim($_REQUEST['ventilation_None'])."','".trim($_REQUEST['Fresh_Air_Intake'])."','".trim($_REQUEST['ERV'])."','".trim($_REQUEST['ventilation_Other'])."','".trim($_REQUEST['instal_type'])."','".trim($_REQUEST['espi_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$response['espi_iaq'] = array("errmsg"=>'Record Updated Successfully');
  		    }
	}else{
  			$response['espi_iaq'] = array("errmsg"=>'Parameters missed');
  	}
	
	if (isset($_REQUEST['leakage'],$_REQUEST['insulation'],$_REQUEST['ventilation1'],$_REQUEST['radiant_barrier'],$_REQUEST['attic_recommendation'],$_REQUEST['insulation_text'],$_REQUEST['Attic_Ladder'],$_REQUEST['Plumbing_Pene'],$_REQUEST['Electrical_Pene'],$_REQUEST['HVAC_Pene'],$_REQUEST['Fiberglass'],$_REQUEST['Greater'],$_REQUEST['Soffits_Clear'],$_REQUEST['Ridge_Vent'],$_REQUEST['Gable_Vent'],$_REQUEST['Power_Ventil'],$_REQUEST['Whirly_Bird'],$_REQUEST['Solar_Attic'],$_REQUEST['blocked'],$_REQUEST['Cool_Ply'],$_REQUEST['Spray_On'],$_REQUEST['Staple'],$_REQUEST['None'],$_REQUEST['espi_id'])){
  				
  		     $leakage = $_REQUEST['leakage'];
		     $insulation = $_REQUEST['insulation'];
		     $ventilation1 = $_REQUEST['ventilation1'];
		     $radiant_barrier = $_REQUEST['radiant_barrier'];
		     $attic_recommendation = $_REQUEST['attic_recommendation'];
		     $insulation_text = $_REQUEST['insulation_text'];
			 $Attic_Ladder  			    = $_REQUEST['Attic_Ladder'];
		     $Plumbing_Pene  			= $_REQUEST['Plumbing_Pene'];
		     $Electrical_Pene  			= $_REQUEST['Electrical_Pene'];
		     $HVAC_Pene  			    = $_REQUEST['HVAC_Pene'];
		     $Fiberglass  			    = $_REQUEST['Fiberglass'];
		     $Greater  			        = $_REQUEST['Greater'];
		     $Soffits_Clear  			= $_REQUEST['Soffits_Clear'];
		     $Ridge_Vent  			    = $_REQUEST['Ridge_Vent'];
		     $Gable_Vent  			    = $_REQUEST['Gable_Vent'];
		     $Power_Ventil  			    = $_REQUEST['Power_Ventil'];
		     $Whirly_Bird  			    = $_REQUEST['Whirly_Bird'];
		     $Solar_Attic  			    = $_REQUEST['Solar_Attic'];
		     $blocked  			        = $_REQUEST['blocked'];
		     $Cool_Ply  			        = $_REQUEST['Cool_Ply'];
		     $Spray_On  			        = $_REQUEST['Spray_On'];
		     $Staple  			        = $_REQUEST['Staple'];
		     $None  			            = $_REQUEST['None'];
		     $id = $_REQUEST['espi_id'];
  		
  	$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	

	 $recs = db_iquery($connection,"CALL sp_espi_five('".trim($leakage)."','".trim($insulation)."','".trim($ventilation1)."','".trim($radiant_barrier)."','".trim($attic_recommendation)."','".trim($insulation_text)."','".trim($Attic_Ladder)."','".trim($Plumbing_Pene)."','".trim($Electrical_Pene)."','".trim($HVAC_Pene)."','".trim($Fiberglass)."','".trim($Greater)."','".trim($Soffits_Clear)."','".trim($Ridge_Vent)."','".trim($Gable_Vent)."','".trim($Power_Ventil)."','".trim($Whirly_Bird)."','".trim($Solar_Attic)."','".trim($blocked)."','".trim($Cool_Ply)."','".trim($Spray_On)."','".trim($Staple)."','".trim($None)."','".trim($id)."')") or die( mysqli_error() ); 

  			if (isset($recs)){
			$response['espi_attic'] = array("errmsg"=>'Record Updated Successfully');
  			}
	}else{
  			$response['espi_attic'] = array("errmsg"=>'Parameters missed');
  		}
	
	if (isset($_REQUEST['espi_id'])){
$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
$recs = db_iquery($connection,"CALL sp_up_espi_twseven('".trim($_REQUEST['air_cond_age'])."','".trim($_REQUEST['age'])."','".trim($_REQUEST['efficiency_seer'])."','".trim($_REQUEST['efficiency_seer_text'])."','".trim($_REQUEST['evacoil'])."','".trim($_REQUEST['maintenance'])."','".trim($_REQUEST['evaporator_coil'])."','".trim($_REQUEST['condenser_coil'])."','".trim($_REQUEST['primary_pan'])."','".trim($_REQUEST['drain_line'])."','".trim($_REQUEST['other'])."','".trim($_REQUEST['installation1'])."','".trim($_REQUEST['Disconnect'])."','".trim($_REQUEST['Level'])."','".trim($_REQUEST['Raise'])."','".trim($_REQUEST['Insulate'])."','".trim($_REQUEST['Relocate'])."','".trim($_REQUEST['Strap'])."','".trim($_REQUEST['Inspection'])."','".trim($_REQUEST['Inline'])."','".trim($_REQUEST['Secondary'])."','".trim($_REQUEST['Hard'])."','".trim($_REQUEST['Surge'])."','".trim($_REQUEST['Quick'])."','".trim($_REQUEST['Otherins'])."','".trim($_REQUEST['air_cond_recommendation'])."','".trim($_REQUEST['espi_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$response['espi_air_conditioning'] = array("errmsg"=>'Record Updated Successfully');
  		   }
	}else
  		{
  			$response['espi_air_conditioning'] = array("errmsg"=>'Parameters missed');
  		}
	
	if (isset($_REQUEST['espi_id']))
  	{
$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
$recs = db_iquery($connection,"CALL sp_up_espi_twseven_heating('".trim($_REQUEST['heating_age'])."','".trim($_REQUEST['heating'])."','".trim($_REQUEST['efficiency'])."','".trim($_REQUEST['heating_efficiency'])."','".trim($_REQUEST['pumps'])."','".trim($_REQUEST['afue'])."','".trim($_REQUEST['effseer'])."','".trim($_REQUEST['fueltype'])."','".trim($_REQUEST['variablespeed'])."','".trim($_REQUEST['Blower'])."','".trim($_REQUEST['Burners'])."','".trim($_REQUEST['Exchanger'])."','".trim($_REQUEST['Main_Heat_Other'])."','".trim($_REQUEST['Furnace'])."','".trim($_REQUEST['Service'])."','".trim($_REQUEST['Flue'])."','".trim($_REQUEST['Gas'])."','".trim($_REQUEST['Ins_Other'])."','".trim($_REQUEST['maintenance1'])."','".trim($_REQUEST['installation2'])."','".trim($_REQUEST['heating_recommendation'])."',".trim($_REQUEST['espi_id']).")") or die( mysqli_error() ); 


  			if(isset($recs))
  			{
  			$response['espi_heating'] = array("errmsg"=>'Record Updated Successfully');

			
  		 }
	}else
  		{
  			$response['espi_heating'] = array("errmsg"=>'Parameters missed');
  		}
	
	if (isset($_REQUEST['espi_id']))
  	{
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
$recs = db_iquery($connection,"CALL sp_up_espi_duct_age_nine('".trim($_REQUEST['duct_age'])."','".trim($_REQUEST['duct_age_check'])."','".trim($_REQUEST['insulation2'])."','".trim($_REQUEST['design'])."','".trim($_REQUEST['installation3'])."','".trim($_REQUEST['duct_insulation'])."','".trim($_REQUEST['duct_recommendation'])."','".trim($_REQUEST['espi_status'])."','".trim($_REQUEST['return_leakage'])."','".trim($_REQUEST['supply_leakage'])."','".trim($_REQUEST['insulationrvalue'])."','".trim($_REQUEST['noise'])."','".trim($_REQUEST['drafts'])."','".trim($_REQUEST['uneventemp'])."','".trim($_REQUEST['highstaticpressure'])."','".trim($_REQUEST['noofreturns'])."','".trim($_REQUEST['seal'])."','".trim($_REQUEST['stretch'])."','".trim($_REQUEST['ductstrap'])."','".trim($_REQUEST['straighten'])."','".trim($_REQUEST['return_grill_size1'])."','".trim($_REQUEST['return_duct_size1'])."','".trim($_REQUEST['system_ton1'])."','".trim($_REQUEST['return_grill_size2'])."','".trim($_REQUEST['return_duct_size2'])."','".trim($_REQUEST['system_ton2'])."','".trim($_REQUEST['return_grill_size3'])."','".trim($_REQUEST['return_duct_size3'])."','".trim($_REQUEST['system_ton3'])."','".trim($_REQUEST['return_grill_size4'])."','".trim($_REQUEST['return_duct_size4'])."','".trim($_REQUEST['system_ton4'])."','".trim($_REQUEST['return_grill_size5'])."','".trim($_REQUEST['return_duct_size5'])."','".trim($_REQUEST['system_ton5'])."','".trim($_REQUEST['return_grill_size6'])."','".trim($_REQUEST['return_duct_size6'])."','".trim($_REQUEST['system_ton6'])."','".trim($_REQUEST['return_grill_size7'])."','".trim($_REQUEST['return_duct_size7'])."','".trim($_REQUEST['system_ton7'])."','".trim($_REQUEST['espi_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$response['espi_duct'] = array("errmsg"=>'Record Updated Successfully');
			
  		 }
	}else
  		{
  			$response['espi_duct'] = array("errmsg"=>'Parameters missed');
  		}
	if(isset($_REQUEST['opt_check']) && $_REQUEST['opt_check'] == "Opt Check"){
		if (isset($_REQUEST['repair_id']) && $_REQUEST['repair_id']!=""){
		/*repair sol update*/
  	if (isset($_REQUEST['repair_id']))
  	{
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
$recs = db_iquery($connection,"CALL sp_update_tbl_repairsolutions_ten9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['optimal_sol_benefits'])."','".trim($_REQUEST['opt_dispatches'])."','".trim($_REQUEST['opt_sal_opp'])."','".trim($_REQUEST['opt_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['opt_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."','".trim($_REQUEST['repair_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$response['repair_solutions_update'] = array("errmsg"=>'Record Updated Successfully');
			
  		 }
	}else
  		{
  			$response['repair_solutions_update'] = array("errmsg"=>'Repair solutions id missed');
  		}
	}else{
		/*repair solutions insert*/
		if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id']))
		{
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
							or die ("could not connect to database");	
	$recs = db_iquery($connection,"CALL sp_insent_tbl__repairsolutions_ten9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['optimal_sol'])."','".trim($_REQUEST['optimal_sol_benefits'])."','".trim($_REQUEST['opt_dispatches'])."','".trim($_REQUEST['opt_sal_opp'])."','".trim($_REQUEST['opt_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['opt_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."')") or die( mysqli_error() ); 
	
				if(isset($recs))
				{
				$response['repair_solutions_insert'] = array("errmsg"=>'Record inserted Successfully');
				
			 }
		}else
			{
				$response['repair_solutions_insert'] = array("errmsg"=>'Parameters missed');
			}
	}
	}
	if(isset($_REQUEST['opt_check']) && $_REQUEST['opt_check'] == "Ess Check"){
		if (isset($_REQUEST['repair_id']) && $_REQUEST['repair_id']!=""){
				/*repair sol update*/
  	if (isset($_REQUEST['repair_id']))
  	{
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
$recs = db_iquery($connection,"CALL sp_update_tbl_repairsolutions9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['essent_sol_ben'])."','".trim($_REQUEST['ess_dispatches'])."','".trim($_REQUEST['ess_sal_opp'])."','".trim($_REQUEST['ess_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['ess_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."','".trim($_REQUEST['repair_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$response['repair_solutions_update'] = array("errmsg"=>'Record Updated Successfully');
  		    }
	}else{
  			$response['repair_solutions_update'] = array("errmsg"=>'Repair solutions id missed');
  	}
}else{
	
	/*repair solutions insert*/
		if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id']))
		{
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
							or die ("could not connect to database");	
	$recs = db_iquery($connection,"CALL sp_insert_tbl_repairsolutions9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['essent_sol'])."','".trim($_REQUEST['essent_sol_ben'])."','".trim($_REQUEST['ess_dispatches'])."','".trim($_REQUEST['ess_sal_opp'])."','".trim($_REQUEST['ess_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['ess_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."')") or die( mysqli_error() ); 
	
				if(isset($recs))
				{
				$response['repair_solutions_insert'] = array("errmsg"=>'Record inserted Successfully');
				
			 }
		}else
			{
				$response['repair_solutions_insert'] = array("errmsg"=>'Parameters missed');
			}
	
}
	}
	if(isset($_REQUEST['opt_check']) && $_REQUEST['opt_check'] == "Cri Check"){
		if (isset($_REQUEST['repair_id']) && $_REQUEST['repair_id']!=""){
			/*repair sol update*/
  	if (isset($_REQUEST['repair_id']))
  	{
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
$recs = db_iquery($connection,"CALL sp_upd_tbl_ten_repairsolutions9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['critical_sol_ben'])."','".trim($_REQUEST['cri_dispatches'])."','".trim($_REQUEST['cri_sal_opp'])."','".trim($_REQUEST['cri_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['cri_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."','".trim($_REQUEST['repair_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs))
  			{
  			$response['repair_solutions_update'] = array("errmsg"=>'Record Updated Successfully');
  		    }
	}else{
  			$response['repair_solutions_update'] = array("errmsg"=>'Repair solutions id missed');
  	}
		}else{
			
			/*repair solutions insert*/
		if (isset($_REQUEST['customer_id'],$_REQUEST['quote_id']))
		{
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
							or die ("could not connect to database");	
	$recs = db_iquery($connection,"CALL sp_ins_tbl_repairsolutions9('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['critical_sol'])."','".trim($_REQUEST['critical_sol_ben'])."','".trim($_REQUEST['cri_dispatches'])."','".trim($_REQUEST['cri_sal_opp'])."','".trim($_REQUEST['cri_rep_opp'])."','".trim($_REQUEST['opt_check'])."','".trim($_REQUEST['cri_investment'])."','".trim($_REQUEST['investment_sol'])."','".trim($_REQUEST['investment_amount'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['created_date'])."','".trim($_REQUEST['discount_type'])."')") or die( mysqli_error() ); 
	
				if(isset($recs))
				{
				$response['repair_solutions_insert'] = array("errmsg"=>'Record inserted Successfully');
				
			 }
		}else
			{
				$response['repair_solutions_insert'] = array("errmsg"=>'Parameters missed');
			}
		}
	}
	
	if (isset($_REQUEST['repair_replace_id']) && $_REQUEST['repair_replace_id']!=""){
		if (isset($_REQUEST['repair_replace_id'])){
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
			$recs = db_iquery($connection,"CALL sp_upd_tbl_repairreplace('".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['tenyrs_old_repair'])."','".trim($_REQUEST['high_bill_repair'])."','".trim($_REQUEST['fre_break_repair'])."','".trim($_REQUEST['sys_ref_repair'])."','".trim($_REQUEST['repair_replace_id'])."')") or die( mysqli_error() ); 

  			if(isset($recs)){
  				$response['repair_replace_update'] = array("errmsg"=>'Record Updated Successfully');
  		    }
		}else{
  				$response['repair_replace_update'] = array("errmsg"=>'Repair replace id missed');
  		}
	}else{
		if (isset($_REQUEST['tenyrs_old_repair'],$_REQUEST['high_bill_repair'],$_REQUEST['fre_break_repair'],$_REQUEST['sys_ref_repair'])){
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
			$recs = db_iquery($connection,"CALL sp_inst_tbl_repairreplace('".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['tenyrs_old_repair'])."','".trim($_REQUEST['high_bill_repair'])."','".trim($_REQUEST['fre_break_repair'])."','".trim($_REQUEST['sys_ref_repair'])."')") or die( mysqli_error() );

  			if(isset($recs)){
  				$response['repair_replace_update'] = array("errmsg"=>'Record inserted Successfully');
  		    }
		}else{
  				$response['repair_replace_update'] = array("errmsg"=>'Parameters missed');
  		}
	}
	
		
	


    //echo json_encode($output);exit();
  	//$response['data'] = $output;
	$response['code'] = 1;
	$response['status'] = 200;
  	sendResponse($response['status'], json_encode($response), $contenttype);
  }
	
   function product_lists() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';	
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id= "";
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id= "";
						
		if ($subscriber_id!="" && $company_id!=""){
			$recs = db_iquery($connection,"SELECT product_name,purchase_cost,customer_cost FROM lkp_products")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs) > 0)
			{	
				$response['code'] = 1;
				$response['status'] = 200;
				while($row=mysqli_fetch_object($recs))
				{
				$output[] =  $row;
				}
				$response['data'] = $output;
			}
			else
			{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"No record found");
			}
		}else{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"Parameters missed");
		}
		sendResponse($response['status'], json_encode($response), $contenttype);
	}
   function single_consultant_rendering() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id= "";
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id= "";
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id = "";
		if (isset($_REQUEST['quote_id'])){$quote_id = $_REQUEST['quote_id'];}else $quote_id = "";

		
		if((trim($subscriber_id) !="") && (trim($company_id) !="") && (trim($customer_id) !=""))
		{	
		    $response['code'] = 1;
			$response['status'] = 200;
			$recs1 = db_iquery($connection,"CALL sp_get_customers_information('".$subscriber_id."','".$company_id."','".$customer_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			
			if (mysqli_num_rows($recs1) > 0)
			{	
				while($row1=mysqli_fetch_object($recs1))
				{
				$customer_information[] =  $row1;
				}	
				$response['customer_information'] =  $customer_information;
				
			}
			else
			{
				$response['customer_information'] = array("errmsg"=>'No Record');
			}
			
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
			$cat_recs = db_iquery($connection,"CALL sp_getallcategory()")or die( mysqli_error() ); // die ("invalid query");

			if (mysqli_num_rows($cat_recs) > 0)
			{	
					
				while($category=mysqli_fetch_object($cat_recs)) 
				{
					    $nauto_cate_id = $category->nauto_cate_id;
						$connection    = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
						$sub_cat_recs  = db_iquery($connection,"CALL sp_tbl_subcategory_one('".$nauto_cate_id."')") or die( mysqli_error() ); 
					   
						   $sub_category_out = "";
							while($sub_category=mysqli_fetch_object($sub_cat_recs)) {
								$sub_category_out[]   = $sub_category;
								$nauto_subcate_id = $sub_category->nauto_subcate_id;
								$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
								$brand_recs      = db_iquery($connection,"SELECT DISTINCT b.nauto_brand_id, b.cbrand_name, b.cbrand_description, b.cbrand_img, b.nbrand_order, b.brand_status_flag, b.dcreated_dt FROM `tbl_series` a, `tbl_brand` b WHERE a.subcate_id = '".$nauto_subcate_id."' AND b.nauto_brand_id = a.nfk_brand_id") or die( mysqli_error() ); 
								$brand_out_new = "";
									while($brand=mysqli_fetch_object($brand_recs)) {
						    				$brand_out_new[] = $brand;
											$nfk_brand_id = $brand->nauto_brand_id;
											$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
											$series_recs = db_iquery($connection,"SELECT * FROM  tbl_series WHERE  nfk_brand_id = '".$nfk_brand_id."' and subcate_id='".$nauto_subcate_id."'") or die( mysqli_error() ); 
											while($series=mysqli_fetch_object($series_recs)) {
												$series_out[] = $series;
												$nauto_series_id = $series->nauto_series_id;
												$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
												$speci_recs = db_iquery($connection,"CALL sp_tbl_specification('".$nauto_series_id."')") or die( mysqli_error() ); 
												while($specification=mysqli_fetch_object($speci_recs)) {
													$specification_out[] = $specification;
												}
												$specication_cat 			 = array('specification'  =>$specification_out);
												$specication_cat_out_new1  = (object)array_merge((array)$series, (array)$specication_cat);
												$specification_res_out1[] =  $specication_cat_out_new1;
											}
											$series_cat 			 = array('series'  =>$specification_res_out1);
											$series_cat_out_new1  = (object)array_merge((array)$brand, (array)$series_cat);
											$series_res_out1[] =  $series_cat_out_new1;
									}
							       	$brand_cat 			 = array('brand'  =>$series_res_out1);
									$brand_cat_out_new1  = (object)array_merge((array)$sub_category, (array)$brand_cat);
									$sub_category_out1[] =  $brand_cat_out_new1;
							}
							$sub_cat 			= array('sub_category'  =>$sub_category_out1);
						    $category_out_new1  = (object)array_merge((array)$category, (array)$sub_cat);
							$category_out[] 	=  $category_out_new1;
				}	

				$response['category'] =  $category_out;
			}
			else
			{
				$response['category'] = array("errmsg"=>'No Record');
			}
		}
		else
		{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"Parameters missed");
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
   function single_acion_plan() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id= "";
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id= "";
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id = "";
		if (isset($_REQUEST['quote_id'])){$quote_id = $_REQUEST['quote_id'];}else $quote_id = "";
		if (isset($_REQUEST['consultant_id'])){$consultant_id = $_REQUEST['consultant_id'];}else $consultant_id = "";

		
		if((trim($consultant_id) !="") && (trim($quote_id) !="") && (trim($customer_id) !=""))
		{	
		    $response['code'] = 1;
			$response['status'] = 200;
			$plan_details = db_iquery($connection,"CALL sel_plan_details('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['consultant_id'])."')") or die( mysqli_error() ); 
			if (mysqli_num_rows($plan_details) > 0)
			{	
				while($plan_details_out=mysqli_fetch_object($plan_details))
				{
					$plan_details_result[] =  $plan_details_out;
				}	
				$response['plan_details'] =  $plan_details_result;
				
			}
			else
			{
				$response['plan_details'] = array("errmsg"=>'No Record');
			}
			$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME) or die ("could not connect to database");	
			$workorder_information = db_iquery($connection,"CALL sp_four_tbl_invoice_quote_header('".$subscriber_id."','".$company_id."','".$quote_id."')")
			or die( mysqli_error() ); // die ("invalid query");
			if (mysqli_num_rows($workorder_information) > 0)
			{	
				while($workorder_information_out=mysqli_fetch_object($workorder_information))
				{
					$workorder_information_result[] =  $workorder_information_out;
				}	
				$response['workorder_information'] =  $workorder_information_result;
				
			}
			else
			{
				$response['workorder_information'] = array("errmsg"=>'No Record');
			}
			
		}
		else
		{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"Parameters missed");
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	function single_update_plan() {
		$connection = db_iconnect(DB_HOST,DB_USER, DB_PASS, DB_NAME)
						or die ("could not connect to database");	
		$contenttype = 'application/json; charset=utf-8';					
		
		if (isset($_REQUEST['subscriber_id'])){$subscriber_id = $_REQUEST['subscriber_id'];}else $subscriber_id= "";
		if (isset($_REQUEST['company_id'])){$company_id = $_REQUEST['company_id'];}else $company_id= "";
		if (isset($_REQUEST['customer_id'])){$customer_id = $_REQUEST['customer_id'];}else $customer_id = "";
		if (isset($_REQUEST['quote_id'])){$quote_id = $_REQUEST['quote_id'];}else $quote_id = "";
		if (isset($_REQUEST['consultant_id'])){$consultant_id = $_REQUEST['consultant_id'];}else $consultant_id = "";
		if (isset($_REQUEST['plandetails_id'])){$plandetails_id = $_REQUEST['plandetails_id'];}else $plandetails_id = "";

		
		if((trim($consultant_id) !="") && (trim($quote_id) !="") && (trim($customer_id) !=""))
		{	
		    $response['code'] = 1;
			$response['status'] = 200;
			if (isset($_REQUEST['plandetails_id'])){	
			$recs = db_iquery($connection,"CALL up_plan_details1('".trim($_REQUEST['customer_id'])."','".trim($_REQUEST['consultant_id'])."','".trim($_REQUEST['quote_id'])."','".trim($_REQUEST['company_id'])."','".trim($_REQUEST['subscriber_id'])."','".trim($_REQUEST['copperline'])."','".trim($_REQUEST['copperlinedesc'])."','".trim($_REQUEST['linesetcovers'])."','".trim($_REQUEST['linesetcoversdesc'])."','".trim($_REQUEST['installsuction'])."','".trim($_REQUEST['liquidline'])."','".trim($_REQUEST['liquidlinedesc'])."','".trim($_REQUEST['newdisconnect'])."','".trim($_REQUEST['conepaapproved'])."','".trim($_REQUEST['refrigantrecovery'])."','".trim($_REQUEST['highvoltage'])."','".trim($_REQUEST['surgeprotector'])."','".trim($_REQUEST['slab'])."','".trim($_REQUEST['circuitbreaker'])."','".trim($_REQUEST['condenserspecialnotes'])."','".trim($_REQUEST['coilepaapproved'])."','".trim($_REQUEST['suctionline'])."','".trim($_REQUEST['installinspection'])."','".trim($_REQUEST['metalstrap'])."','".trim($_REQUEST['drainpan'])."','".trim($_REQUEST['drainpandesc'])."','".trim($_REQUEST['txvvalve'])."','".trim($_REQUEST['condensatepump'])."','".trim($_REQUEST['floatswitch'])."','".trim($_REQUEST['coilplenum'])."','".trim($_REQUEST['cleanoutt'])."','".trim($_REQUEST['primarydrainlines'])."','".trim($_REQUEST['secondarydrainlines'])."','".trim($_REQUEST['frenchdrain'])."','".trim($_REQUEST['collars'])."','".trim($_REQUEST['coilspecialnotes'])."','".trim($_REQUEST['disconnect_desc'])."','".trim($_REQUEST['refrigerant_desc'])."','".trim($_REQUEST['surge_desc'])."','".trim($_REQUEST['circuit_desc'])."','".trim($_REQUEST['plandetails_id'])."')") or die( mysqli_error() );
				
				$response['plan_details1'] = array("errmsg"=>'Record updated successfully');
			}
			else
			{
				$response['plan_details1'] = array("errmsg"=>'Plandetails id missed');
			}
			
			if (isset($_REQUEST['plandetails_id'])){	
			$recs = db_iquery($connection,"CALL Up_plan_Details2('".trim($_REQUEST['furreturnair'])."','".trim($_REQUEST['furreturnairplenum'])."','".trim($_REQUEST['fuelpipe'])."','".trim($_REQUEST['flexlinevalve'])."','".trim($_REQUEST['replacegascutoff'])."','".trim($_REQUEST['installnewcap'])."','".trim($_REQUEST['cutroofdecking'])."','".trim($_REQUEST['gaspiping'])."','".trim($_REQUEST['metalfurnacestands'])."','".trim($_REQUEST['metalfurnacestandsdesc'])."','".trim($_REQUEST['furmetalstrap'])."','".trim($_REQUEST['furnacespecialnotes'])."','".trim($_REQUEST['airepaapproved'])."','".trim($_REQUEST['airmetalstrap'])."','".trim($_REQUEST['airmetalstrapdesc'])."','".trim($_REQUEST['metalstands'])."','".trim($_REQUEST['metalstandsdesc'])."','".trim($_REQUEST['breakerchange'])."','".trim($_REQUEST['breakerchangedesc'])."','".trim($_REQUEST['furdrainpans'])."','".trim($_REQUEST['floatswitchkit'])."','".trim($_REQUEST['disconnectbox'])."','".trim($_REQUEST['disconnectboxdesc'])."','".trim($_REQUEST['newdisconnectbox'])."','".trim($_REQUEST['airgrillspecialnotes'])."','".trim($_REQUEST['plandetails_id'])."')") or die( mysqli_error() ); 
				
				$response['plan_details2'] = array("errmsg"=>'Record updated successfully');
			}
			else
			{
				$response['plan_details2'] = array("errmsg"=>'Plandetails id missed');
			}
			
			if (isset($_REQUEST['plandetails_id'])){	
			$recs = db_iquery($connection,"CALL Up_plan_Details3('".trim($_REQUEST['ductplenums'])."','".trim($_REQUEST['ductplenumdesc'])."','".trim($_REQUEST['ductboxes'])."','".trim($_REQUEST['ductboxesdesc'])."','".trim($_REQUEST['returnchaseseal'])."','".trim($_REQUEST['ductgrills'])."','".trim($_REQUEST['ductgrillsdesc'])."','".trim($_REQUEST['masticascode'])."','".trim($_REQUEST['damperscollars'])."','".trim($_REQUEST['damperscollarsdesc'])."','".trim($_REQUEST['newreturnair'])."','".trim($_REQUEST['newreturnairdesc'])."','".trim($_REQUEST['ductstrap'])."','".trim($_REQUEST['nylonduct'])."','".trim($_REQUEST['airdistspecialnotes'])."','".trim($_REQUEST['airgrillnum1'])."','".trim($_REQUEST['airgrillnum2'])."','".trim($_REQUEST['aircombo1'])."','".trim($_REQUEST['airgrillnum3'])."','".trim($_REQUEST['airgrillnum4'])."','".trim($_REQUEST['aircombo2'])."','".trim($_REQUEST['airgrillnum5'])."','".trim($_REQUEST['airgrillnum6'])."','".trim($_REQUEST['aircombo3'])."','".trim($_REQUEST['airgrillnum7'])."','".trim($_REQUEST['airgrillnum8'])."','".trim($_REQUEST['aircombo4'])."','".trim($_REQUEST['airgrillnum9'])."','".trim($_REQUEST['airgrillnum10'])."','".trim($_REQUEST['aircombo5'])."','".trim($_REQUEST['airgrillnum11'])."','".trim($_REQUEST['airgrillnum12'])."','".trim($_REQUEST['aircombo6'])."','".trim($_REQUEST['cairgrill_specialnotes'])."','".trim($_REQUEST['plandetails_id'])."')") or die( mysqli_error() ); 
				
				$response['plan_details3'] = array("errmsg"=>'Record updated successfully');
			}
			else
			{
				$response['plan_details3'] = array("errmsg"=>'Plandetails id missed');
			}
			
			if (isset($_REQUEST['plandetails_id'])){	
			$recs = db_iquery($connection,"CALL Up_plan_Details4('".trim($_REQUEST['tattic_attic_tent'])."','".trim($_REQUEST['cattic_attic_tent_desc'])."','".trim($_REQUEST['tattic_seal_attic'])."','".trim($_REQUEST['cattic_seal_attic_desc'])."','".trim($_REQUEST['tattic_insulation'])."','".trim($_REQUEST['cattic_insulation_desc'])."','".trim($_REQUEST['tattic_solar_attic'])."','".trim($_REQUEST['tattic_light_covers'])."','".trim($_REQUEST['cattic_light_covers_desc'])."','".trim($_REQUEST['tattic_radiant_barrier'])."','".trim($_REQUEST['tattic_old_insulation'])."','".trim($_REQUEST['tattic_wall_insulation'])."','".trim($_REQUEST['tattic_channel_soffit'])."','".trim($_REQUEST['tattic_other'])."','".trim($_REQUEST['tattic_special_notes'])."','".trim($_REQUEST['tindoor_air_cleaner'])."','".trim($_REQUEST['tindoor_germicidal_lights'])."','".trim($_REQUEST['cindoor_special_notes'])."','".trim($_REQUEST['tengg_load_analysis'])."','".trim($_REQUEST['tengg_door_test'])."','".trim($_REQUEST['tengg_blaster_test'])."','".trim($_REQUEST['tengg_duct_design'])."','".trim($_REQUEST['cengg_special_notes'])."','".trim($_REQUEST['plandetails_id'])."')") or die( mysqli_error() ); 
				
				$response['plan_details4'] = array("errmsg"=>'Record updated successfully');
			}
			else
			{
				$response['plan_details4'] = array("errmsg"=>'Plandetails id missed');
			}
			
			if (isset($_REQUEST['plandetails_id'])){	
			$recs = db_iquery($connection,"CALL Up_plan_Details5('".trim($_REQUEST['tcont_thermostat'])."','".trim($_REQUEST['tcont_dehumidification'])."','".trim($_REQUEST['ccont_special_notes'])."','".trim($_REQUEST['tinst_drug_test'])."','".trim($_REQUEST['tinst_checked'])."','".trim($_REQUEST['tinst_certified_installer'])."','".trim($_REQUEST['tinst_installation'])."','".trim($_REQUEST['tinst_booties'])."','".trim($_REQUEST['tinst_drop_cloths'])."','".trim($_REQUEST['tinst_cleaning'])."','".trim($_REQUEST['tinst_special_notes'])."','".trim($_REQUEST['additional_notes'])."','".trim($_REQUEST['nautoid'])."')") or die( mysqli_error() ); 
				
				$response['plan_details5'] = array("errmsg"=>'Record updated successfully');
			}
			else
			{
				$response['plan_details5'] = array("errmsg"=>'Plandetails id missed');
			}
			
			
		}
		else
		{
				$response['code'] = 1;
				$response['status'] = 400;
				$response['data'] = array("status"=>"Parameters missed");
		}		

		sendResponse($response['status'], json_encode($response), $contenttype);
	}
	
   function defa() {
  // Set default HTTP response.
  $response['code'] = 0;
  $response['data'] = NULL;
  $contenttype = 'application/json; charset=utf-8';
  /*
  $output = array("errmsg"=>'Invalid API call!');
  echo json_encode($output);exit();
  */
  $output = array("errmsg"=>'Invalid API call!');
  $response['status'] = 400;
  $response['data'] = $output;
  sendResponse($response['status'], json_encode($response), $contenttype);
  }
  function getStatusCodeMessage($status)
  {
    /* Status code example	*/
    $codes = Array(
  	200 => 'OK',
  	301 => 'Moved Permanently',
  	400 => 'Bad Request',
  	401 => 'Unauthorized',
  	402 => 'Payment Required',
  	403 => 'Forbidden',
  	404 => 'Not Found',
  	405 => 'Method Not Allowed',
  	406 => 'Not Acceptable',
  	407 => 'Proxy Authentication Required',
  	408 => 'Request Timeout',
  	409 => 'Conflict',
  	410 => 'Gone',
  	411 => 'Length Required',
  	412 => 'Precondition Failed',
  	413 => 'Request Entity Too Large',
  	414 => 'Request-URI Too Long',
  	415 => 'Unsupported Media Type',
  	416 => 'Requested Range Not Satisfiable',
  	417 => 'Expectation Failed',
  	500 => 'Internal Server Error',
  	501 => 'Not Implemented',
  	502 => 'Bad Gateway',
  	503 => 'Service Unavailable',
  	504 => 'Gateway Timeout',
  	505 => 'HTTP Version Not Supported'
    );

    return (isset($codes[$status])) ? $codes[$status] : '';
  }
	
	?>