<?php

	/*define('DBMS', 'MYSQL'); // database system	
	define('DB_HOST', 'localhost'); // database host
	define('DB_USER', 'root'); // username
	define('DB_PASS', ''); // password
	define('DB_NAME', 'servicemaxdb'); // database name
	*/
	
	define('DBMS', 'MYSQL'); // database system	
	define('DB_HOST', 'localhost'); // database host
	define('DB_USER', 'servicemaxuser'); // username
	define('DB_PASS', 's36v1c3#@56'); // password
	define('DB_NAME', 'servicemaxdb'); // database name
?>